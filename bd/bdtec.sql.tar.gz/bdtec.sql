--
-- PostgreSQL database dump
--

-- Dumped from database version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ITE; Type: SCHEMA; Schema: -; Owner: amaterasu
--

CREATE SCHEMA "ITE";


ALTER SCHEMA "ITE" OWNER TO amaterasu;

--
-- Name: T_apellidos_persona; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_apellidos_persona" AS character varying(55);


ALTER DOMAIN "ITE"."T_apellidos_persona" OWNER TO amaterasu;

--
-- Name: T_aula; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_aula" AS character(6) NOT NULL;


ALTER DOMAIN "ITE"."T_aula" OWNER TO amaterasu;

--
-- Name: T_calificacion; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_calificacion" AS smallint;


ALTER DOMAIN "ITE"."T_calificacion" OWNER TO amaterasu;

--
-- Name: T_carrera; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_carrera" AS character(3);


ALTER DOMAIN "ITE"."T_carrera" OWNER TO amaterasu;

--
-- Name: T_ciudad; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_ciudad" AS character varying(100);


ALTER DOMAIN "ITE"."T_ciudad" OWNER TO amaterasu;

--
-- Name: T_creditos; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_creditos" AS smallint;


ALTER DOMAIN "ITE"."T_creditos" OWNER TO amaterasu;

--
-- Name: T_curp; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_curp" AS character varying(18);


ALTER DOMAIN "ITE"."T_curp" OWNER TO amaterasu;

--
-- Name: T_especialidad; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_especialidad" AS character varying(5);


ALTER DOMAIN "ITE"."T_especialidad" OWNER TO amaterasu;

--
-- Name: T_estado_civil; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_estado_civil" AS character(1);


ALTER DOMAIN "ITE"."T_estado_civil" OWNER TO amaterasu;

--
-- Name: T_fecha; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_fecha" AS date;


ALTER DOMAIN "ITE"."T_fecha" OWNER TO amaterasu;

--
-- Name: T_folio_acta; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_folio_acta" AS character(12);


ALTER DOMAIN "ITE"."T_folio_acta" OWNER TO amaterasu;

--
-- Name: T_lugar_nac; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_lugar_nac" AS character(2);


ALTER DOMAIN "ITE"."T_lugar_nac" OWNER TO amaterasu;

--
-- Name: T_materia; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_materia" AS character varying(10);


ALTER DOMAIN "ITE"."T_materia" OWNER TO amaterasu;

--
-- Name: T_no_de_control; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_no_de_control" AS character varying(10) NOT NULL;


ALTER DOMAIN "ITE"."T_no_de_control" OWNER TO amaterasu;

--
-- Name: T_periodo; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_periodo" AS character varying(5);


ALTER DOMAIN "ITE"."T_periodo" OWNER TO amaterasu;

--
-- Name: T_promedio; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_promedio" AS numeric(5,2);


ALTER DOMAIN "ITE"."T_promedio" OWNER TO amaterasu;

--
-- Name: T_reticula; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_reticula" AS smallint;


ALTER DOMAIN "ITE"."T_reticula" OWNER TO amaterasu;

--
-- Name: T_sexo; Type: DOMAIN; Schema: ITE; Owner: amaterasu
--

CREATE DOMAIN "ITE"."T_sexo" AS character(1) NOT NULL;


ALTER DOMAIN "ITE"."T_sexo" OWNER TO amaterasu;

--
-- Name: actualizar_egreso_ind(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".actualizar_egreso_ind(control character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
ultimo_periodo character varying;
promedio numeric;

BEGIN

	SELECT MAX(h.periodo) INTO ultimo_periodo FROM "ITE".historia_alumno h 
	WHERE h.no_de_control = control;
	
	SELECT ROUND(AVG(h.calificacion),2) INTO promedio FROM "ITE".historia_alumno h 
	WHERE h.no_de_control = control AND h.calificacion>=70
	AND h.tipo_evaluacion NOT IN('AC','93','92','91');
	
	UPDATE "ITE".alumnos a 
	SET ultimo_periodo_inscrito=ultimo_periodo,
	promedio_aritmetico_acumulado=promedio 
	WHERE a.no_de_control = control;

END
$$;


ALTER FUNCTION "ITE".actualizar_egreso_ind(control character varying) OWNER TO amaterasu;

--
-- Name: alta_horario(); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".alta_horario() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
vexcesohoras char(13);
vcount int; 
vcount1 int; 
vcount2 int; 
vparalelo char(20) := null;
BEGIN
	IF NEW.dia_semana =1 THEN 
	vexcesohoras := 'domingo'; 
        ELSIF NEW.dia_semana = 2 THEN
	vexcesohoras := 'lunes'; 
        ELSIF NEW.dia_semana = 3 THEN
	vexcesohoras := 'martes';
        ELSIF NEW.dia_semana = 4 THEN
	vexcesohoras := 'miercoles';
        ELSIF NEW.dia_semana = 5 THEN
	vexcesohoras := 'jueves';
        ELSIF NEW.dia_semana = 6 THEN
	vexcesohoras := 'viernes';
        ELSE 
	vexcesohoras := 'sabado';
	END IF;   
	IF NEW.tipo_horario='D' THEN
      	SELECT paralelo_de FROM "ITE".grupos WHERE periodo=NEW.periodo and materia=NEW.materia AND grupo=NEW.grupo INTO vparalelo;
	END IF;	
	IF vparalelo IS NULL THEN
		SELECT count(*) from "ITE".horarios where periodo=NEW.periodo AND rfc=NEW.rfc AND (NEW.rfc is not null or NEW.rfc<>'') and dia_semana=NEW.dia_semana 
		and ( hora_inicial=NEW.hora_inicial  or ( hora_inicial < NEW.hora_inicial and NEW.hora_inicial<hora_final )  
		or ( hora_inicial < NEW.hora_final and NEW.hora_final<hora_final )  
		or ( NEW.hora_inicial<hora_inicial and hora_inicial<NEW.hora_final ) 
		or ( hora_inicial > NEW.hora_inicial and hora_final<NEW.hora_final )                
      		and (vigencia_inicio=NEW.vigencia_inicio OR NEW.vigencia_inicio IS NULL)) INTO vcount;
		IF vcount > 0 THEN
			RAISE EXCEPTION 'Error esta persona ya tiene ocupada la hora indicada el día %', vexcesohoras;
		END IF;
		IF NEW.tipo_horario='D' THEN
			select count(*) from "ITE".grupos where paralelo_de=CONCAT(NEW.materia,NEW.grupo) and periodo = NEW.periodo INTO vcount1;
			 select count(*) from "ITE".horarios where periodo=NEW.periodo and aula=NEW.aula and aula<>'no' 
			 and aula in (select a.aula from aulas a where permite_cruce='N') 
			 and dia_semana=NEW.dia_semana         
				and ( hora_inicial=NEW.hora_inicial  or                                         
					( (hora_inicial < NEW.hora_inicial) and (NEW.hora_inicial<hora_final) )  or    
					( (hora_inicial < NEW.hora_final) and (NEW.hora_final<hora_final) )  or                                        
					( (NEW.hora_inicial<hora_inicial) and (hora_inicial<NEW.hora_final)) or                                        
					( (hora_inicial > NEW.hora_inicial) and (hora_final<NEW.hora_final))                                        
				) into vcount2;
			IF (vcount1 = 0 and vcount2 > 1) THEN      
				RAISE EXCEPTION 'Error, el aula indicada ya está ocupada en este horario el día %', vexcesohoras;
			END IF;
		END IF;
		RETURN NEW;
	ELSE
		RETURN NEW;
	END IF;
END
$$;


ALTER FUNCTION "ITE".alta_horario() OWNER TO amaterasu;

--
-- Name: alta_materia(); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".alta_materia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
IF EXISTS(SELECT 1 FROM "ITE".historia_alumno HA WHERE HA.no_de_control=NEW.no_de_control AND HA.materia=NEW.materia AND HA.calificacion>=70)THEN
    RAISE EXCEPTION 'El estudiante ya tiene acreditada la materia ';
    ROLLBACK;
    RETURN NULL;
END IF;
RETURN NEW;
END;$$;


ALTER FUNCTION "ITE".alta_materia() OWNER TO amaterasu;

--
-- Name: calificaciones(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".calificaciones(periodo_checar character varying, control character varying, OUT mater "ITE"."T_materia", OUT nombre character varying, OUT cal smallint, OUT tipo character, OUT descripcion character varying, OUT credit smallint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
DECLARE 
reg RECORD;
BEGIN
	FOR reg IN SELECT HA.materia,nombre_completo_materia, calificacion,HA.tipo_evaluacion, 
descripcion_evaluacion,creditos_materia
FROM 
historia_alumno HA, alumnos A, materias_carreras MC, materias M,tipos_evaluacion TE
WHERE 
HA.no_de_control=control AND HA.no_de_control=A.no_de_control
AND A.carrera=MC.carrera
AND A.reticula=MC.reticula
AND MC.materia=M.materia
AND HA.materia=MC.materia
AND HA.tipo_evaluacion=TE.tipo_evaluacion
AND A.plan_de_estudios=TE.plan_de_estudios
AND HA.periodo=periodo_checar LOOP
mater:=reg.materia;
nombre:=reg.nombre_completo_materia;
cal:=reg.calificacion;
tipo:=reg.tipo_evaluacion;
descripcion:=reg.descripcion_evaluacion;
credit:=reg.creditos_materia;
RETURN NEXT;
END LOOP;
RETURN;
END
$$;


ALTER FUNCTION "ITE".calificaciones(periodo_checar character varying, control character varying, OUT mater "ITE"."T_materia", OUT nombre character varying, OUT cal smallint, OUT tipo character, OUT descripcion character varying, OUT credit smallint) OWNER TO amaterasu;

--
-- Name: cmaterias(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".cmaterias(control character varying, OUT cve_mat character varying, OUT nmat character varying) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
DECLARE 
reg RECORD;
BEGIN
	FOR reg IN SELECT M.materia,nombre_completo_materia
FROM 
	alumnos A, materias_carreras MC, materias M
WHERE 
A.no_de_control=control
AND A.carrera=MC.carrera
AND A.reticula=MC.reticula
AND MC.materia=M.materia
ORDER BY nombre_completo_materia
LOOP
cve_mat:=reg.materia;
nmat:=reg.nombre_completo_materia;
RETURN NEXT;
END LOOP;
RETURN;
END
$$;


ALTER FUNCTION "ITE".cmaterias(control character varying, OUT cve_mat character varying, OUT nmat character varying) OWNER TO amaterasu;

--
-- Name: cruce_horario(character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".cruce_horario(peri character varying, mat character varying, gpo character varying, doc character varying, dia integer, OUT cruce integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
hora_inicio time without time zone;
hora_fin time without time zone;
BEGIN
select hora_inicial from horarios where periodo = peri 
and materia = mat and grupo=gpo and dia_semana = dia into hora_inicio;
select hora_final from horarios where periodo = peri 
and materia = mat and grupo=gpo and dia_semana = dia into hora_fin;
select count(*) from horarios where periodo = peri    
and rfc = doc and (rfc is not null or rfc<>'') and dia_semana = dia
and (hora_inicial=hora_inicio  
or ((hora_inicial < hora_inicio) and (hora_inicio < hora_final))  
or ((hora_inicial < hora_fin) and (hora_fin < hora_final) ) 
or ((hora_inicio < hora_inicial) and (hora_inicial < hora_fin)) 
or ((hora_inicial > hora_inicio) and (hora_final < hora_fin))) into cruce;
END
$$;


ALTER FUNCTION "ITE".cruce_horario(peri character varying, mat character varying, gpo character varying, doc character varying, dia integer, OUT cruce integer) OWNER TO amaterasu;

--
-- Name: evl_omitir_mat_alu(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".evl_omitir_mat_alu(peri character varying, control character varying) RETURNS TABLE(materia "ITE"."T_materia", grupo character)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY SELECT DISTINCT(SM.materia),SM.grupo 
	from "ITE".seleccion_materias SM, "ITE".alumnos A,
	"ITE".materias_carreras MC,"ITE".materias M 
	WHERE SM.no_de_control=control and SM.periodo=peri 
	and SM.no_de_control=A.no_de_control 
	AND A.carrera=MC.carrera AND A.reticula=MC.reticula 
	AND SM.materia=MC.materia AND M.materia=SM.materia 
	AND M.nombre_abreviado_materia NOT LIKE 'RESIDENCIA%'
	AND M.materia NOT IN 
	(SELECT EA.materia FROM "ITE".evaluacion_alumnos EA 
	 WHERE EA.no_de_control=control AND EA.periodo=peri);
END
$$;


ALTER FUNCTION "ITE".evl_omitir_mat_alu(peri character varying, control character varying) OWNER TO amaterasu;

--
-- Name: horario(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".horario(control character varying, periodo_checar character varying, OUT mater character varying, OUT gpo character varying, OUT docente character varying, OUT nombre character varying, OUT credit smallint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
DECLARE 
reg RECORD;
BEGIN
	FOR reg IN SELECT SM.materia,SM.grupo,apellidos_empleado,nombre_empleado,
	nombre_completo_materia,creditos_materia
FROM 
seleccion_materias SM, alumnos A, materias_carreras MC, materias M, grupos G, personal P
WHERE 
SM.no_de_control=control AND SM.no_de_control=A.no_de_control
AND SM.periodo=periodo_checar
AND A.carrera=MC.carrera
AND A.reticula=MC.reticula
AND MC.materia=M.materia
AND SM.materia=MC.materia
AND SM.periodo=G.periodo
AND SM.materia=G.materia
AND SM.grupo=G.grupo
AND G.rfc=P.rfc
 LOOP
mater:=reg.materia;
gpo:=reg.grupo;
docente:=CONCAT(reg.apellidos_empleado,' ',reg.nombre_empleado);
nombre:=reg.nombre_completo_materia;
credit:=reg.creditos_materia;
RETURN NEXT;
END LOOP;
RETURN;
END
$$;


ALTER FUNCTION "ITE".horario(control character varying, periodo_checar character varying, OUT mater character varying, OUT gpo character varying, OUT docente character varying, OUT nombre character varying, OUT credit smallint) OWNER TO amaterasu;

--
-- Name: pac_act_ins_gpoxmat(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_act_ins_gpoxmat(peri character varying) RETURNS smallint
    LANGUAGE plpgsql
    AS $$
DECLARE
inscritos smallint;
rec record;

BEGIN
   --Se leen los datos
    FOR rec IN SELECT DISTINCT(G.materia), G.grupo FROM "ITE".grupos G WHERE G.periodo=peri
    LOOP
        --Obtener materias y grupos
        SELECT COUNT(DISTINCT(SM.no_de_control)) FROM "ITE".seleccion_materias SM WHERE SM.periodo=peri AND SM.materia=rec.materia
        AND SM.grupo=rec.grupo INTO inscritos;
        --Actualizar
        UPDATE "ITE".grupos SET alumnos_inscritos=inscritos WHERE periodo=peri AND materia=rec.materia
        AND grupo=rec.grupo;
    END LOOP;
    RETURN 1 AS terminado;	
	
END

$$;


ALTER FUNCTION "ITE".pac_act_ins_gpoxmat(peri character varying) OWNER TO amaterasu;

--
-- Name: pac_actas_faltan(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_actas_faltan(peri character varying) RETURNS TABLE(materia "ITE"."T_materia", grupo character, apellidos_empleado character, nombre_empleado character, nombre_abreviado_materia character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
	  

    RETURN QUERY SELECT DISTINCT(G.materia),G.grupo, P.apellidos_empleado,P.nombre_empleado,M.nombre_abreviado_materia 
FROM "ITE".grupos G, "ITE".horarios H, "ITE".personal P, "ITE".materias M
WHERE G.periodo=peri 
AND G.materia=H.materia AND G.grupo=H.grupo
AND H.periodo=G.periodo AND H.rfc=P.rfc
AND G.materia=M.materia
AND G.entrego=false
ORDER BY apellidos_empleado,nombre_empleado, nombre_abreviado_materia; 
	
	
END

$$;


ALTER FUNCTION "ITE".pac_actas_faltan(peri character varying) OWNER TO amaterasu;

--
-- Name: pac_alumnos_faltan_ev(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_alumnos_faltan_ev(peri character varying, carr character varying) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", nombre_reducido character varying, apellido_paterno "ITE"."T_apellidos_persona", apellido_materno "ITE"."T_apellidos_persona", nombre_alumno character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
	IF carr='T' THEN
        RETURN QUERY SELECT DISTINCT(SM.no_de_control), C.nombre_reducido, A.apellido_paterno, A.apellido_materno, A.nombre_alumno 
        FROM "ITE".alumnos A, "ITE".carreras C, "ITE".seleccion_materias SM 
        WHERE SM.no_de_control=A.no_de_control AND SM.periodo=peri AND 
        A.carrera=C.carrera AND A.reticula=C.reticula AND A.nivel_escolar='L'
        AND SM.no_de_control NOT IN(SELECT DISTINCT(EA.no_de_control) FROM "ITE".evaluacion_alumnos EA WHERE periodo=peri)
	    ORDER BY nombre_reducido,apellido_paterno,apellido_materno,nombre_alumno; 
    ELSE
        RETURN QUERY SELECT DISTINCT(SM.no_de_control), C.nombre_reducido, A.apellido_paterno, A.apellido_materno, A.nombre_alumno 
        FROM "ITE".alumnos A, "ITE".carreras C, "ITE".seleccion_materias SM 
        WHERE SM.no_de_control=A.no_de_control AND SM.periodo=peri AND 
        A.carrera=carr AND A.carrera=C.carrera AND A.reticula=C.reticula
        AND SM.no_de_control NOT IN(SELECT DISTINCT(EA.no_de_control) FROM "ITE".evaluacion_alumnos EA WHERE periodo=peri)
	    ORDER BY nombre_reducido,apellido_paterno,apellido_materno,nombre_alumno;
	END IF;
END

$$;


ALTER FUNCTION "ITE".pac_alumnos_faltan_ev(peri character varying, carr character varying) OWNER TO amaterasu;

--
-- Name: pac_calcula_totales_alumno(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_calcula_totales_alumno(control character varying) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", creditos_totales smallint, clave_oficial character, creditos_aprobados bigint, creditos_aprobados2 bigint, promedio numeric, periodo_final text)
    LANGUAGE plpgsql
    AS $$

BEGIN
	
    RETURN QUERY SELECT A.no_de_control, C.creditos_totales, C.clave_oficial, sum(MC.creditos_materia) as creditos_aprobados,
sum(MC.creditos_materia) as creditos_aprobados2, avg(HA.calificacion)::numeric(10,2) as promedio, max(HA.periodo) as periodo_final  
   from "ITE".historia_alumno HA, "ITE".alumnos A, "ITE".materias_carreras MC, "ITE".carreras C, "ITE".materias M   
  where HA.no_de_control = control   
    and HA.calificacion >= 60   
    and HA.no_de_control = A.no_de_control   
   and A.carrera = C.carrera and A.reticula = C.reticula   
   and HA.materia = M.materia   
   and A.carrera = MC.carrera and A.reticula = MC.reticula and HA.materia = MC.materia   
   and M.tipo_materia <> 4   
  group by A.no_de_control, C.creditos_totales, C.clave_oficial;

END

$$;


ALTER FUNCTION "ITE".pac_calcula_totales_alumno(control character varying) OWNER TO amaterasu;

--
-- Name: pac_calificacion_semestre(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_calificacion_semestre(control character varying, peri character varying) RETURNS TABLE(materia "ITE"."T_materia", grupo character, nombre_abreviado_materia character varying, creditos_materia smallint, calificacion "ITE"."T_calificacion")
    LANGUAGE plpgsql
    AS $$

BEGIN
	
    RETURN QUERY SELECT DISTINCT(SM.materia),SM.grupo,M.nombre_abreviado_materia, MC.creditos_materia,SM.calificacion
FROM "ITE".seleccion_materias SM, "ITE".materias M, "ITE".materias_carreras MC, "ITE".alumnos A
WHERE A.no_de_control=control 
AND A.no_de_control=SM.no_de_control
AND SM.materia=M.materia
AND MC.materia=M.materia
AND MC.carrera=A.carrera
AND MC.reticula=A.reticula
AND SM.periodo=peri;

END

$$;


ALTER FUNCTION "ITE".pac_calificacion_semestre(control character varying, peri character varying) OWNER TO amaterasu;

--
-- Name: pac_calificaciones(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_calificaciones(control character varying, peri character varying) RETURNS TABLE(tipo_materia smallint, clave character, nombre_completo_materia character varying, nombre_abreviado_materia character varying, periodo "ITE"."T_periodo", no_de_control "ITE"."T_no_de_control", materia "ITE"."T_materia", grupo character, calificacion "ITE"."T_calificacion", tipo_evaluacion character, fecha_calificacion timestamp without time zone, plan_de_estudios character, estatus_materia character, nopresento character, creditos_materia smallint, descripcion_corta_evaluacion character varying, identificacion_corta character)
    LANGUAGE plpgsql
    AS $$
BEGIN
	CREATE TEMPORARY TABLE histo AS
	SELECT historia_alumno.periodo, historia_alumno.no_de_control, historia_alumno.materia, 
	historia_alumno.grupo, historia_alumno.calificacion, historia_alumno.tipo_evaluacion, 
	historia_alumno.fecha_calificacion, historia_alumno.plan_de_estudios, 
	historia_alumno.estatus_materia, historia_alumno.nopresento,historia_alumno.usuario, 
	historia_alumno.fecha_actualizacion, historia_alumno.periodo_acredita_materia 
	FROM "ITE".historia_alumno WHERE historia_alumno.no_de_control=control AND historia_alumno.periodo=peri;
 
	RETURN QUERY
	SELECT DISTINCT(M.tipo_materia), MC.clave_oficial_materia as clave, M.nombre_completo_materia, 
	M.nombre_abreviado_materia, H.periodo, H.no_de_control, H.materia, 
	H.grupo, H.calificacion, H.tipo_evaluacion, H.fecha_calificacion as fecha_calificacion, 
	H.plan_de_estudios, H.estatus_materia, H.nopresento, MC.creditos_materia, 
	TE.descripcion_corta_evaluacion, PE.identificacion_corta 
 	FROM histo H, "ITE".materias M, "ITE".materias_carreras MC, "ITE".tipos_evaluacion TE, "ITE".alumnos A, "ITE".periodos_escolares PE 
 where H.materia=M.materia 
 and H.no_de_control=A.no_de_control 
 and A.carrera=MC.carrera and A.reticula=MC.reticula and H.materia=MC.materia 
 and H.tipo_evaluacion=TE.tipo_evaluacion 
 and A.plan_de_estudios=TE.plan_de_estudios 
 and H.periodo=PE.periodo 
 ORDER BY clave;

	DROP TABLE histo;

END
$$;


ALTER FUNCTION "ITE".pac_calificaciones(control character varying, peri character varying) OWNER TO amaterasu;

--
-- Name: pac_certificado_cal(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_certificado_cal(control character varying) RETURNS TABLE(nombre_completo_materia character varying, periodo "ITE"."T_periodo", no_de_control "ITE"."T_no_de_control", materia "ITE"."T_materia", grupo character, calificacion "ITE"."T_calificacion", tipo_evaluacion character, fecha_calificacion timestamp without time zone, plan_de_estudios character, estatus_materia character, nopresento character, periodo_acrdita_materia "ITE"."T_periodo", creditos_materia smallint, orden_certificado smallint)
    LANGUAGE plpgsql
    AS $$
BEGIN
	CREATE TEMPORARY TABLE histo AS
	SELECT historia_alumno.periodo, historia_alumno.no_de_control, historia_alumno.materia, historia_alumno.grupo, historia_alumno.calificacion, historia_alumno.tipo_evaluacion, historia_alumno.fecha_calificacion, historia_alumno.plan_de_estudios, historia_alumno.estatus_materia, historia_alumno.nopresento,historia_alumno.usuario, historia_alumno.fecha_actualizacion, historia_alumno.periodo_acredita_materia 
	FROM "ITE".historia_alumno WHERE historia_alumno.no_de_control=control and historia_alumno.calificacion>=60;
 
	RETURN QUERY
	SELECT DISTINCT(M.nombre_completo_materia),H.periodo, H.no_de_control, M.materia, H.grupo, H.calificacion, H.tipo_evaluacion, H.fecha_calificacion as fecha_calificacion, H.plan_de_estudios, H.estatus_materia, H.nopresento, H.periodo_acredita_materia ,MC.creditos_materia, MC.orden_certificado
 	FROM histo H, "ITE".materias M, "ITE".materias_carreras MC, "ITE".alumnos A
 where H.no_de_control=A.no_de_control 
 and A.carrera=MC.carrera and A.reticula=MC.reticula and H.materia=MC.materia 
 and H.materia=M.materia
 and MC.creditos_materia>0
 ORDER BY M.nombre_completo_materia, MC.orden_certificado, M.materia;

	DROP TABLE histo;

END
$$;


ALTER FUNCTION "ITE".pac_certificado_cal(control character varying) OWNER TO amaterasu;

--
-- Name: pac_constancias(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_constancias(control character varying) RETURNS TABLE(periodo "ITE"."T_periodo", materia "ITE"."T_materia", n_materia character varying, n_materia_r character varying, calificacion "ITE"."T_calificacion", tipo_evaluacion character, creditos integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
rec record;

BEGIN
	SELECT carrera FROM "ITE".alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM "ITE".alumnos WHERE no_de_control=control into reti;

	CREATE TEMP TABLE IF NOT EXISTS materias_alumno AS
	select h.periodo, h.materia, m.nombre_completo_materia as n_materia, m.nombre_abreviado_materia as n_materia_r, h.calificacion, h.tipo_evaluacion, 0 as creditos, 0 as orden_certificado
    FROM "ITE".historia_alumno h
	LEFT JOIN "ITE".materias m
	ON (h.materia =m.materia)
    WHERE h.no_de_control=control and h.calificacion!=0;
	
    FOR rec IN SELECT mc.materia,mc.creditos_materia,mc.orden_certificado FROM "ITE".materias_carreras mc WHERE mc.carrera = carre and mc.reticula = reti	
    LOOP
        UPDATE materias_alumno
        SET creditos = rec.creditos_materia, orden_certificado = rec.orden_certificado
        WHERE materias_alumno.materia=rec.materia;
    END LOOP;

    RETURN QUERY SELECT ma.periodo, ma.materia, ma.n_materia, ma.n_materia_r, ma.calificacion, ma.tipo_evaluacion, ma.creditos
	FROM materias_alumno ma
    ORDER by periodo;

	DROP TABLE materias_alumno; 
END

$$;


ALTER FUNCTION "ITE".pac_constancias(control character varying) OWNER TO amaterasu;

--
-- Name: pac_constancias_kardex(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_constancias_kardex(control character varying) RETURNS TABLE(periodo "ITE"."T_periodo", materia "ITE"."T_materia", n_materia character varying, n_materia_r character varying, calificacion "ITE"."T_calificacion", tipo_evaluacion character, creditos integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
rec record;

BEGIN
	SELECT carrera FROM "ITE".alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM "ITE".alumnos WHERE no_de_control=control into reti;

	CREATE TEMP TABLE IF NOT EXISTS materias_alumno AS
	select h.periodo, h.materia, m.nombre_completo_materia as n_materia, m.nombre_abreviado_materia as n_materia_r, h.calificacion, h.tipo_evaluacion, 0 as creditos, 0 as orden_certificado
    FROM "ITE".historia_alumno h
	LEFT JOIN "ITE".materias m
	ON (h.materia =m.materia)
    WHERE h.no_de_control=control;
	
    FOR rec IN SELECT mc.materia,mc.creditos_materia,mc.orden_certificado FROM "ITE".materias_carreras mc WHERE mc.carrera = carre and mc.reticula = reti	
    LOOP
        UPDATE materias_alumno
        SET creditos = rec.creditos_materia, orden_certificado = rec.orden_certificado
        WHERE materias_alumno.materia=rec.materia;
    END LOOP;

    RETURN QUERY SELECT ma.periodo, ma.materia, ma.n_materia, ma.n_materia_r, ma.calificacion, ma.tipo_evaluacion, ma.creditos
	FROM materias_alumno ma
    ORDER by periodo;

	DROP TABLE materias_alumno; 
END

$$;


ALTER FUNCTION "ITE".pac_constancias_kardex(control character varying) OWNER TO amaterasu;

--
-- Name: pac_cresidencias("ITE"."T_periodo", character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_cresidencias(per "ITE"."T_periodo", quien character varying, OUT cantidad integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
select count(*) from "ITE".seleccion_materias, "ITE".materias, "ITE".grupos
	WHERE nombre_abreviado_materia LIKE 'RESIDENCIA%' 
	AND materias.materia=grupos.materia
	AND grupos.periodo=per
	AND seleccion_materias.periodo=grupos.periodo
	AND seleccion_materias.materia=grupos.materia
	AND seleccion_materias.grupo=grupos.grupo
	AND grupos.rfc=quien into cantidad;
END
$$;


ALTER FUNCTION "ITE".pac_cresidencias(per "ITE"."T_periodo", quien character varying, OUT cantidad integer) OWNER TO amaterasu;

--
-- Name: pac_dataresidencias(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_dataresidencias(peri character varying, quien character varying) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", apellido_paterno "ITE"."T_apellidos_persona", apellido_materno "ITE"."T_apellidos_persona", nombre_alumno character varying, plan_de_estudios character, calificacion "ITE"."T_calificacion", materia "ITE"."T_materia", grupo character)
    LANGUAGE plpgsql
    AS $$
BEGIN
	
    -- Obtener informacion de residencias
	CREATE TEMP TABLE IF NOT EXISTS info_grupos AS 
	SELECT seleccion_materias.no_de_control, alumnos.apellido_paterno, alumnos.apellido_materno, alumnos.nombre_alumno,
    alumnos.plan_de_estudios, seleccion_materias.calificacion, seleccion_materias.materia, seleccion_materias.grupo FROM
    "ITE".seleccion_materias, "ITE".materias, "ITE".grupos, "ITE".alumnos
	WHERE nombre_abreviado_materia LIKE 'RESIDENCIA%' 
	AND materias.materia=grupos.materia
	AND grupos.periodo=peri
	AND seleccion_materias.periodo=grupos.periodo
	AND seleccion_materias.materia=grupos.materia
	AND seleccion_materias.grupo=grupos.grupo
	AND grupos.rfc=quien
	AND seleccion_materias.no_de_control=alumnos.no_de_control
	ORDER BY apellido_paterno,apellido_materno,nombre_alumno;

    RETURN QUERY SELECT info_grupos.no_de_control, info_grupos.apellido_paterno, info_grupos.apellido_materno, info_grupos.nombre_alumno, info_grupos.plan_de_estudios, info_grupos.calificacion, info_grupos.materia,info_grupos.grupo 
    FROM info_grupos;

	DROP TABLE info_grupos;
	
	
END
$$;


ALTER FUNCTION "ITE".pac_dataresidencias(peri character varying, quien character varying) OWNER TO amaterasu;

--
-- Name: pac_docentes_faltan_ev(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_docentes_faltan_ev(peri character varying) RETURNS TABLE(rfc character, apellidos_empleado character, nombre_empleado character)
    LANGUAGE plpgsql
    AS $$

BEGIN
        RETURN QUERY SELECT DISTINCT(G.rfc), P.apellidos_empleado, P.nombre_empleado 
        FROM "ITE".grupos G, "ITE".personal P
        WHERE G.periodo=peri AND G.rfc=P.rfc AND G.rfc NOT IN (
                                        SELECT DISTINCT(EA.rfc) FROM "ITE".evaluacion_alumnos EA WHERE EA.periodo=peri) 
        ORDER BY apellidos_empleado, nombre_empleado;
END

$$;


ALTER FUNCTION "ITE".pac_docentes_faltan_ev(peri character varying) OWNER TO amaterasu;

--
-- Name: pac_edades(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_edades(peri character varying, genero character varying) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", edad double precision, semestre smallint)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY SELECT distinct(SM.no_de_control), date_part('year',current_date)-date_part('year',fecha_nacimiento) as edad, 
A.semestre FROM "ITE".alumnos A, "ITE".seleccion_materias SM WHERE SM.periodo=peri and sexo=genero 
and SM.no_de_control=A.no_de_control;
END
$$;


ALTER FUNCTION "ITE".pac_edades(peri character varying, genero character varying) OWNER TO amaterasu;

--
-- Name: pac_edades_carrera(character varying, character varying, character, smallint); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_edades_carrera(peri character varying, genero character varying, carr character, reti smallint) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", edad double precision, semestre smallint)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY SELECT distinct(SM.no_de_control), date_part('year',current_date)-date_part('year',fecha_nacimiento) as edad, 
A.semestre FROM "ITE".alumnos A, "ITE".seleccion_materias SM WHERE SM.periodo=peri and sexo=genero and carrera=carr and reticula=reti 
and SM.no_de_control=A.no_de_control;
END
$$;


ALTER FUNCTION "ITE".pac_edades_carrera(peri character varying, genero character varying, carr character, reti smallint) OWNER TO amaterasu;

--
-- Name: pac_edades_estado(character varying, character varying, character, smallint, character); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_edades_estado(peri character varying, genero character varying, carr character, reti smallint, edo character) RETURNS TABLE(no_de_control "ITE"."T_no_de_control", edad double precision, semestre smallint)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY SELECT distinct(SM.no_de_control), date_part('year',current_date)-date_part('year',fecha_nacimiento) as edad, 
A.semestre FROM "ITE".alumnos A, "ITE".seleccion_materias SM WHERE SM.periodo=peri and sexo=genero and carrera=carr and reticula=reti and entidad_procedencia=edo 
and SM.no_de_control=A.no_de_control;
END
$$;


ALTER FUNCTION "ITE".pac_edades_estado(peri character varying, genero character varying, carr character, reti smallint, edo character) OWNER TO amaterasu;

--
-- Name: pac_eval_carr_ret("ITE"."T_periodo", smallint, "ITE"."T_carrera", integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_eval_carr_ret(peri "ITE"."T_periodo", preg smallint, carr "ITE"."T_carrera", ret integer) RETURNS TABLE(respuesta text, cantidad bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE

BEGIN
	
	CREATE TEMP TABLE IF NOT EXISTS evlR0 AS
	SELECT SUBSTRING(EA.respuestas,preg,1) AS respuesta
    FROM "ITE".evaluacion_alumnos EA, "ITE".materias_carreras MC
    WHERE EA.periodo=peri AND EA.encuesta='A' AND EA.materia=MC.materia AND MC.carrera=carr AND MC.reticula=ret;
	
    RETURN QUERY SELECT DISTINCT(EV.respuesta) AS respuesta, COUNT(EV.respuesta) AS cantidad
	FROM evlR0 EV
    GROUP BY EV.respuesta;

	DROP TABLE evlR0; 
END

$$;


ALTER FUNCTION "ITE".pac_eval_carr_ret(peri "ITE"."T_periodo", preg smallint, carr "ITE"."T_carrera", ret integer) OWNER TO amaterasu;

--
-- Name: pac_eval_depto("ITE"."T_periodo", smallint, character, integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_eval_depto(peri "ITE"."T_periodo", preg smallint, depto character, tamanio integer) RETURNS TABLE(respuesta text, cantidad bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE

BEGIN
	
	CREATE TEMP TABLE IF NOT EXISTS evlR0 AS
	SELECT SUBSTRING(EA.respuestas,preg,1) AS respuesta
    FROM "ITE".evaluacion_alumnos EA, "ITE".materias_carreras MC
    WHERE EA.periodo=peri AND EA.encuesta='A' AND EA.clave_area=depto AND char_length(respuestas)=tamanio;
	
    RETURN QUERY SELECT DISTINCT(EV.respuesta) AS respuesta, COUNT(EV.respuesta) AS cantidad
	FROM evlR0 EV
    GROUP BY EV.respuesta;

	DROP TABLE evlR0; 
END

$$;


ALTER FUNCTION "ITE".pac_eval_depto(peri "ITE"."T_periodo", preg smallint, depto character, tamanio integer) OWNER TO amaterasu;

--
-- Name: pac_eval_docente("ITE"."T_periodo", smallint, "ITE"."T_materia", character); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_eval_docente(peri "ITE"."T_periodo", preg smallint, mater "ITE"."T_materia", gpo character) RETURNS TABLE(respuesta text, cantidad bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE

BEGIN
	
	CREATE TEMP TABLE IF NOT EXISTS evlR10 AS
	SELECT SUBSTRING(EA.respuestas,preg,1) AS respuesta
    FROM "ITE".evaluacion_alumnos EA
    WHERE EA.periodo=peri AND EA.encuesta='A' AND EA.materia=mater AND EA.grupo=gpo;
	
    RETURN QUERY SELECT DISTINCT(EV.respuesta) AS respuesta, COUNT(EV.respuesta) AS cantidad
	FROM evlR10 EV
    GROUP BY EV.respuesta;

	DROP TABLE evlR10; 
END

$$;


ALTER FUNCTION "ITE".pac_eval_docente(peri "ITE"."T_periodo", preg smallint, mater "ITE"."T_materia", gpo character) OWNER TO amaterasu;

--
-- Name: pac_evl_docente(character varying, character varying, smallint); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_evl_docente(peri character varying, doc character varying, tamanio smallint) RETURNS TABLE(nombre_completo_materia character varying, materia "ITE"."T_materia", grupo character, alumnos_inscritos smallint, paralelo_de character, evaluaron smallint)
    LANGUAGE plpgsql
    AS $$DECLARE
rec record;
evaluaron integer:=0;
BEGIN
-- Se crea la tabla de las materias
	CREATE TEMPORARY TABLE evlM0(
    materia character varying, 
    grupo character(3), 
    paralelo_de character varying,
    evaluados smallint
    );

	FOR rec IN SELECT DISTINCT(G.materia),G.grupo,G.paralelo_de
	FROM "ITE".grupos G,"ITE".evaluacion_alumnos EA, "ITE".materias M
	WHERE G.periodo=peri AND G.rfc=doc AND G.rfc=EA.rfc 
    AND EA.encuesta='A' AND length(EA.respuestas) = tamanio
    AND EA.materia=M.materia AND EA.materia=G.materia 
    AND M.nombre_abreviado_materia NOT LIKE 'RESIDENCIA%'
    LOOP
        SELECT COUNT(*) FROM "ITE".evaluacion_alumnos EA
        WHERE EA.periodo=peri and EA.materia=rec.materia and EA.grupo=rec.grupo and length(EA.respuestas)=tamanio INTO evaluaron;
--Almacenar
        INSERT INTO evlM0(materia,grupo,paralelo_de,evaluados) VALUES (rec.materia,rec.grupo,rec.paralelo_de,evaluaron);
    END LOOP;

        RETURN QUERY SELECT M.nombre_completo_materia,G.materia,G.grupo,G.alumnos_inscritos,G.paralelo_de,E.evaluados 
		FROM "ITE".grupos G, "ITE".materias M, evlM0 E  
		WHERE G.periodo=peri AND G.materia=E.materia AND G.grupo=E.grupo AND G.materia=M.materia ORDER BY paralelo_de DESC;

	    DROP TABLE evlM0;
END

$$;


ALTER FUNCTION "ITE".pac_evl_docente(peri character varying, doc character varying, tamanio smallint) OWNER TO amaterasu;

--
-- Name: pac_gruposmateria(character varying, character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_gruposmateria(peri character varying, control character varying, mater character varying) RETURNS TABLE(grupo character, capacidad_grupo smallint, alumnos_inscritos smallint, rfc character, nombre_abreviado_materia character varying, paralelo_de character)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
especiales smallint;
seleccionadas smallint;
ofertadas smallint;
diferencia smallint;

BEGIN
	SELECT carrera FROM "ITE".alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM "ITE".alumnos WHERE no_de_control=control into reti;
	
    -- Obtener materias en especial acreditadas
	CREATE TEMP TABLE IF NOT EXISTS info_grupos AS 
	SELECT G.grupo, G.capacidad_grupo, G.alumnos_inscritos, G.rfc, M.nombre_abreviado_materia, G.paralelo_de 
    FROM "ITE".grupos G, "ITE".materias M 
    WHERE G.periodo=peri AND G.materia=mater AND M.materia=mater AND exclusivo_carrera=carre AND exclusivo_reticula=reti
    UNION
    SELECT G.grupo, G.capacidad_grupo, G.alumnos_inscritos, G.rfc, M.nombre_abreviado_materia, G.paralelo_de 
    FROM "ITE".grupos G, "ITE".materias M 
    WHERE G.periodo=peri AND G.materia=mater AND M.materia=mater AND G.exclusivo='no';  
  

    RETURN QUERY SELECT info_grupos.grupo, info_grupos.capacidad_grupo, info_grupos.alumnos_inscritos, info_grupos.rfc, info_grupos.nombre_abreviado_materia, info_grupos.paralelo_de 
    FROM info_grupos;

	DROP TABLE info_grupos;
	
	
END
$$;


ALTER FUNCTION "ITE".pac_gruposmateria(peri character varying, control character varying, mater character varying) OWNER TO amaterasu;

--
-- Name: pac_historia_escolar_alumno(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_historia_escolar_alumno(control character varying) RETURNS TABLE(tipo_materia smallint, clave character, nombre_completo_materia character varying, nombre_abreviado_materia character varying, periodo "ITE"."T_periodo", no_de_control "ITE"."T_no_de_control", materia "ITE"."T_materia", grupo character, calificacion "ITE"."T_calificacion", tipo_evaluacion character, fecha_calificacion timestamp without time zone, plan_de_estudios character, estatus_materia character, nopresento character, creditos_materia smallint, descripcion_corta_evaluacion character varying, identificacion_corta character)
    LANGUAGE plpgsql
    AS $$
BEGIN
	CREATE TEMPORARY TABLE histo AS
	SELECT historia_alumno.periodo, historia_alumno.no_de_control, historia_alumno.materia, historia_alumno.grupo, historia_alumno.calificacion, historia_alumno.tipo_evaluacion, historia_alumno.plan_de_estudios, historia_alumno.estatus_materia, historia_alumno.nopresento,historia_alumno.usuario,  historia_alumno.periodo_acredita_materia 
	FROM "ITE".historia_alumno WHERE historia_alumno.no_de_control=control;
 
	RETURN QUERY
	SELECT DISTINCT(M.tipo_materia), MC.clave_oficial_materia as clave, M.nombre_completo_materia, M.nombre_abreviado_materia, H.periodo, H.no_de_control, H.materia, H.grupo, H.calificacion, H.tipo_evaluacion, H.plan_de_estudios, H.estatus_materia, H.nopresento, MC.creditos_materia, TE.descripcion_corta_evaluacion, PE.identificacion_corta 
 	FROM histo H, "ITE".materias M, "ITE".materias_carreras MC, "ITE".tipos_evaluacion TE, "ITE".alumnos A, "ITE".periodos_escolares PE 
 where H.no_de_control=control 
 and H.materia=M.materia 
 and H.no_de_control=A.no_de_control 
 and A.carrera=MC.carrera and A.reticula=MC.reticula and H.materia=MC.materia 
 and H.tipo_evaluacion=TE.tipo_evaluacion 
 and A.plan_de_estudios=TE.plan_de_estudios 
 and H.periodo=PE.periodo 
 ORDER BY periodo;

	DROP TABLE histo;

END$$;


ALTER FUNCTION "ITE".pac_historia_escolar_alumno(control character varying) OWNER TO amaterasu;

--
-- Name: pac_horario(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_horario(control character varying, peri character varying) RETURNS TABLE(mat character varying, nmateria character varying, gpo character, ndocente character varying, creditos smallint)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
nmateria character varying;
nrfc character varying;
nombre_doc character varying;
credi smallint;
rec record;

BEGIN
	SELECT carrera FROM alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM alumnos WHERE no_de_control=control into reti;
	
    -- Se crea la tabla del horario
	CREATE TEMPORARY TABLE horario(
    mat character varying, 
    nmateria character varying, 
    gpo character(3), 
    ndocente character varying,
    creditos smallint
    );

   --Se leen los datos
    FOR rec IN SELECT materia, grupo FROM seleccion_materias WHERE periodo=peri AND no_de_control=control 
    LOOP
        --Obtener nombre materia
        SELECT materias.nombre_completo_materia FROM materias,materias_carreras WHERE materias_carreras.materia=materias.materia AND materias_carreras.carrera=carre 
        AND materias_carreras.reticula=reti AND materias_carreras.materia=rec.materia INTO nmateria;
        --Obtener nombre docente
        SELECT grupos.rfc FROM grupos WHERE grupos.periodo=peri AND grupos.materia=rec.materia AND grupos.grupo=rec.grupo INTO nrfc;
        IF nrfc IS NULL THEN
            SELECT CONCAT('PENDIENTE',' ','POR ASIGNAR') INTO nombre_doc;
        ELSE
            SELECT CONCAT(personal.apellidos_empleado,' ',personal.nombre_empleado) FROM personal WHERE rfc=nrfc INTO nombre_doc;
        END IF;
        --Creditos
        SELECT materias_carreras.creditos_materia FROM materias_carreras WHERE materias_carreras.materia=rec.materia 
        AND materias_carreras.carrera=carre AND materias_carreras.reticula=reti INTO credi;
        --Almacaner
        INSERT INTO horario(mat,nmateria,gpo,ndocente,creditos) VALUES (rec.materia, nmateria, rec.grupo, nombre_doc, credi);
    END LOOP;
    RETURN QUERY SELECT horario.mat, horario.nmateria, horario.gpo, horario.ndocente, horario.creditos FROM horario;
        

	DROP TABLE horario;		
	
	
END

$$;


ALTER FUNCTION "ITE".pac_horario(control character varying, peri character varying) OWNER TO amaterasu;

--
-- Name: pac_idiomas_consulta("ITE"."T_periodo", integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_idiomas_consulta(peri "ITE"."T_periodo", leng_ext integer) RETURNS TABLE(cve character varying, ncurso character varying, cantidad smallint)
    LANGUAGE plpgsql
    AS $$
DECLARE
inscritos smallint:=0;
rec record;

BEGIN
	
    -- Se crea la tabla del horario
	CREATE TEMPORARY TABLE inscritos_idiomas(
    cve character varying, 
    ncurso character varying, 
    cantidad smallint
    );

   --Se leen los datos
    FOR rec IN SELECT IG.id, IG.nombre_completo FROM idiomas_grupos IG WHERE IG.periodo=peri AND IG.idioma=leng_ext ORDER BY IG.nombre_completo
    LOOP
        --Creditos
        SELECT COUNT(*) FROM idiomas_inscripcion II WHERE II.periodo=peri AND II.idioma=leng_ext AND II.clave=rec.id INTO inscritos;
        --Almacaner
        INSERT INTO inscritos_idiomas(cve,ncurso,cantidad) VALUES (rec.id, rec.nombre_completo, inscritos);
    END LOOP;
    RETURN QUERY SELECT II.cve,II.ncurso,II.cantidad FROM inscritos_idiomas II;
	DROP TABLE inscritos_idiomas;		
	
	
END

$$;


ALTER FUNCTION "ITE".pac_idiomas_consulta(peri "ITE"."T_periodo", leng_ext integer) OWNER TO amaterasu;

--
-- Name: pac_materias_calificadas(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_materias_calificadas(peri character varying) RETURNS TABLE(materia "ITE"."T_materia", grupo character, apellidos_empleado character, nombre_empleado character, nombre_abreviado_materia character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
	  

    RETURN QUERY SELECT DISTINCT(SM.materia),SM.grupo, P.apellidos_empleado,P.nombre_empleado,M.nombre_abreviado_materia 
FROM "ITE".seleccion_materias SM, "ITE".horarios H, "ITE".personal P, "ITE".materias M
WHERE SM.periodo=peri and SM.calificacion IS NOT NULL
AND SM.materia=H.materia AND SM.grupo=H.grupo
AND SM.materia=M.materia
AND H.periodo=SM.periodo AND H.rfc=P.rfc
ORDER BY apellidos_empleado,nombre_empleado, nombre_abreviado_materia; 
	
	
END
$$;


ALTER FUNCTION "ITE".pac_materias_calificadas(peri character varying) OWNER TO amaterasu;

--
-- Name: pac_materias_faltan(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_materias_faltan(peri character varying) RETURNS TABLE(materia "ITE"."T_materia", grupo character, apellidos_empleado character, nombre_empleado character, nombre_abreviado_materia character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
	  

    RETURN QUERY SELECT DISTINCT(SM.materia),SM.grupo, P.apellidos_empleado,P.nombre_empleado,M.nombre_abreviado_materia 
FROM "ITE".seleccion_materias SM, "ITE".horarios H, "ITE".personal P, "ITE".materias M
WHERE SM.periodo=peri and SM.calificacion IS NULL
AND SM.materia=H.materia AND SM.grupo=H.grupo
AND SM.materia=M.materia
AND H.periodo=SM.periodo AND H.rfc=P.rfc
ORDER BY apellidos_empleado,nombre_empleado, nombre_abreviado_materia; 
	
	
END
$$;


ALTER FUNCTION "ITE".pac_materias_faltan(peri character varying) OWNER TO amaterasu;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: periodos_escolares; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".periodos_escolares (
    periodo "ITE"."T_periodo" NOT NULL,
    identificacion_larga character(30) NOT NULL,
    identificacion_corta character(12),
    fecha_inicio date,
    fecha_termino date,
    inicio_vacacional_ss date,
    fin_vacacional_ss date,
    inicio_especial date,
    fin_especial date,
    cierre_horarios character(1),
    cierre_seleccion character(1),
    inicio_sele_alumnos date,
    fin_sele_alumnos date,
    inicio_vacacional date,
    termino_vacacional date,
    inicio_cal_docentes date,
    fin_cal_docentes date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    ccarrera smallint
);


ALTER TABLE "ITE".periodos_escolares OWNER TO amaterasu;

--
-- Name: pac_periodo_actual(); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_periodo_actual() RETURNS SETOF "ITE".periodos_escolares
    LANGUAGE plpgsql
    AS $$
DECLARE
	mes smallint;
	dia smallint;
	anio int;
	perio character(5);
BEGIN
	SELECT date_part('month',now()) into mes; 
	SELECT date_part('day',  now()) into dia;
	SELECT date_part('year', now()) into anio;
	IF mes BETWEEN 2 and 6 THEN
 		SELECT concat(anio,'1') into perio;
	--inicio de agosto-diciembre en el mes de agosto	
	ELSIF (mes=7 or(mes=8 and dia<=15)) THEN -- ESTA ES LA LINEA ORIGINAL: @mes=7 or (@mes=8 and @dia <=3) 
 		SELECT concat(anio,'2') into perio; 
 	ELSE
 		IF mes between 8 and 12 THEN -- ESTA ES LA LINEA ORIGINAL: @mes between 8 and 12 
 			IF mes=12 and dia>=22 THEN --dia de diciembre en que inicia el periodo Enero-Junio
 				SELECT concat(anio+1,'1') into perio; -- tecmina
 			ELSE
 				SELECT concat(anio,'3') into perio; 
			END IF;
 		ELSE 
 			IF mes=1 THEN
			--dia para determinar inicio de periodo1 del mes 01
 				IF dia <=14 THEN
 					SELECT concat(anio-1,'3') into perio;
 				ELSE 
 					SELECT concat(anio,'1') into perio;
				END IF;
 			ELSE
 			--dia para determinar inicio de verano del mes 06
 				IF dia < 27 THEN
 					SELECT concat(anio,'1') into perio;
 				ELSE 
 					SELECT concat(anio,'2') into perio;
				END IF;
			END IF;
		END IF;
	END IF;
	RETURN QUERY SELECT * FROM "ITE".periodos_escolares WHERE periodo=perio; 
	RETURN;
END;
$$;


ALTER FUNCTION "ITE".pac_periodo_actual() OWNER TO amaterasu;

--
-- Name: pac_poblacion(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_poblacion(peri character varying) RETURNS TABLE(carrera character varying, reticula smallint, ncarrera character varying, cantidad integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
cantidad int;
rec record;
BEGIN
    
    CREATE TEMPORARY TABLE poblacion(
        carrera character varying, 
        reticula smallint, 
        ncarrera character varying, 
        cantidad int
    );
 
    FOR rec IN
        SELECT carreras.carrera, carreras.reticula, carreras.nombre_carrera FROM carreras
    LOOP
        SELECT COUNT(DISTINCT(SM.no_de_control)) FROM seleccion_materias SM, alumnos A
        WHERE SM.no_de_control=A.no_de_control AND SM.periodo=peri AND A.carrera=rec.carrera
        AND A.reticula=rec.reticula INTO cantidad;
        IF cantidad>0 THEN
            INSERT INTO poblacion(carrera,reticula,ncarrera,cantidad) 
VALUES(rec.carrera, rec.reticula, rec.nombre_carrera, cantidad);

        END IF;
    END LOOP;
 RETURN QUERY select poblacion.carrera, poblacion.reticula, poblacion.ncarrera, poblacion.cantidad FROM poblacion ORDER BY ncarrera ASC;
 DROP TABLE poblacion; 
END

$$;


ALTER FUNCTION "ITE".pac_poblacion(peri character varying) OWNER TO amaterasu;

--
-- Name: pac_resul_x_carrera1(character varying, "ITE"."T_carrera", integer, integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_resul_x_carrera1(peri character varying, carr "ITE"."T_carrera", ret integer, tamanio integer) RETURNS TABLE(clave_area character, siglas character, mat_existen integer, mat_eval integer, docentes integer, doc_eval integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
rec record;
evaluadas smallint:=0;
sigla character(5);
personal_area smallint:=0;
personal_eval smallint:=0;
BEGIN

    CREATE TEMPORARY TABLE eval0(clave_area character(6), siglas character(5),mat_existen integer, mat_eval integer, docentes integer, doc_eval integer);
    CREATE TEMP TABLE IF NOT EXISTS evlAO AS
    SELECT DISTINCT(M.clave_area), G.materia
    FROM "ITE".grupos G, "ITE".materias M, "ITE".materias_carreras MC
    WHERE G.periodo=peri AND G.materia=M.materia
    AND M.materia=MC.materia AND MC.carrera=carr AND MC.reticula=ret
    AND M.nombre_completo_materia NOT LIKE '%RESIDENCIA%';

    CREATE TEMP TABLE IF NOT EXISTS evlEO AS
    SELECT DISTINCT(M.clave_area), EA.materia
    FROM "ITE".evaluacion_alumnos EA, "ITE".materias M, "ITE".materias_carreras MC
    WHERE EA.periodo=peri AND EA.materia=M.materia
    AND M.materia=MC.materia AND MC.carrera=carr AND MC.reticula=ret AND char_length(EA.respuestas)=tamanio;

    FOR rec IN SELECT DISTINCT(EA.clave_area), count(EA.clave_area) AS total FROM evlAO EA GROUP BY (EA.clave_area) LOOP
        SELECT organigrama.siglas FROM "ITE".organigrama WHERE organigrama.clave_area=rec.clave_area INTO sigla;

        SELECT count(*) FROM evlEO WHERE evlEO.clave_area=rec.clave_area INTO evaluadas;

        SELECT COUNT(DISTINCT(G.rfc)) FROM "ITE".grupos G, "ITE".materias M, "ITE".materias_carreras MC, "ITE".personal P
        WHERE G.periodo=peri AND G.materia=M.materia AND M.materia=MC.materia AND MC.carrera=carr AND MC.reticula=ret
        AND G.rfc=P.rfc AND P.clave_area=rec.clave_area INTO personal_area;

        SELECT COUNT(DISTINCT(E.rfc)) FROM "ITE".evaluacion_alumnos E, "ITE".materias M, "ITE".materias_carreras MC, "ITE".personal P
        WHERE E.periodo=peri AND E.materia=M.materia AND M.materia=MC.materia AND MC.carrera=carr AND MC.reticula=ret AND char_length(respuestas)=tamanio
        AND E.rfc=P.rfc AND P.clave_area=rec.clave_area INTO personal_eval;

        INSERT INTO eval0(clave_area,siglas,mat_existen,mat_eval,docentes,doc_eval) VALUES(rec.clave_area,sigla,rec.total,evaluadas,personal_area,personal_eval);
    END LOOP;
    RETURN QUERY SELECT eval0.clave_area,eval0.siglas,eval0.mat_existen,eval0.mat_eval,eval0.docentes,eval0.doc_eval FROM eval0 ORDER BY siglas;
    
    DROP TABLE eval0;
    DROP TABLE evlAO;
    DROP TABLE evlEO;
END
$$;


ALTER FUNCTION "ITE".pac_resul_x_carrera1(peri character varying, carr "ITE"."T_carrera", ret integer, tamanio integer) OWNER TO amaterasu;

--
-- Name: pac_resul_x_carrera2(character varying, "ITE"."T_carrera", integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_resul_x_carrera2(peri character varying, carr "ITE"."T_carrera", ret integer) RETURNS TABLE(inscritos integer, evaluaron integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
inscrit smallint:=0;
eval smallint:=0;
BEGIN

    CREATE TEMPORARY TABLE eval1(inscritos integer, evaluaron integer);

    SELECT COUNT(DISTINCT(SM.no_de_control))
    FROM "ITE".seleccion_materias SM, "ITE".alumnos A
    WHERE SM.periodo=peri AND SM.no_de_control=A.no_de_control
    AND A.carrera=carr AND A.reticula=ret INTO inscrit;

    SELECT COUNT(DISTINCT(EA.no_de_control))
    FROM "ITE".evaluacion_alumnos EA, "ITE".alumnos A
    WHERE EA.periodo=peri AND EA.no_de_control=A.no_de_control
    AND A.carrera=carr AND A.reticula=ret INTO eval;

    INSERT INTO eval1(inscritos,evaluaron) VALUES(inscrit,eval);
    
    RETURN QUERY SELECT eval1.inscritos,eval1.evaluaron FROM eval1;
    
    DROP TABLE eval1;
END
$$;


ALTER FUNCTION "ITE".pac_resul_x_carrera2(peri character varying, carr "ITE"."T_carrera", ret integer) OWNER TO amaterasu;

--
-- Name: pac_resul_x_carrera3(character varying, character, integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_resul_x_carrera3(peri character varying, depto character, tamanio integer) RETURNS TABLE(clave_area character, siglas character, mat_existen integer, mat_eval integer, docentes integer, doc_eval integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
rec record;
evaluadas smallint:=0;
sigla character(5);
personal_area smallint:=0;
personal_eval smallint:=0;
BEGIN

    CREATE TEMPORARY TABLE evalD0(clave_area character(6), siglas character(5),mat_existen integer, mat_eval integer, docentes integer, doc_eval integer);
    CREATE TEMP TABLE IF NOT EXISTS evlDO AS
    SELECT DISTINCT(M.clave_area), G.materia
    FROM "ITE".grupos G, "ITE".materias M
    WHERE G.periodo=peri AND G.materia=M.materia
    AND M.clave_area=depto
    AND M.nombre_completo_materia NOT LIKE '%RESIDENCIA%';

    CREATE TEMP TABLE IF NOT EXISTS evlEO AS
    SELECT DISTINCT(M.clave_area), EA.materia
    FROM "ITE".evaluacion_alumnos EA, "ITE".materias M
    WHERE EA.periodo=peri AND EA.materia=M.materia
    AND M.clave_area=depto AND char_length(EA.respuestas)=tamanio;

    FOR rec IN SELECT DISTINCT(EA.clave_area), count(EA.clave_area) AS total FROM evlDO EA GROUP BY (EA.clave_area) LOOP
        SELECT organigrama.siglas FROM "ITE".organigrama WHERE organigrama.clave_area=rec.clave_area INTO sigla;

        SELECT count(*) FROM evlEO WHERE evlEO.clave_area=rec.clave_area INTO evaluadas;

        SELECT COUNT(DISTINCT(G.rfc)) FROM "ITE".grupos G, "ITE".materias M, "ITE".personal P
        WHERE G.periodo=peri AND G.materia=M.materia 
        AND G.rfc=P.rfc AND P.clave_area=rec.clave_area INTO personal_area;

        SELECT COUNT(DISTINCT(E.rfc)) FROM "ITE".evaluacion_alumnos E, "ITE".materias M, "ITE".personal P
        WHERE E.periodo=peri AND E.materia=M.materia AND char_length(respuestas)=tamanio
        AND E.rfc=P.rfc AND P.clave_area=rec.clave_area INTO personal_eval;

        INSERT INTO evalD0(clave_area,siglas,mat_existen,mat_eval,docentes,doc_eval) VALUES(rec.clave_area,sigla,rec.total,evaluadas,personal_area,personal_eval);
    END LOOP;
    RETURN QUERY SELECT evalD0.clave_area,evalD0.siglas,evalD0.mat_existen,evalD0.mat_eval,evalD0.docentes,evalD0.doc_eval FROM evalD0;
    
    DROP TABLE evalD0;
    DROP TABLE evlDO;
    DROP TABLE evlEO;
END
$$;


ALTER FUNCTION "ITE".pac_resul_x_carrera3(peri character varying, depto character, tamanio integer) OWNER TO amaterasu;

--
-- Name: pac_resul_x_carrera4(character varying, character, integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_resul_x_carrera4(peri character varying, depto character, tamanio integer) RETURNS TABLE(inscritos integer, evaluaron integer)
    LANGUAGE plpgsql
    AS $$
DECLARE

alumnos smallint:=0;
eval smallint:=0;
BEGIN

    CREATE TEMPORARY TABLE evalF0(inscritos integer, evaluaron integer);

    SELECT COUNT(DISTINCT(SM.no_de_control)) FROM "ITE".seleccion_materias SM, "ITE".materias M
    WHERE SM.periodo=peri AND SM.materia=M.materia AND M.clave_area=depto AND
    M.nombre_completo_materia NOT LIKE '%RESIDENCIA%' INTO alumnos;

    SELECT COUNT(DISTINCT(EA.no_de_control)) FROM "ITE".evaluacion_alumnos EA, "ITE".materias M
    WHERE EA.periodo=peri AND EA.materia=M.materia AND M.clave_area=depto AND EA.encuesta='A' AND char_length(respuestas)=tamanio INTO eval;

    INSERT INTO evalF0(inscritos, evaluaron) VALUES (alumnos,eval);
    
    RETURN QUERY SELECT evalF0.inscritos,evalF0.evaluaron FROM evalF0;

    DROP TABLE evalF0;
END
$$;


ALTER FUNCTION "ITE".pac_resul_x_carrera4(peri character varying, depto character, tamanio integer) OWNER TO amaterasu;

--
-- Name: pac_reticulaalumno(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_reticulaalumno(control character varying) RETURNS TABLE(materia "ITE"."T_materia", nombre_abreviado_materia character varying, creditos_materia smallint, semestre_reticula smallint, renglon smallint, calificacion "ITE"."T_calificacion", tipo_evaluacion character, tipocur text)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
espe  character varying;
BEGIN
 SELECT carrera FROM alumnos WHERE no_de_control=control into carre;
 SELECT reticula FROM alumnos WHERE no_de_control=control into reti;
 SELECT especialidad FROM alumnos WHERE no_de_control=control into espe;

 CREATE TEMP TABLE IF NOT EXISTS histoalumno AS 
 select historia_alumno.periodo, historia_alumno.materia, historia_alumno.calificacion,
 historia_alumno.tipo_evaluacion, historia_alumno.plan_de_estudios,
 historia_alumno.estatus_materia 
 from historia_alumno 
 where no_de_control=control;
 CREATE TEMP TABLE IF NOT EXISTS hist1 AS 
 select histoalumno.materia, histoalumno.calificacion, histoalumno.tipo_evaluacion, 'AC' as tipocur 
  from histoalumno 
 where histoalumno.calificacion >=60;
 CREATE TEMP TABLE IF NOT EXISTS esperepro AS 
 select histoalumno.materia, histoalumno.calificacion, histoalumno.tipo_evaluacion, 'ER' as tipocur
 from histoalumno 
 where (histoalumno.calificacion < 70 and histoalumno.tipo_evaluacion in ('EE', 'CE')) 
 and histoalumno.materia not in (select hist1.materia from hist1);
 CREATE TEMP TABLE IF NOT EXISTS didacta AS 
 select count(histoalumno.materia) as contador, histoalumno.materia 
 from histoalumno 
 where histoalumno.calificacion <70 group by histoalumno.materia;
 -- Materias cursadas en Segunda Oportunidad y no Acreditadas 
 CREATE TEMP TABLE IF NOT EXISTS hist2 AS 
  select histoalumno.materia, histoalumno.calificacion, histoalumno.tipo_evaluacion, 'AE' as tipocur 
  from histoalumno 
  where (histoalumno.calificacion < 70 and histoalumno.tipo_evaluacion in ('O2', 'R2', 'RO', 'RP', 'R1')) --Agregado Ricardo Castro
  and histoalumno.materia not in (select hist1.materia from hist1) 
  and histoalumno.materia not in (select esperepro.materia from esperepro) or histoalumno.materia in 
 (select histoalumno.materia from histoalumno, didacta 
  where histoalumno.tipo_evaluacion='EA' and histoalumno.materia=didacta.materia 
  and contador>=2) and histoalumno.materia not in (select hist1.materia from hist1);
 CREATE TEMP TABLE IF NOT EXISTS hist3 AS 
 -- Materias cursadas y no Acreditados (En primera o Ex. Especial Autodidacta) y que no tienen segundas 
  select histoalumno.materia, histoalumno.calificacion, histoalumno.tipo_evaluacion, 'CR' as tipocur 
 from histoalumno 
  where (histoalumno.calificacion < 70 and histoalumno.tipo_evaluacion in ('O1', 'R1', 'E1', 'EA', 'OO', 'OC', '1', '2', 'E2', 'OS')) --Agregado Ricardo Castro
  and histoalumno.materia not in (select hist1.materia from hist1) 
  and histoalumno.materia not in (select hist2.materia from hist2) 
  and histoalumno.materia not in (select esperepro.materia from esperepro) -- Agregado por Licette Rueda 
  union 
  -- Materias a Examen Especial Pendientes 
  select hist2.materia, hist2.calificacion, hist2.tipo_evaluacion, hist2.tipocur 
  from hist2 
  union 
 -- Materias en Especiales Reprobados 
  select esperepro.materia, esperepro.calificacion, esperepro.tipo_evaluacion, esperepro.tipocur 
  from esperepro;
 CREATE TEMP TABLE IF NOT EXISTS mathis AS 
 select hist1.materia, hist1.calificacion, hist1.tipo_evaluacion, hist1.tipocur 
 from hist1 
  union 
  select hist3.materia, hist3.calificacion, hist3.tipo_evaluacion, hist3.tipocur 
 from hist3;
 
 CREATE TEMP TABLE IF NOT EXISTS reticalu1 AS
 select MC.materia, M.nombre_abreviado_materia, MC.creditos_materia, 
 MC.semestre_reticula, MC.renglon, MC.especialidad 
  from materias_carreras MC, materias M 
 where MC.carrera=carre and MC.reticula=reti
  and MC.materia=M.materia;
 
 CREATE TEMP TABLE IF NOT EXISTS reticalu AS
 select reticalu1.materia, reticalu1.nombre_abreviado_materia, reticalu1.creditos_materia, 
 reticalu1.semestre_reticula, reticalu1.renglon, mathis.calificacion, mathis.tipo_evaluacion, mathis.tipocur, 
 reticalu1.especialidad, '00' as cur 
  from reticalu1
 LEFT JOIN mathis
 ON (mathis.materia =reticalu1.materia);
 
 update reticalu set tipocur='NA' where reticalu.tipocur is NULL
 and reticalu.semestre_reticula > 9;
 IF espe IS NULL THEN
  CREATE TEMP TABLE IF NOT EXISTS reticula AS
  select reticalu.materia, reticalu.nombre_abreviado_materia, reticalu.creditos_materia, 
  reticalu.semestre_reticula, reticalu.renglon, reticalu.calificacion,
  reticalu.tipo_evaluacion, reticalu.tipocur
   from reticalu 
   where reticalu.especialidad is NULL 
  order by reticalu.materia, reticalu.tipo_evaluacion;
 ELSE
  CREATE TEMP TABLE IF NOT EXISTS reticula2 AS
  select reticalu.materia, reticalu.nombre_abreviado_materia, reticalu.creditos_materia, reticalu.semestre_reticula, reticalu.renglon, reticalu.calificacion,
  reticalu.tipo_evaluacion, reticalu.tipocur
   from reticalu 
   where reticalu.especialidad is NULL 
   union 
   select reticalu.materia, reticalu.nombre_abreviado_materia, reticalu.creditos_materia, reticalu.semestre_reticula, reticalu.renglon, reticalu.calificacion,
  reticalu.tipo_evaluacion, reticalu.tipocur 
   from reticalu 
   where reticalu.especialidad in (espe, '');
 END IF;
 IF espe IS NULL THEN
  RETURN QUERY select reticula.materia, reticula.nombre_abreviado_materia, reticula.creditos_materia, reticula.semestre_reticula, reticula.renglon, reticula.calificacion,
  reticula.tipo_evaluacion, reticula.tipocur 
  from reticula 
  order by materia, tipocur;
 ELSE
  RETURN QUERY select reticula2.materia, reticula2.nombre_abreviado_materia, reticula2.creditos_materia, reticula2.semestre_reticula, reticula2.renglon, reticula2.calificacion,
  reticula2.tipo_evaluacion, reticula2.tipocur
  from reticula2 
  order by materia, tipocur;
 END IF;
 DROP TABLE histoalumno;
 DROP TABLE hist1;  
 DROP TABLE esperepro;
 DROP TABLE didacta;
 DROP TABLE hist2;
 DROP TABLE hist3;
 DROP TABLE mathis;
 DROP TABLE reticalu1;
 DROP TABLE reticalu;
 DROP TABLE reticula2; 
END

$$;


ALTER FUNCTION "ITE".pac_reticulaalumno(control character varying) OWNER TO amaterasu;

--
-- Name: pac_verifica_especial(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_verifica_especial(control character varying, peri character varying) RETURNS TABLE(adeudo smallint, seleccionadas smallint, pendientes smallint, ofertados smallint)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
especiales smallint;
seleccionadas smallint;
ofertadas smallint;
diferencia smallint;


BEGIN
	SELECT carrera FROM alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM alumnos WHERE no_de_control=control into reti;
	
    -- Obtener materias en especial acreditadas
	CREATE TEMP TABLE IF NOT EXISTS especiales_acreditadas AS 
	select historia_alumno.materia
	from historia_alumno 
	where historia_alumno.no_de_control=control and historia_alumno.tipo_evaluacion='CE' and calificacion>=70;

    -- Obtengo las materias en especial
	CREATE TEMP TABLE IF NOT EXISTS adeudo_especial AS 
	select historia_alumno.materia
 	from historia_alumno 
	where historia_alumno.no_de_control=control and historia_alumno.tipo_evaluacion IN ('RO','RP','R1','R2') and historia_alumno.calificacion<70 
    AND historia_alumno.materia NOT IN (SELECT materia FROM especiales_acreditadas);

    -- Obtengo las materias en especial que ya fueron seleccionadas
	CREATE TEMP TABLE IF NOT EXISTS materias_seleccionadas AS 
	select seleccion_materias.materia
	from seleccion_materias
	where seleccion_materias.no_de_control = control AND seleccion_materias.periodo=peri AND seleccion_materias.tipo_evaluacion IN ('RO','RP','R1','R2') AND seleccion_materias.calificacion < 70 
    AND seleccion_materias.materia NOT IN (SELECT materia FROM adeudo_especial);

    CREATE TEMP TABLE IF NOT EXISTS materias_ofertadas AS 
	select distinct(grupos.materia)
	from grupos
	where grupos.periodo = peri AND grupos.exclusivo_carrera = carre AND grupos.exclusivo_reticula = reti 
    AND grupos.materia IN (SELECT materia FROM adeudo_especial);

    CREATE TEMPORARY TABLE resultados(adeudo smallint, seleccionadas smallint, pendientes smallint, ofertados smallint);

    SELECT COUNT(*) FROM adeudo_especial INTO especiales;
    SELECT COUNT(*) FROM materias_seleccionadas INTO seleccionadas;
    SELECT COUNT(*) FROM materias_ofertadas INTO ofertadas;
    diferencia := especiales - seleccionadas;
	
    INSERT INTO resultados(adeudo,seleccionadas,pendientes,ofertados) VALUES (especiales,seleccionadas, diferencia, ofertadas);

    RETURN QUERY SELECT resultados.adeudo,resultados.seleccionadas,resultados.pendientes,resultados.ofertados FROM resultados;

	DROP TABLE especiales_acreditadas;
	DROP TABLE adeudo_especial;		
	DROP TABLE materias_seleccionadas;
	DROP TABLE materias_ofertadas;
    DROP TABLE resultados;
	
END

$$;


ALTER FUNCTION "ITE".pac_verifica_especial(control character varying, peri character varying) OWNER TO amaterasu;

--
-- Name: pac_verifica_repite(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pac_verifica_repite(control character varying, peri character varying) RETURNS TABLE(adeudo smallint, seleccionadas smallint, pendientes smallint, ofertados smallint)
    LANGUAGE plpgsql
    AS $$
DECLARE
carre character varying;
reti smallint;
repite smallint;
seleccionadas smallint;
ofertadas smallint;
diferencia smallint;


BEGIN
	SELECT carrera FROM alumnos WHERE no_de_control=control into carre;
	SELECT reticula FROM alumnos WHERE no_de_control=control into reti;
	
    -- Obtener materias en repetición acreditadas
	CREATE TEMP TABLE IF NOT EXISTS repites_acreditadas AS 
	select historia_alumno.materia
	from historia_alumno 
	where historia_alumno.no_de_control=control and historia_alumno.tipo_evaluacion IN('CE','RO','RP','R1','R2') and calificacion>=70;

    -- Obtengo las materias en especial
	CREATE TEMP TABLE IF NOT EXISTS especiales AS 
	select historia_alumno.materia
 	from historia_alumno 
	where historia_alumno.no_de_control=control and historia_alumno.tipo_evaluacion IN ('RO','RP','R1','R2') and historia_alumno.calificacion<70 
    AND historia_alumno.materia NOT IN (SELECT materia FROM repites_acreditadas);

    -- Unir informacion
	CREATE TEMP TABLE IF NOT EXISTS union_descartados AS 
	select repites_acreditadas.materia from repites_acreditadas
 	union
    select especiales.materia from especiales;

    -- Obtengo las materias en repeticion
    CREATE TEMP TABLE IF NOT EXISTS adeudo_repite AS 
	select historia_alumno.materia
	from historia_alumno
	where historia_alumno.no_de_control=control and historia_alumno.calificacion < 70 
    and historia_alumno.tipo_evaluacion IN ('OC','OO','1','2') AND historia_alumno.materia NOT IN (SELECT materia FROM union_descartados);

    -- Obtengo las materias ya fueron seleccionadas
	CREATE TEMP TABLE IF NOT EXISTS materias_seleccionadas AS 
	select seleccion_materias.materia
	from seleccion_materias
	where seleccion_materias.no_de_control = control AND seleccion_materias.periodo=peri  
    AND seleccion_materias.materia IN (SELECT materia FROM adeudo_repite);

    CREATE TEMP TABLE IF NOT EXISTS materias_ofertadas AS 
	select distinct(grupos.materia)
	from grupos
	where grupos.periodo = peri AND grupos.exclusivo_carrera = carre AND grupos.exclusivo_reticula = reti 
    AND grupos.materia IN (SELECT materia FROM adeudo_repite);

    CREATE TEMPORARY TABLE resultados(adeudo smallint, seleccionadas smallint, pendientes smallint, ofertados smallint);

    SELECT COUNT(*) FROM adeudo_repite INTO repite;
    SELECT COUNT(*) FROM materias_seleccionadas INTO seleccionadas;
    SELECT COUNT(*) FROM materias_ofertadas INTO ofertadas;
    diferencia := repite - seleccionadas;
	
    INSERT INTO resultados(adeudo,seleccionadas,pendientes,ofertados) VALUES (repite, seleccionadas, diferencia, ofertadas);

    RETURN QUERY SELECT resultados.adeudo,resultados.seleccionadas,resultados.pendientes,resultados.ofertados FROM resultados;

	DROP TABLE repites_acreditadas;
	DROP TABLE especiales;		
    DROP TABLE union_descartados;
    DROP TABLE adeudo_repite;
	DROP TABLE materias_seleccionadas;
	DROP TABLE materias_ofertadas;
    DROP TABLE resultados;
	
END

$$;


ALTER FUNCTION "ITE".pac_verifica_repite(control character varying, peri character varying) OWNER TO amaterasu;

--
-- Name: pap_agrega_calif_a_histo("ITE"."T_periodo", character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_agrega_calif_a_histo(peri "ITE"."T_periodo", usuar character varying) RETURNS smallint
    LANGUAGE plpgsql
    AS $$
DECLARE
fecha_actual timestamp without time zone;
fecha_cali timestamp without time zone;
rec record;
contador smallint := 0;
existencia smallint;
nveces smallint := 0;
tipo char(2);
acred char(1);
per_acred character varying;
BEGIN
	SELECT current_timestamp into fecha_actual;
   
    IF substring(peri,5,1)='1' THEN 
     SELECT to_timestamp(CONCAT(substring(peri,1,4),'/06/01'),'YYYY/MM/DD HH24:MI:SS') INTO fecha_cali;
    ELSIF substring(peri,5,1)='2' THEN 
     SELECT to_timestamp(CONCAT(substring(peri,1,4),'/08/01'),'YYYY/MM/DD HH24:MI:SS') INTO fecha_cali; 
    ELSE 
     SELECT to_timestamp(CONCAT(substring(peri,1,4),'/12/01'),'YYYY/MM/DD HH24:MI:SS') INTO fecha_cali; 
    END IF;
 
    -- Determinar si ya existe historial academico del periodo
    SELECT COUNT(*) FROM "ITE".historia_alumno WHERE historia_alumno.periodo=peri AND historia_alumno.tipo_evaluacion NOT IN ('EE','EA','RU','RC','AC') INTO existencia;

    IF existencia > 0 THEN  --Si existe, por lo que se verifica que no se vaya a repetir la materia
        CREATE TEMP TABLE IF NOT EXISTS historia_periodo AS 
        select HA.periodo, HA.no_de_control, HA.materia, HA.calificacion, HA.tipo_evaluacion, HA.fecha_calificacion, HA.plan_de_estudios
        from "ITE".historia_alumno HA
        where HA.periodo=peri and HA.tipo_evaluacion not in ('EE', 'EA', 'RU', 'RC', 'AC');
	
        FOR rec IN SELECT SM.periodo, SM.no_de_control, SM.materia, SM.grupo, SM.calificacion, SM.tipo_evaluacion, A.plan_de_estudios, SM.nopresento 
        from "ITE".seleccion_materias SM, "ITE".alumnos A 
        where SM.periodo=peri AND SM.tipo_evaluacion is not NULL AND SM.no_de_control=A.no_de_control
        LOOP     
            SELECT COUNT(*) FROM historia_periodo HP WHERE HP.periodo=rec.periodo and HP.no_de_control=rec.no_de_control and HP.materia=rec.materia 
            and HP.calificacion=rec.calificacion and HP.tipo_evaluacion=rec.tipo_evaluacion and HP.fecha_calificacion=fecha_cali 
            and HP.plan_de_estudios=rec.plan_de_estudios INTO contador;
            IF contador=0 THEN  --Como la materia no esta repetida, se puede analizar para determinar como se almacena
                IF substring(rec.tipo_evaluacion,1,1)='R' THEN
                    SELECT COUNT(*) FROM "ITE".historia_alumno WHERE no_de_control=rec.no_de_control AND materia=rec.materia INTO nveces; 
                    IF nveces > 2 THEN
                        IF rec.calificacion >=70 THEN
                            SELECT 'A' INTO acred;
                            SELECT 'CE' INTO tipo;
                            SELECT peri INTO per_acred;
                        ELSE
                            SELECT 'N' INTO acred;
                            SELECT 'CE' INTO tipo;
                            SELECT null INTO per_acred;
                        END IF;
                    ELSE
                        IF rec.calificacion >=70 THEN
                            SELECT 'A' INTO acred;
                            SELECT rec.tipo_evaluacion INTO tipo;
                            SELECT peri INTO per_acred;
                        ELSE
                            SELECT 'P' INTO acred;
                            SELECT rec.tipo_evaluacion INTO tipo;
                            SELECT null INTO per_acred;
                        END IF;
                    END IF;
                ELSE
                    IF rec.calificacion >=70 THEN
                        SELECT 'A' INTO acred;
                        SELECT rec.tipo_evaluacion INTO tipo;
                        SELECT peri INTO per_acred;
                    ELSE
                        SELECT 'P' INTO acred;
                        SELECT rec.tipo_evaluacion INTO tipo;
                        SELECT null INTO per_acred;
                   END IF;
                END IF;
                INSERT INTO "ITE".historia_alumno(periodo,no_de_control,materia,grupo,calificacion,tipo_evaluacion,fecha_calificacion,
                plan_de_estudios,estatus_materia,nopresento,usuario,fecha_actualizacion,periodo_acredita_materia,created_at,updated_at) VALUES       
                (rec.periodo,rec.no_de_control,rec.materia,rec.grupo,rec.calificacion,tipo,fecha_cali,rec.plan_de_estudios,acred,null,usuar,
                fecha_actual,per_acred,fecha_cali,null); 
            END IF;   
        END LOOP;
        DROP TABLE historia_periodo;
    ELSE 
        FOR rec IN SELECT SM.periodo, SM.no_de_control, SM.materia, SM.grupo, SM.calificacion, SM.tipo_evaluacion, A.plan_de_estudios, SM.nopresento 
        from "ITE".seleccion_materias SM, "ITE".alumnos A 
        where SM.periodo=peri AND SM.tipo_evaluacion is not NULL AND SM.no_de_control=A.no_de_control
        LOOP     
            IF substring(rec.tipo_evaluacion,1,1)='R' THEN
                SELECT COUNT(*) FROM "ITE".historia_alumno WHERE no_de_control=rec.no_de_control AND materia=rec.materia INTO nveces; 
                IF nveces > 2 THEN
                    IF rec.calificacion >=70 THEN
                        SELECT 'A' INTO acred;
                        SELECT 'CE' INTO tipo;
                        SELECT peri INTO per_acred;
                    ELSE
                        SELECT 'N' INTO acred;
                        SELECT 'CE' INTO tipo;
                        SELECT null INTO per_acred;
                    END IF;
                ELSE
                   IF rec.calificacion >=70 THEN
                        SELECT 'A' INTO acred;
                        SELECT rec.tipo_evaluacion INTO tipo;
                        SELECT peri INTO per_acred;
                   ELSE
                        SELECT 'P' INTO acred;
                        SELECT rec.tipo_evaluacion INTO tipo;
                        SELECT null INTO per_acred;
                   END IF;
                END IF;
            ELSE
                IF rec.calificacion >=70 THEN
                    SELECT 'A' INTO acred;
                    SELECT rec.tipo_evaluacion INTO tipo;
                    SELECT peri INTO per_acred;
                ELSE
                    SELECT 'P' INTO acred;
                    SELECT rec.tipo_evaluacion INTO tipo;
                    SELECT null INTO per_acred;
                END IF;
            END IF;
            INSERT INTO "ITE".historia_alumno(periodo,no_de_control,materia,grupo,calificacion,tipo_evaluacion,fecha_calificacion,
            plan_de_estudios,estatus_materia,nopresento,usuario,fecha_actualizacion,periodo_acredita_materia,created_at,updated_at) VALUES       
            (rec.periodo,rec.no_de_control,rec.materia,rec.grupo,rec.calificacion,tipo,fecha_cali,rec.plan_de_estudios,acred,null,usuar,
            fecha_actual,per_acred,fecha_cali,null);            
        END LOOP;
    END IF;
    RETURN 1 as fin; 
END
$$;


ALTER FUNCTION "ITE".pap_agrega_calif_a_histo(peri "ITE"."T_periodo", usuar character varying) OWNER TO amaterasu;

--
-- Name: pap_avisos_reinscripcion(character varying, character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_avisos_reinscripcion(peri character varying, per_aviso character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
-- Inicializo variables
DECLARE
    rec record;
	semestre integer:=0; 
    creda integer:=0; 
    credc integer:=0; 
    credt integer:=0; 
    matc integer:=0; 
    matr integer:=0; 
    indice float:=0.00; 
    escolar char(1); 
    biblioteca char(1); 
    financieros char(1); 
    baja char(1):='N'; 
    motivo_baja character varying; 
    mata integer:=0; 
    egresar char(1):='N'; 
    encuesto char(1);          
    vobo char(1):='N'; 
    regular char(1):='S'; 
    credauto integer:=0; 
    promedio numeric(5,2):=0.00; 
    prom_acum numeric(5,2):=0.00;
    carga_max integer:=0; 
    carga_min integer:=0; 
    credcarr integer:=0; 
    valor integer:=0; 
    adeuda_esp char(1):='N'; 
    estatus char(3); 
    msgi character varying; 
    especiales_cursados integer:=0; 
    en_especial integer:=0;
    semini integer:=0;
    anioini integer:=0; 
    perini integer:=0;
    perrev integer:=0;
	cuando timestamp without time zone;
BEGIN	
--Alumnos del periodo en cuestion
    FOR rec IN SELECT DISTINCT SM.no_de_control FROM "ITE".seleccion_materias SM WHERE SM.periodo=peri
        LOOP
            IF EXISTS (SELECT 1 FROM "ITE".evaluacion_alumnos EA WHERE EA.periodo=peri AND EA.no_de_control=rec.no_de_control) THEN
                encuesto:='S';
            ELSE
                encuesto:='N';
            END IF;
            SELECT AH.indice_reprobacion_acumulado,creditos_aprobados,creditos_cursados,materias_cursadas,materias_reprobadas,promedio_aritmetico,promedio_aritmetico_acumulado,
                CASE WHEN AH.promedio_aritmetico BETWEEN 80.0 and 100 THEN creditos_cursados + 8
                WHEN promedio_aritmetico BETWEEN 70.0 and 79.999 THEN creditos_cursados
                WHEN promedio_aritmetico BETWEEN 60.0 and 69.999 THEN creditos_cursados - 4
                WHEN promedio_aritmetico BETWEEN 50.0 and 59.999 THEN creditos_cursados - 8
                ELSE creditos_cursados - 10 END
            INTO indice,creda,credc,mata,matr,promedio,prom_acum,credauto FROM "ITE".acumulado_historico AH WHERE AH.no_de_control=rec.no_de_control AND AH.periodo=peri;
            SELECT SUM(AH.creditos_aprobados) INTO credt FROM "ITE".acumulado_historico AH WHERE AH.no_de_control=rec.no_de_control;
             -- Adeudo con Servicios Escolares
			 /*
             IF EXISTS (SELECT 1 FROM "ITE".adeudos AD WHERE AD.periodo=peri AND AD.no_de_control=rec.no_de_control AND AD.tipo='E') THEN
                escolar:='S';
             ELSE
                escolar:='N';
             END IF;

             -- Adeudo con Centro de Información (Biblioteca)
             IF EXISTS (SELECT 1 FROM "ITE".adeudos AD WHERE AD.periodo=peri AND AD.no_de_control=rec.no_de_control AND AD.tipo='B') THEN
                biblioteca:='S';
             ELSE
                biblioteca:='N';
             END IF;
             
             -- Adeudo con Recursos Financieros
             IF EXISTS (SELECT 1 FROM "ITE".adeudos AD WHERE AD.periodo=peri AND AD.no_de_control=rec.no_de_control AND AD.tipo='F') THEN
                financieros:='S';
             ELSE
                financieros:='N';
             END IF;
             */
			 escolar:='N';
			 biblioteca:='N';
			 financieros:='N';
             vobo:='N'; -- Inicializa la variable que define el vo.bo. del director para avance

             -- Selecciono los creditos totales, carga máxima y carga mínima de la carrera del alumno
             SELECT C.creditos_totales, C.carga_maxima, C.carga_minima INTO credcarr,carga_max,carga_min FROM "ITE".carreras C, "ITE".alumnos A 
             WHERE C.carrera=A.carrera and C.reticula=A.reticula AND A.no_de_control=rec.no_de_control;
             
             -- Se definen los créditos autorizados
             IF credauto < carga_min THEN
                credauto:=carga_min;
             ELSIF credauto > carga_max THEN
                credauto:=carga_max;
             END IF;
			 
             -- Se calcula semestre del alumno
             IF SUBSTRING(peri,5,1) = '3' THEN        
                 semini:=2;        
             ELSE        
                 semini:=1;
             END IF;
            SELECT SUBSTRING(A.periodo_ingreso_it,1,4)::INTEGER,SUBSTRING(A.periodo_ingreso_it,5,1)::INTEGER, A.periodos_revalidacion        
            INTO anioini,perini,perrev FROM "ITE".alumnos A WHERE A.no_de_control = rec.no_de_control;
            semestre:= 2 * (SUBSTRING(peri,1,4)::INTEGER - anioini);        
            IF perini=3 THEN
                semestre:= semestre + (semini - perini + 2 + perrev);
            ELSE 
                semestre:= semestre + (semini - perini + 1 + perrev);
            END IF;
            IF semestre < 0 THEN
                semestre:= 0;
            END IF;
            IF (semestre=1) AND ((mata - matr) < 3) THEN--REPROBACION DE MAS DE 50% DE CREDITOS PARA NUEVO INGRESO EN PRIMER SEMESTRE
                baja:='S';
                motivo_baja:='REPROBACION DE MAS DE 3 MATERIAS PARA NUEVO INGRESO EN PRIMER SEMESTRE';
                estatus:='BD2';
                egresar:='N';
            ELSIF semestre>12 THEN
                baja:='S';
                motivo_baja:='EXCEDE MAS DE 12 SEMESTRES PERMITIDOS';
                estatus:='BD4';
				egresar:='N';
			ELSE
				baja:='N';
				motivo_baja:='';
			    estatus:='ACT';
				egresar:='N';	
            END IF;
			IF credt >=credcarr THEN
                egresar:='S';
				baja:='S';
				motivo_baja:='EGRESO';
			    estatus:='EGR';
			END IF;
            --Si es regular
            IF EXISTS (SELECT 1 from "ITE".historia_alumno HA WHERE HA.no_de_control = rec.no_de_control AND HA.periodo <= peri AND HA.calificacion < 70 
              AND HA.materia NOT IN (SELECT HA.materia FROM "ITE".historia_alumno HA WHERE HA.calificacion >= 70 
              AND HA.no_de_control = rec.no_de_control AND periodo <= peri)) THEN
                regular:= 'N';
            ELSE
                regular:='S';
            END IF;
            SELECT COUNT(*) INTO especiales_cursados FROM "ITE".historia_alumno WHERE historia_alumno.no_de_control=rec.no_de_control AND historia_alumno.tipo_evaluacion='CE';
            SELECT COUNT(*) INTO en_especial FROM "ITE".historia_alumno HA WHERE HA.no_de_control=rec.no_de_control AND HA.tipo_evaluacion IN ('RO', 'RP') AND HA.materia NOT IN (
                SELECT HA.materia FROM "ITE".historia_alumno HA WHERE HA.no_de_control=rec.no_de_control AND HA.tipo_evaluacion='CE' AND HA.calificacion >=70) AND HA.calificacion < 70;
            IF (especiales_cursados + en_especial) > 5 THEN
                baja:='S';
                motivo_baja:='EXCEDE DEL MAXIMO NUMERO DE CURSOS ESPECIALES PERMITIDOS';
                adeuda_esp:='S';
                estatus:='BD7';
                egresar:='N';
            END IF;
            IF en_especial >=1 THEN
                credauto:=carga_max;
            END IF;
			SELECT now() AT TIME ZONE current_setting('timezone') INTO cuando;
            INSERT INTO "ITE".avisos_reinscripcion (periodo, no_de_control, autoriza_escolar,recibo_pago,fecha_recibo,cuenta_pago,fecha_hora_seleccion,lugar_seleccion,fecha_hora_pago,adeuda_escolar, adeuda_biblioteca, adeuda_financieros, otro_mensaje,baja, motivo_aviso_baja, 
 egresa, encuesto, vobo_adelanta_sel, regular, indice_reprobacion, creditos_autorizados, estatus_reinscripcion,semestre, promedio, adeudo_especial,promedio_acumulado,proareas,created_at,updated_at) 
            VALUES
            (per_aviso, rec.no_de_control,'N',null,null,null,null,null,null,escolar, biblioteca, financieros,null, baja, motivo_baja, egresar, encuesto, vobo, regular, indice, credauto, null,semestre, promedio, adeuda_esp,prom_acum,null,cuando,null);
            UPDATE "ITE".alumnos SET estatus_alumno=estatus WHERE alumnos.no_de_control=rec.no_de_control;
        END LOOP;
END;
$$;


ALTER FUNCTION "ITE".pap_avisos_reinscripcion(peri character varying, per_aviso character varying) OWNER TO amaterasu;

--
-- Name: pap_curso_especial(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_curso_especial(peri character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
-- Inicializo variables
DECLARE
    rec record;
	cantidad integer:=0; 
BEGIN	
    -- Obtener materias en especial 
	FOR rec IN SELECT SM.no_de_control,SM.materia, SM.calificacion FROM "ITE".seleccion_materias SM, "ITE".alumnos A WHERE SM.periodo=peri AND
        SM.no_de_control=A.no_de_control AND (A.plan_de_estudios='3' OR A.plan_de_estudios='4') AND SM.repeticion='S'
        LOOP
             SELECT COUNT(*) INTO cantidad FROM "ITE".historia_alumno HA WHERE HA.no_de_control=rec.no_de_control AND HA.materia=rec.materia AND HA.calificacion=0;
             IF cantidad=3 AND rec.calificacion=0 THEN
                UPDATE "ITE".alumnos SET estatus_alumno='BDR' WHERE alumnos.no_de_control=rec.no_de_control;
                INSERT INTO "ITE".baja_cespeciales(periodo, no_de_control, materia) VALUES(peri, rec.no_de_control, rec.materia);
             ELSIF cantidad=2 AND rec.calificacion >=70 THEN
                UPDATE "ITE".seleccion_materias SM SET tipo_evaluacion='CE' WHERE SM.periodo=peri AND SM.no_de_control=rec.no_de_control AND SM.materia=rec.materia;
			    UPDATE "ITE".historia_alumno HA SET tipo_evaluacion='CE' WHERE HA.periodo=peri and HA.no_de_control=rec.no_de_control AND HA.materia=rec.materia;
             END IF;
             
        END LOOP;
END;

$$;


ALTER FUNCTION "ITE".pap_curso_especial(peri character varying) OWNER TO amaterasu;

--
-- Name: pap_estatus_alumno(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_estatus_alumno(peri character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$-- Inicializo variables
DECLARE
    rec record;
	cuando timestamp without time zone;
BEGIN	
--Primero, darlos de baja
UPDATE "ITE".alumnos SET estatus_alumno='BT3' WHERE estatus_alumno='ACT';
--Alumnos del periodo en cuestion
    FOR rec IN SELECT DISTINCT SM.no_de_control FROM "ITE".seleccion_materias SM WHERE SM.periodo=peri
        LOOP
            UPDATE "ITE".alumnos SET estatus_alumno = 'ACT' where no_de_control = rec.no_de_control;
        END LOOP;
END;$$;


ALTER FUNCTION "ITE".pap_estatus_alumno(peri character varying) OWNER TO amaterasu;

--
-- Name: pap_estudios_personal(integer); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_estudios_personal(personal integer) RETURNS TABLE(id integer, descripcion character varying, nivel character, carrera text, nombre text, cedula character varying, fecha_inicio date, fecha_final date)
    LANGUAGE plpgsql
    AS $$
BEGIN

RETURN QUERY SELECT PE.id, PN.descripcion, PC.nivel, PC.carrera, PI.nombre, PE.cedula, PE.fecha_inicio, PE.fecha_final 
FROM "ITE".personal_carreras PC, "ITE".personal_estudios PE, "ITE".personal_instit_estudios PI, "ITE".personal_nivel_estudios PN
WHERE PE.id_docente=personal AND PE.id_carrera=PC.id AND PE.id_escuela=PI.id AND PC.nivel=PN.caracter;
END
$$;


ALTER FUNCTION "ITE".pap_estudios_personal(personal integer) OWNER TO amaterasu;

--
-- Name: pap_promedios_alumno("ITE"."T_no_de_control", character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_promedios_alumno(control "ITE"."T_no_de_control", peri character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
-- Inicializo variables
DECLARE
    historia record;
	materias_cursadas integer:=0; 
    materias_aprobadas integer:=0; 
    materias_reprobadas integer:=0; 
    materias_a_especial integer:=0; 
    materias_especial_reprobado integer:=0; 
    creditos_cursados integer:=0; 
    creditos_aprobados integer:=0; 
    creditos_reprobados integer:=0; 
    suma_calificacion integer:=0; 
    suma_calificacion_ponderada integer:=0; 
    indice numeric(5,2):=0.00; 
    creditos_promedio integer:=0; 
    materias_promedio integer:=0; 
    promedio_ponderado numeric(5,2):=0.00; 
    promedio_aritmetico numeric(5,2):=0.00;          
    creditos_aprobados_a integer:=0; 
    creditos_cursados_a integer:=0; 
    suma_calificacion_a integer:=0; 
    suma_calificacion_ponderada_a integer:=0; 
    suma_calificacion_certificado integer:=0; 
    creditos_reprobados_a integer:=0; 
    materias_promedio_certificado integer:=0; 
    indice_a numeric(5,2):=0.00; 
    creditos_promedio_a integer:=0; 
    materias_promedio_a integer:=0; 
    promedio_ponderado_a numeric(5,2):=0.00; 
    promedio_aritmetico_a numeric(5,2):=0.00; 
    promedio_certificado numeric(5,2):=0.00;
    estatus_periodo char(1);
    fin smallint:=1;
BEGIN	
--Alumnos del periodo en cuestion
    
        --Historial academico
            CREATE TEMP TABLE IF NOT EXISTS histo AS SELECT HA.periodo, HA.no_de_control, HA.materia, HA.calificacion, HA.tipo_evaluacion, HA.plan_de_estudios, 
            HA.estatus_materia, HA.nopresento, HA.periodo_acredita_materia FROM "ITE".historia_alumno HA WHERE HA.periodo <= peri and no_de_control = control;
        --Analizar historia
            FOR historia IN SELECT H.periodo, H.no_de_control, H.materia, MC.creditos_materia, H.calificacion, H.tipo_evaluacion, A.plan_de_estudios, H.estatus_materia, 
            C.creditos_totales, H.periodo_acredita_materia                       
            FROM histo H, "ITE".materias_carreras MC, "ITE".alumnos A, "ITE".materias M, "ITE".carreras C       
            WHERE H.no_de_control = control AND H.no_de_control = A.no_de_control AND H.materia = M.materia AND M.tipo_materia in (1,2,3) AND H.materia = MC.materia AND A.carrera = MC.carrera 
            AND A.reticula = MC.reticula AND A.carrera = C.carrera and A.reticula = C.reticula
                LOOP
                    IF historia.periodo=peri THEN
                    	IF historia.tipo_evaluacion not in ('RU', 'RC', 'EE', 'EA') THEN -- Materias cursadas 
                        	materias_cursadas:= materias_cursadas + 1; 
                            creditos_cursados:= creditos_cursados + historia.creditos_materia;
                        END IF;
                        IF historia.calificacion >= 70 OR (historia.calificacion >= 60 AND historia.tipo_evaluacion in ('RC','RU')) THEN    
                            creditos_aprobados:= creditos_aprobados + historia.creditos_materia;     -- Materia Aprobada          
                        ELSE             
                            materias_reprobadas:= materias_reprobadas + 1;
                            creditos_reprobados:= creditos_reprobados + historia.creditos_materia;  --Materia Reprobada 
                            IF historia.tipo_evaluacion = 'EE' THEN
                            	materias_especial_reprobado:= materias_especial_reprobado + 1;   -- Especial Reprobado 
                            ELSIF historia.tipo_evaluacion IN ('O2', 'R2') THEN
                                materias_a_especial = materias_a_especial + 1;    -- Materia a Especial
                            END IF;
                        END IF;
                        IF historia.tipo_evaluacion != 'RU' THEN   -- Para todas las materias que no son de Equivalencia             
                            suma_calificacion:= suma_calificacion + historia.calificacion;
                            materias_promedio:= materias_promedio + 1; 
                            suma_calificacion_ponderada:= suma_calificacion_ponderada + (historia.calificacion * historia.creditos_materia);
                            creditos_promedio:= creditos_promedio + historia.creditos_materia; 
                        END IF;
                    END IF;
                    -- Inicia analisis para acumulados 
                    IF historia.tipo_evaluacion != 'RU' THEN    -- Elimina Materias en Equivalencia  
                        IF historia.tipo_evaluacion not in ('EE','EA','RC') THEN 
                            creditos_cursados_a:= creditos_cursados_a + historia.creditos_materia;
                        END IF;
                        IF (historia.calificacion >= 70) OR (historia.calificacion < 70 AND ( (historia.estatus_materia = 'R') OR (historia.periodo_acredita_materia > historia.periodo))) THEN
                            suma_calificacion_a:= suma_calificacion_a + historia.calificacion;
                            materias_promedio_a:= materias_promedio_a + 1; 
                            suma_calificacion_ponderada_a:= suma_calificacion_ponderada_a + (historia.calificacion * historia.creditos_materia);
                            creditos_promedio_a:= creditos_promedio_a + historia.creditos_materia; 
                            IF historia.calificacion < 70 THEN 
                               creditos_reprobados_a:= creditos_reprobados_a + historia.creditos_materia;
                            END IF;
                        END IF; 
                        IF historia.calificacion >= 70 THEN
                            suma_calificacion_certificado:= suma_calificacion_certificado + historia.calificacion;
                            materias_promedio_certificado:= materias_promedio_certificado + 1;
                            creditos_aprobados_a:= creditos_aprobados_a + historia.creditos_materia;
                        END IF; 
                    END IF; 
                    -- Fin analisis para acumulados 
                    -- Inician Calculos para el periodo
                    IF creditos_promedio > 0 THEN -- Curso Materias en el Periodo, Obtiene Promedio, Aritmético y Ponderado 
                        promedio_ponderado:= suma_calificacion_ponderada / creditos_promedio;
                        promedio_aritmetico:= suma_calificacion / materias_promedio;
                        IF creditos_reprobados > 0 THEN  -- Si es afirmativo, calcula indice de reprobación por periodo 
                        	indice:=  creditos_reprobados / creditos_promedio;
                        ELSE 
                            indice:= 0.00; 
                        END IF; 
                    ELSE 
                        promedio_ponderado:= 0.00;
                        promedio_aritmetico:= 0.00;
                        IF materias_especial_reprobado > 0 THEN
                           estatus_periodo:= 'X'; 
                        ELSIF materias_a_especial >= 2 THEN
                           estatus_periodo:= 'T';
                        ELSIF creditos_reprobados > 0 THEN
                           estatus_periodo:= 'I';
                        ELSE 
                           estatus_periodo:= 'R';
                        END IF;
                    END IF;
                    -- Finalizan Calculos para el periodo  
                    -- Inician Calculos para acumulados
                    IF creditos_promedio_a > 0 THEN -- Curso Materias, Obtiene Promedio, Aritmético, Ponderado, de Certificado e Indice de reprobación
                        promedio_ponderado_a:= suma_calificacion_ponderada_a / creditos_promedio_a; 
                        promedio_aritmetico_a:= suma_calificacion_a / materias_promedio_a;         
                        IF materias_promedio_certificado > 0 THEN
                        	promedio_certificado:= suma_calificacion_certificado / materias_promedio_certificado;
                        ELSE 
                            promedio_certificado:= 0.00; 
                        END IF;
                    	IF creditos_reprobados_a > 0 THEN  -- Si es afirmativo, calcula indice de reprobación
                        	indice_a:= creditos_reprobados_a / creditos_promedio_a;
                        ELSE 
                            indice_a:= 0.00; 
                        END IF;
                    ELSE 
                        promedio_ponderado_a:= 0.00; 
                        promedio_aritmetico_a:= 0.00; 
                        indice_a:= 0.00; 
                        promedio_certificado:= 0.00; 
                    END IF; 
                END LOOP;
                INSERT INTO "ITE".acumulado_historico(periodo,no_de_control,estatus_periodo_alumno,creditos_cursados,
														  creditos_aprobados,promedio_ponderado,promedio_ponderado_acumulado,
														  promedio_aritmetico,promedio_aritmetico_acumulado,promedio_certificado,
														  materias_cursadas, materias_reprobadas, materias_a_examen_especial, 
														  materias_especial_reprobadas,indice_reprobacion_semestre,creditos_autorizados,
														  indice_reprobacion_acumulado) 
                VALUES(peri, control, estatus_periodo, creditos_cursados, creditos_aprobados, 
						   promedio_ponderado, promedio_ponderado_a, promedio_aritmetico,promedio_aritmetico_a, 
						   promedio_certificado, materias_cursadas, materias_reprobadas, materias_a_especial, 
						   materias_especial_reprobado, indice, 0, indice_a); 
                UPDATE "ITE".alumnos SET promedio_aritmetico_acumulado = promedio_aritmetico_a, creditos_aprobados = creditos_aprobados_a, 
					creditos_cursados = creditos_cursados_a, promedio_final_alcanzado = promedio_certificado 
				WHERE no_de_control = control; 
               DROP TABLE histo;
END;

$$;


ALTER FUNCTION "ITE".pap_promedios_alumno(control "ITE"."T_no_de_control", peri character varying) OWNER TO amaterasu;

--
-- Name: pap_semestre_alumno(character varying); Type: FUNCTION; Schema: ITE; Owner: amaterasu
--

CREATE FUNCTION "ITE".pap_semestre_alumno(peri character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
-- Inicializo variables
DECLARE
    rec record;
	semestr integer:=0; 
    semini integer:=0;
    anioini integer:=0; 
    perini integer:=0;
    perrev integer:=0;
	cuando timestamp without time zone;
BEGIN	
--Alumnos del periodo en cuestion
    FOR rec IN SELECT DISTINCT SM.no_de_control FROM "ITE".seleccion_materias SM WHERE SM.periodo=peri
        LOOP
             -- Se calcula semestre del alumno
             IF SUBSTRING(peri,5,1) = '3' THEN        
                 semini:=2;        
             ELSE        
                 semini:=1;
             END IF;
            SELECT SUBSTRING(A.periodo_ingreso_it,1,4)::INTEGER,SUBSTRING(A.periodo_ingreso_it,5,1)::INTEGER, A.periodos_revalidacion        
            INTO anioini,perini,perrev FROM "ITE".alumnos A WHERE A.no_de_control = rec.no_de_control;
            semestr:= 2 * (SUBSTRING(peri,1,4)::INTEGER - anioini);        
            IF perini=3 THEN
                semestr:= semestr + (semini - perini + 2 + perrev);
            ELSE 
                semestr:= semestr + (semini - perini + 1 + perrev);
            END IF;
            IF semestr < 0 THEN
                semestr:= 0;
            END IF;
            --Se le indica ahora que irá al próximo semestre
            semestr:= semestr + 1;
            UPDATE "ITE".alumnos SET semestre = semestr where no_de_control = rec.no_de_control;
        END LOOP;
END;

$$;


ALTER FUNCTION "ITE".pap_semestre_alumno(peri character varying) OWNER TO amaterasu;

--
-- Name: actividades_apoyo; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".actividades_apoyo (
    actividad character varying(4),
    descripcion_actividad character varying(150)
);


ALTER TABLE "ITE".actividades_apoyo OWNER TO amaterasu;

--
-- Name: acumulado_historico; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".acumulado_historico (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    estatus_periodo_alumno character(1),
    creditos_cursados "ITE"."T_creditos",
    creditos_aprobados "ITE"."T_creditos",
    promedio_ponderado "ITE"."T_promedio",
    promedio_ponderado_acumulado "ITE"."T_promedio",
    promedio_aritmetico "ITE"."T_promedio",
    promedio_aritmetico_acumulado "ITE"."T_promedio",
    promedio_certificado "ITE"."T_promedio",
    materias_cursadas integer,
    materias_reprobadas integer,
    materias_a_examen_especial integer,
    materias_especial_reprobadas integer,
    indice_reprobacion_semestre numeric(8,6),
    creditos_autorizados "ITE"."T_creditos",
    indice_reprobacion_acumulado numeric(8,6)
);


ALTER TABLE "ITE".acumulado_historico OWNER TO amaterasu;

--
-- Name: alumnos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".alumnos (
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    carrera "ITE"."T_carrera",
    reticula "ITE"."T_reticula",
    especialidad "ITE"."T_especialidad",
    nivel_escolar "char",
    semestre smallint,
    estatus_alumno character(3) DEFAULT 'ACT'::bpchar,
    plan_de_estudios character(1) NOT NULL,
    apellido_paterno "ITE"."T_apellidos_persona",
    apellido_materno "ITE"."T_apellidos_persona",
    nombre_alumno character varying(255) NOT NULL,
    curp_alumno "ITE"."T_curp",
    fecha_nacimiento "ITE"."T_fecha",
    sexo "ITE"."T_sexo",
    estado_civil "ITE"."T_estado_civil",
    tipo_ingreso numeric(1,0) NOT NULL,
    periodo_ingreso_it "ITE"."T_periodo" NOT NULL,
    ultimo_periodo_inscrito "ITE"."T_periodo",
    promedio_periodo_anterior "ITE"."T_promedio",
    promedio_aritmetico_acumulado "ITE"."T_promedio",
    creditos_aprobados "ITE"."T_creditos",
    creditos_cursados "ITE"."T_creditos",
    promedio_final_alcanzado "ITE"."T_promedio",
    escuela_procedencia character varying(50),
    entidad_procedencia "ITE"."T_lugar_nac",
    ciudad_procedencia "ITE"."T_ciudad",
    correo_electronico character varying(60),
    periodos_revalidacion smallint,
    becado_por character varying(100),
    nip integer,
    fecha_titulacion "ITE"."T_fecha",
    opcion_titulacion character varying(4),
    periodo_titulacion "ITE"."T_periodo",
    nss character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".alumnos OWNER TO amaterasu;

--
-- Name: alumnos_generales; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".alumnos_generales (
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    domicilio_calle character varying(60),
    domicilio_colonia character varying(40),
    codigo_postal character varying(5),
    telefono character varying(30),
    facebook character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".alumnos_generales OWNER TO amaterasu;

--
-- Name: apoyo_docencia; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".apoyo_docencia (
    periodo "ITE"."T_periodo",
    rfc character varying(13),
    actividad character varying(4),
    consecutivo smallint,
    especifica_actividad character varying(110)
);


ALTER TABLE "ITE".apoyo_docencia OWNER TO amaterasu;

--
-- Name: aulas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".aulas (
    id integer NOT NULL,
    aula character varying(6) NOT NULL,
    ubicacion character varying(30) NOT NULL,
    capacidad integer,
    estatus boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".aulas OWNER TO amaterasu;

--
-- Name: aulas_aspirantes; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".aulas_aspirantes (
    id integer NOT NULL,
    periodo "ITE"."T_periodo" NOT NULL,
    aula integer NOT NULL,
    capacidad smallint NOT NULL,
    disponibles smallint NOT NULL,
    carrera "ITE"."T_carrera" NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".aulas_aspirantes OWNER TO amaterasu;

--
-- Name: aulas_aspirantes_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".aulas_aspirantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".aulas_aspirantes_id_seq OWNER TO amaterasu;

--
-- Name: aulas_aspirantes_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".aulas_aspirantes_id_seq OWNED BY "ITE".aulas_aspirantes.id;


--
-- Name: aulas_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".aulas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".aulas_id_seq OWNER TO amaterasu;

--
-- Name: aulas_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".aulas_id_seq OWNED BY "ITE".aulas.id;


--
-- Name: avisos_reinscripcion; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".avisos_reinscripcion (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    autoriza_escolar character(1),
    recibo_pago character(10),
    fecha_recibo date,
    cuenta_pago character varying(250),
    fecha_hora_seleccion timestamp without time zone,
    lugar_seleccion character varying(250),
    fecha_hora_pago date,
    lugar_pago character varying(250),
    adeuda_escolar character(1),
    adeuda_biblioteca character(1),
    adeuda_financieros character(1),
    otro_mensaje character varying(250),
    baja character(1),
    motivo_aviso_baja character varying(250),
    egresa character(1),
    encuesto character(1),
    vobo_adelanta_sel character(1),
    regular character(1),
    indice_reprobacion real,
    creditos_autorizados integer,
    estatus_reinscripcion character(1),
    semestre integer,
    promedio integer,
    adeudo_especial character(1),
    promedio_acumulado "ITE"."T_promedio",
    proareas character(1),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".avisos_reinscripcion OWNER TO amaterasu;

--
-- Name: baja_cespeciales; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".baja_cespeciales (
    id integer NOT NULL,
    periodo "ITE"."T_periodo",
    no_de_control "ITE"."T_no_de_control",
    materia "ITE"."T_materia"
);


ALTER TABLE "ITE".baja_cespeciales OWNER TO amaterasu;

--
-- Name: baja_cespeciales_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".baja_cespeciales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".baja_cespeciales_id_seq OWNER TO amaterasu;

--
-- Name: baja_cespeciales_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".baja_cespeciales_id_seq OWNED BY "ITE".baja_cespeciales.id;


--
-- Name: carreras; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".carreras (
    carrera "ITE"."T_carrera" NOT NULL,
    reticula "ITE"."T_reticula" NOT NULL,
    nivel_escolar character(1) NOT NULL,
    clave_oficial character(20) NOT NULL,
    nombre_carrera character varying(80) NOT NULL,
    nombre_reducido character varying(30) NOT NULL,
    siglas character varying(10) NOT NULL,
    carga_maxima smallint NOT NULL,
    carga_minima smallint NOT NULL,
    creditos_totales smallint,
    modalidad character(1),
    nreal character varying(100),
    ofertar boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".carreras OWNER TO amaterasu;

--
-- Name: categorias; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".categorias (
    id integer NOT NULL,
    categoria character varying(8) NOT NULL,
    descripcion character varying(200) NOT NULL,
    horas integer,
    horas_grupo integer,
    nivel integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".categorias OWNER TO amaterasu;

--
-- Name: categorías_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE"."categorías_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE"."categorías_id_seq" OWNER TO amaterasu;

--
-- Name: categorías_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE"."categorías_id_seq" OWNED BY "ITE".categorias.id;


--
-- Name: entidades_federativas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".entidades_federativas (
    entidad_federativa smallint,
    nombre_entidad character varying(50),
    clave_entidad character(2)
);


ALTER TABLE "ITE".entidades_federativas OWNER TO amaterasu;

--
-- Name: especialidades; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".especialidades (
    especialidad "ITE"."T_especialidad" NOT NULL,
    carrera "ITE"."T_carrera" NOT NULL,
    reticula "ITE"."T_reticula" NOT NULL,
    nombre_especialidad character varying(100) NOT NULL,
    creditos_optativos smallint,
    creditos_especialidad smallint NOT NULL,
    activa boolean,
    nombre_corto character varying(60) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".especialidades OWNER TO amaterasu;

--
-- Name: estatus_alumno; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".estatus_alumno (
    estatus character(3) NOT NULL,
    descripcion character(100) NOT NULL
);


ALTER TABLE "ITE".estatus_alumno OWNER TO amaterasu;

--
-- Name: evaluacion_alumnos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".evaluacion_alumnos (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    grupo character(3),
    rfc character varying(13),
    clave_area character(6),
    encuesta character(1),
    respuestas character varying(50),
    resp_abierta character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".evaluacion_alumnos OWNER TO amaterasu;

--
-- Name: evaluacion_aspectos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".evaluacion_aspectos (
    aspecto character varying(1) NOT NULL,
    encuesta character varying(1) NOT NULL,
    descripcion character varying(255),
    consecutivo smallint NOT NULL
);


ALTER TABLE "ITE".evaluacion_aspectos OWNER TO amaterasu;

--
-- Name: failed_jobs; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".failed_jobs (
    id bigint NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "ITE".failed_jobs OWNER TO amaterasu;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".failed_jobs_id_seq OWNER TO amaterasu;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".failed_jobs_id_seq OWNED BY "ITE".failed_jobs.id;


--
-- Name: fecha_evaluacion; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".fecha_evaluacion (
    id integer NOT NULL,
    periodo "ITE"."T_periodo" NOT NULL,
    encuesta character(1) NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_final date NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".fecha_evaluacion OWNER TO amaterasu;

--
-- Name: fecha_evaluacion_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".fecha_evaluacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".fecha_evaluacion_id_seq OWNER TO amaterasu;

--
-- Name: fecha_evaluacion_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".fecha_evaluacion_id_seq OWNED BY "ITE".fecha_evaluacion.id;


--
-- Name: fechas_carreras; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".fechas_carreras (
    carrera "ITE"."T_carrera",
    fecha_inscripcion date,
    fecha_inicio time without time zone,
    fecha_fin time without time zone,
    intervalo smallint,
    personas smallint,
    periodo "ITE"."T_periodo",
    puntero smallint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".fechas_carreras OWNER TO amaterasu;

--
-- Name: fichas_configuracion; Type: TABLE; Schema: ITE; Owner: postgres
--

CREATE TABLE "ITE".fichas_configuracion (
    periodo "ITE"."T_periodo" NOT NULL,
    fecha_inicio_solicitudes timestamp without time zone NOT NULL,
    fecha_termino_solicitudes timestamp without time zone NOT NULL,
    fecha_examen_ceneval timestamp without time zone NOT NULL,
    direccion_url_ceneval character varying(200) NOT NULL,
    hora_examen_ceneval character varying(5) NOT NULL,
    hora_inicio_dia_atencion character varying(5) NOT NULL,
    hora_fin_dia_atencion character varying(5) NOT NULL,
    folios_por_dia_atencion integer NOT NULL,
    costo_examen integer NOT NULL,
    banco character varying(20) NOT NULL,
    cuenta character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".fichas_configuracion OWNER TO postgres;

--
-- Name: folio_constancias; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".folio_constancias (
    id integer NOT NULL,
    folio integer,
    periodo "ITE"."T_periodo",
    control "ITE"."T_no_de_control",
    tipo character(2),
    fecha timestamp without time zone,
    anio character(4),
    quien character(30),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".folio_constancias OWNER TO amaterasu;

--
-- Name: folios_constancias_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".folios_constancias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".folios_constancias_id_seq OWNER TO amaterasu;

--
-- Name: folios_constancias_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".folios_constancias_id_seq OWNED BY "ITE".folio_constancias.id;


--
-- Name: generar_listas_temporales; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".generar_listas_temporales (
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    apellido_paterno character varying(100),
    apellido_materno character varying(100),
    nombre_alumno character varying(100),
    semestre smallint,
    fecha_hora_seleccion timestamp without time zone,
    promedio_ponderado numeric(7,3),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".generar_listas_temporales OWNER TO amaterasu;

--
-- Name: grupos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".grupos (
    periodo "ITE"."T_periodo" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    grupo character(3) NOT NULL,
    estatus_grupo character(1),
    capacidad_grupo smallint NOT NULL,
    alumnos_inscritos smallint,
    folio_acta "ITE"."T_folio_acta",
    paralelo_de character(10),
    exclusivo_carrera "ITE"."T_carrera",
    exclusivo_reticula "ITE"."T_reticula",
    rfc character(13),
    tipo_personal character(1),
    exclusivo character(2),
    entrego boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".grupos OWNER TO amaterasu;

--
-- Name: historia_alumno; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".historia_alumno (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    grupo character(3),
    calificacion "ITE"."T_calificacion",
    tipo_evaluacion character(2) NOT NULL,
    fecha_calificacion timestamp without time zone,
    plan_de_estudios character(1),
    estatus_materia character(1),
    nopresento character(1),
    usuario character(30),
    periodo_acredita_materia "ITE"."T_periodo",
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    fecha_actualizacion date
);


ALTER TABLE "ITE".historia_alumno OWNER TO amaterasu;

--
-- Name: horario_administrativo; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".horario_administrativo (
    periodo "ITE"."T_periodo",
    rfc character varying(13),
    consecutivo_admvo smallint,
    descripcion_horario integer,
    fcaptura date
);


ALTER TABLE "ITE".horario_administrativo OWNER TO amaterasu;

--
-- Name: horario_observaciones; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".horario_observaciones (
    periodo "ITE"."T_periodo",
    rfc character varying(13),
    observaciones character varying(400),
    depto character varying(6),
    cuando timestamp without time zone
);


ALTER TABLE "ITE".horario_observaciones OWNER TO amaterasu;

--
-- Name: horarios; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".horarios (
    periodo "ITE"."T_periodo" NOT NULL,
    rfc character(13),
    tipo_horario character(1) NOT NULL,
    dia_semana smallint NOT NULL,
    hora_inicial time without time zone NOT NULL,
    hora_final time without time zone,
    materia "ITE"."T_materia",
    grupo character(3),
    aula character(6),
    actividad character(10),
    consecutivo smallint,
    vigencia_inicio date,
    vigencia_fin date,
    consecutivo_admvo smallint,
    tipo_personal character(1),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".horarios OWNER TO amaterasu;

--
-- Name: idiomas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas (
    id integer NOT NULL,
    idiomas character(100),
    abrev character varying(5)
);


ALTER TABLE "ITE".idiomas OWNER TO amaterasu;

--
-- Name: idiomas_docentes; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas_docentes (
    id integer NOT NULL,
    rfc character varying(13),
    appat character varying(200),
    apmat character varying(200) NOT NULL,
    nombre character varying(200) NOT NULL,
    status character(1) NOT NULL
);


ALTER TABLE "ITE".idiomas_docentes OWNER TO amaterasu;

--
-- Name: idiomas_docentes_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".idiomas_docentes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".idiomas_docentes_id_seq OWNER TO amaterasu;

--
-- Name: idiomas_docentes_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".idiomas_docentes_id_seq OWNED BY "ITE".idiomas_docentes.id;


--
-- Name: idiomas_grupos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas_grupos (
    id integer NOT NULL,
    periodo "ITE"."T_periodo" NOT NULL,
    idioma smallint NOT NULL,
    clave character varying(6) NOT NULL,
    nombre_completo character varying(255) NOT NULL,
    nombre_abrev character varying(200) NOT NULL,
    ya_eval boolean
);


ALTER TABLE "ITE".idiomas_grupos OWNER TO amaterasu;

--
-- Name: idiomas_grupos_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".idiomas_grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".idiomas_grupos_id_seq OWNER TO amaterasu;

--
-- Name: idiomas_grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".idiomas_grupos_id_seq OWNED BY "ITE".idiomas_grupos.id;


--
-- Name: idiomas_horario; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas_horario (
    periodo "ITE"."T_periodo" NOT NULL,
    idioma smallint NOT NULL,
    lun_ini character varying(5),
    lun_fin character varying(5),
    mar_ini character varying(5),
    mar_fin character varying(5),
    mie_ini character varying(5),
    mie_fin character varying(5),
    jue_ini character varying(5),
    jue_fin character varying(5),
    vie_ini character varying(5),
    vie_fin character varying(5),
    sab_ini character varying(5),
    sab_fin character varying(5),
    clave integer NOT NULL,
    asesor integer,
    lugar character varying(200) NOT NULL,
    capacidad integer
);


ALTER TABLE "ITE".idiomas_horario OWNER TO amaterasu;

--
-- Name: idiomas_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".idiomas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".idiomas_id_seq OWNER TO amaterasu;

--
-- Name: idiomas_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".idiomas_id_seq OWNED BY "ITE".idiomas.id;


--
-- Name: idiomas_inscripcion; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas_inscripcion (
    periodo "ITE"."T_periodo" NOT NULL,
    control "ITE"."T_no_de_control" NOT NULL,
    carrera "ITE"."T_carrera" NOT NULL,
    reticula "ITE"."T_reticula" NOT NULL,
    idioma integer NOT NULL,
    clave integer NOT NULL,
    calif "ITE"."T_calificacion",
    fecha_hora_selecc timestamp without time zone NOT NULL,
    quien character varying(200) NOT NULL
);


ALTER TABLE "ITE".idiomas_inscripcion OWNER TO amaterasu;

--
-- Name: idiomas_liberacion; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".idiomas_liberacion (
    periodo "ITE"."T_periodo",
    control "ITE"."T_no_de_control" NOT NULL,
    calif "ITE"."T_calificacion",
    liberacion date,
    idioma integer NOT NULL,
    opcion character(1) NOT NULL
);


ALTER TABLE "ITE".idiomas_liberacion OWNER TO amaterasu;

--
-- Name: jefes; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".jefes (
    clave_area character(6) NOT NULL,
    descripcion_area character varying(200),
    jefe_area character varying(70),
    rfc character varying(13),
    correo character varying(200),
    ext character varying(4),
    correo2 character varying(200)
);


ALTER TABLE "ITE".jefes OWNER TO amaterasu;

--
-- Name: materias; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".materias (
    materia "ITE"."T_materia" NOT NULL,
    nivel_escolar character(1),
    tipo_materia smallint,
    clave_area character(6),
    nombre_completo_materia character varying(100) NOT NULL,
    nombre_abreviado_materia character varying(40) NOT NULL,
    caracterizacion text,
    generales text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".materias OWNER TO amaterasu;

--
-- Name: materias_carreras; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".materias_carreras (
    carrera "ITE"."T_carrera" NOT NULL,
    reticula "ITE"."T_reticula" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    creditos_materia smallint,
    horas_teoricas smallint NOT NULL,
    horas_practicas smallint NOT NULL,
    orden_certificado smallint,
    semestre_reticula smallint NOT NULL,
    creditos_prerrequisito smallint,
    especialidad "ITE"."T_especialidad",
    clave_oficial_materia character(10),
    renglon smallint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".materias_carreras OWNER TO amaterasu;

--
-- Name: migrations; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE "ITE".migrations OWNER TO amaterasu;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".migrations_id_seq OWNER TO amaterasu;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".migrations_id_seq OWNED BY "ITE".migrations.id;


--
-- Name: motivos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".motivos (
    id integer NOT NULL,
    motivo character varying(2) NOT NULL,
    descripcion character varying(200) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".motivos OWNER TO amaterasu;

--
-- Name: motivos_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".motivos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".motivos_id_seq OWNER TO amaterasu;

--
-- Name: motivos_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".motivos_id_seq OWNED BY "ITE".motivos.id;


--
-- Name: municipios; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".municipios (
    id integer NOT NULL,
    id_estado integer NOT NULL,
    id_municipio integer NOT NULL,
    municipio character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".municipios OWNER TO amaterasu;

--
-- Name: municipios_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".municipios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".municipios_id_seq OWNER TO amaterasu;

--
-- Name: municipios_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".municipios_id_seq OWNED BY "ITE".municipios.id;


--
-- Name: nivel_escolar; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".nivel_escolar (
    nivel_escolar character(1),
    descripcion_nivel character(50)
);


ALTER TABLE "ITE".nivel_escolar OWNER TO amaterasu;

--
-- Name: organigrama; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".organigrama (
    clave_area character(6) NOT NULL,
    descripcion_area character varying(200),
    area_depende character(6),
    siglas character(5)
);


ALTER TABLE "ITE".organigrama OWNER TO amaterasu;

--
-- Name: parametros; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".parametros (
    id integer NOT NULL,
    ciudad text NOT NULL,
    tec text NOT NULL
);


ALTER TABLE "ITE".parametros OWNER TO amaterasu;

--
-- Name: parametros_fichas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".parametros_fichas (
    id integer NOT NULL,
    fichas "ITE"."T_periodo" NOT NULL,
    activo boolean NOT NULL,
    inicio_prope date,
    fin_prope date,
    entrega date,
    termina date,
    created_at date,
    updated_at date
);


ALTER TABLE "ITE".parametros_fichas OWNER TO amaterasu;

--
-- Name: parametros_fichas_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".parametros_fichas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".parametros_fichas_id_seq OWNER TO amaterasu;

--
-- Name: parametros_fichas_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".parametros_fichas_id_seq OWNED BY "ITE".parametros_fichas.id;


--
-- Name: parametros_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".parametros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".parametros_id_seq OWNER TO amaterasu;

--
-- Name: parametros_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".parametros_id_seq OWNED BY "ITE".parametros.id;


--
-- Name: password_resets; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE "ITE".password_resets OWNER TO amaterasu;

--
-- Name: permisos_carreras; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".permisos_carreras (
    carrera "ITE"."T_carrera",
    reticula "ITE"."T_reticula",
    nombre_carrera character varying(150),
    nombre_reducido character varying(100),
    email character varying(150)
);


ALTER TABLE "ITE".permisos_carreras OWNER TO amaterasu;

--
-- Name: personal; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal (
    id integer NOT NULL,
    rfc character(13) NOT NULL,
    clave_area character(6),
    curp_empleado character(18),
    no_tarjeta integer,
    apellidos_empleado character(200),
    nombre_empleado character(100),
    nombramiento character(1) NOT NULL,
    ingreso_rama character(6),
    inicio_gobierno character(6),
    inicio_sep character(6),
    inicio_plantel character(6),
    domicilio_empleado character varying(150),
    colonia_empleado character varying(100),
    codigo_postal_empleado integer,
    telefono_empleado character varying(30),
    sexo_empleado character(1),
    estado_civil character(1),
    status_empleado character(2),
    correo_electronico character varying(150),
    correo_institucion character varying(150),
    apellido_paterno character varying(100),
    apellido_materno character varying(100),
    siglas character(5),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal OWNER TO amaterasu;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE "ITE".personal_access_tokens OWNER TO amaterasu;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_access_tokens_id_seq OWNER TO amaterasu;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_access_tokens_id_seq OWNED BY "ITE".personal_access_tokens.id;


--
-- Name: personal_carreras; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_carreras (
    id integer NOT NULL,
    carrera text NOT NULL,
    nombre_corto character varying(200) NOT NULL,
    siglas character varying(5) NOT NULL,
    nivel character(1),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_carreras OWNER TO amaterasu;

--
-- Name: personal_carreras_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_carreras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_carreras_id_seq OWNER TO amaterasu;

--
-- Name: personal_carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_carreras_id_seq OWNED BY "ITE".personal_carreras.id;


--
-- Name: personal_datos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_datos (
    id integer NOT NULL,
    campo character varying(50) NOT NULL,
    lectura character varying(60) NOT NULL,
    tabla character varying(50) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_datos OWNER TO amaterasu;

--
-- Name: personal_datos_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_datos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_datos_id_seq OWNER TO amaterasu;

--
-- Name: personal_datos_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_datos_id_seq OWNED BY "ITE".personal_datos.id;


--
-- Name: personal_estudios; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_estudios (
    id integer NOT NULL,
    id_docente integer NOT NULL,
    fecha_inicio date,
    fecha_final date,
    id_carrera integer,
    id_escuela integer,
    cedula character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_estudios OWNER TO amaterasu;

--
-- Name: personal_estudios_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_estudios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_estudios_id_seq OWNER TO amaterasu;

--
-- Name: personal_estudios_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_estudios_id_seq OWNED BY "ITE".personal_estudios.id;


--
-- Name: personal_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_id_seq OWNER TO amaterasu;

--
-- Name: personal_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_id_seq OWNED BY "ITE".personal.id;


--
-- Name: personal_instit_estudios; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_instit_estudios (
    id integer NOT NULL,
    id_escuela integer NOT NULL,
    id_estado integer NOT NULL,
    id_municipio integer,
    nombre text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_instit_estudios OWNER TO amaterasu;

--
-- Name: personal_instit_estudio_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_instit_estudio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_instit_estudio_id_seq OWNER TO amaterasu;

--
-- Name: personal_instit_estudio_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_instit_estudio_id_seq OWNED BY "ITE".personal_instit_estudios.id;


--
-- Name: personal_nivel_estudios; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_nivel_estudios (
    id integer NOT NULL,
    caracter character(1) NOT NULL,
    descripcion character varying(60) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_nivel_estudios OWNER TO amaterasu;

--
-- Name: personal_nivel_estudios_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_nivel_estudios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_nivel_estudios_id_seq OWNER TO amaterasu;

--
-- Name: personal_nivel_estudios_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_nivel_estudios_id_seq OWNED BY "ITE".personal_nivel_estudios.id;


--
-- Name: personal_nombramientos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_nombramientos (
    id integer NOT NULL,
    letra character(1) NOT NULL,
    descripcion character varying(50) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_nombramientos OWNER TO amaterasu;

--
-- Name: personal_nombramientos_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_nombramientos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_nombramientos_id_seq OWNER TO amaterasu;

--
-- Name: personal_nombramientos_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_nombramientos_id_seq OWNED BY "ITE".personal_nombramientos.id;


--
-- Name: personal_plazas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".personal_plazas (
    id integer NOT NULL,
    id_personal integer NOT NULL,
    unidad character varying(2) NOT NULL,
    subunidad character varying(2) NOT NULL,
    id_categoria integer NOT NULL,
    horas integer NOT NULL,
    diagonal character varying(6) NOT NULL,
    estatus_plaza character varying(2) NOT NULL,
    id_motivo integer NOT NULL,
    efectos_iniciales character varying(6) NOT NULL,
    efectos_finales character varying(6) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".personal_plazas OWNER TO amaterasu;

--
-- Name: personal_plazas_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".personal_plazas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".personal_plazas_id_seq OWNER TO amaterasu;

--
-- Name: personal_plazas_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".personal_plazas_id_seq OWNED BY "ITE".personal_plazas.id;


--
-- Name: planes_de_estudio; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".planes_de_estudio (
    plan_de_estudio character(1) NOT NULL,
    descripcion character(100) NOT NULL
);


ALTER TABLE "ITE".planes_de_estudio OWNER TO amaterasu;

--
-- Name: preficha; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".preficha (
    no_recibo integer NOT NULL,
    fecha_registro date,
    instituto character(50),
    apellido_paterno "ITE"."T_apellidos_persona",
    apellido_materno "ITE"."T_apellidos_persona" NOT NULL,
    nombre_aspirante character varying(255) NOT NULL,
    nip integer NOT NULL,
    fecha_nacimiento date,
    sexo "ITE"."T_sexo",
    nacionalidad character(1),
    especifique_extranjero character(20),
    curp "ITE"."T_curp",
    carrera_opcion_1 "ITE"."T_carrera",
    entidad_federativa_prepa "ITE"."T_lugar_nac",
    clave_preparatoria character varying(15),
    agnio_egreso integer,
    promedio_general "ITE"."T_promedio",
    calle_no character varying(80),
    entidad_federativa "ITE"."T_lugar_nac",
    municipio "ITE"."T_ciudad",
    codigo_postal character varying(5),
    colonia_aspirante character varying(40),
    correo_electronico character varying(60),
    telefono character varying(30),
    estado_civil "ITE"."T_estado_civil",
    capacidad_diferente character(1),
    tienes_beca character(1),
    quien_otorgo character(30),
    zona_procedencia character(1),
    especifique_zona_procedencia character(30),
    programa_oportunidades character(1),
    apellido_paterno_padre "ITE"."T_apellidos_persona",
    apellido_materno_padre "ITE"."T_apellidos_persona",
    nombre_padre_aspirante character varying(50),
    vive_padre character(1),
    apellido_paterno_madre "ITE"."T_apellidos_persona",
    apellido_materno_madre "ITE"."T_apellidos_persona",
    nombre_madre_aspirante character varying(50),
    vive_madre character(1),
    fecha_atencion date,
    hora_atencion character(50),
    no_solicitud integer NOT NULL,
    periodo "ITE"."T_periodo" NOT NULL,
    itmin character(9),
    folio_ceneval integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".preficha OWNER TO amaterasu;

--
-- Name: preguntas; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".preguntas (
    encuesta character varying(1) NOT NULL,
    aspecto character varying(1) NOT NULL,
    no_pregunta integer NOT NULL,
    pregunta character varying(300),
    respuestas character varying(150),
    resp_val integer,
    consecutivo integer NOT NULL
);


ALTER TABLE "ITE".preguntas OWNER TO amaterasu;

--
-- Name: preparatorias; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".preparatorias (
    clave_preparatoria character(10) NOT NULL,
    nombre_preparatoria character(200) NOT NULL,
    entidad_federativa integer NOT NULL,
    municipio character(50)
);


ALTER TABLE "ITE".preparatorias OWNER TO amaterasu;

--
-- Name: puestos; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".puestos (
    clave_puesto integer,
    descripcion_puesto character varying(200)
);


ALTER TABLE "ITE".puestos OWNER TO amaterasu;

--
-- Name: requisitos_materia; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".requisitos_materia (
    carrera "ITE"."T_carrera" NOT NULL,
    reticula "ITE"."T_reticula" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    materia_relacion "ITE"."T_materia" NOT NULL,
    tipo_requisito "char"
);


ALTER TABLE "ITE".requisitos_materia OWNER TO amaterasu;

--
-- Name: role_user; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".role_user (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE "ITE".role_user OWNER TO amaterasu;

--
-- Name: role_user_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".role_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".role_user_id_seq OWNER TO amaterasu;

--
-- Name: role_user_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".role_user_id_seq OWNED BY "ITE".role_user.id;


--
-- Name: roles; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE "ITE".roles OWNER TO amaterasu;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".roles_id_seq OWNER TO amaterasu;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".roles_id_seq OWNED BY "ITE".roles.id;


--
-- Name: seleccion_materias; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".seleccion_materias (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    grupo character(3) NOT NULL,
    calificacion "ITE"."T_calificacion",
    tipo_evaluacion character(2),
    repeticion character(1),
    nopresento character(1),
    status_seleccion character(1),
    fecha_hora_seleccion timestamp without time zone,
    global character(1),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE "ITE".seleccion_materias OWNER TO amaterasu;

--
-- Name: seleccion_materias_log; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".seleccion_materias_log (
    periodo "ITE"."T_periodo" NOT NULL,
    no_de_control "ITE"."T_no_de_control" NOT NULL,
    materia "ITE"."T_materia" NOT NULL,
    grupo character varying(3) NOT NULL,
    movimiento character(1) NOT NULL,
    cuando timestamp without time zone NOT NULL,
    responsable character varying(150) NOT NULL
);


ALTER TABLE "ITE".seleccion_materias_log OWNER TO amaterasu;

--
-- Name: sessions; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE "ITE".sessions OWNER TO amaterasu;

--
-- Name: socioecono; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".socioecono (
    nivel_estudios_padre integer,
    nivel_estudios_madre integer,
    con_quien_vives integer,
    ingresos_padre integer,
    ingresos_madre integer,
    ingresos_hermanos integer,
    ingresos_propios integer,
    total_ingresos integer,
    ocupacion_padre integer,
    ocupacion_madre integer,
    de_quien_dependes integer,
    casa_vives character(1),
    cuartos_casa integer,
    personas_casa integer,
    personas_dependen integer,
    tipo_sangre character(20),
    comunicar_con character(80),
    calle_no character(80),
    colonia character(40),
    codigo_postal character(5),
    municipio "ITE"."T_ciudad",
    entidad_federativa "ITE"."T_lugar_nac",
    telefono character(30),
    lugar_trabajo character(50),
    telefono_trabajo character(30),
    no_solicitud integer NOT NULL,
    periodo "ITE"."T_periodo" NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tipo_alergia character varying(200),
    enfermedad character varying(200)
);


ALTER TABLE "ITE".socioecono OWNER TO amaterasu;

--
-- Name: sol_ds_de_quien_dependes; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".sol_ds_de_quien_dependes (
    de_quien integer NOT NULL,
    descripcion character(30) NOT NULL
);


ALTER TABLE "ITE".sol_ds_de_quien_dependes OWNER TO amaterasu;

--
-- Name: sol_ds_estudios_padres; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".sol_ds_estudios_padres (
    nivel_estudios integer NOT NULL,
    descripcion character(60) NOT NULL
);


ALTER TABLE "ITE".sol_ds_estudios_padres OWNER TO amaterasu;

--
-- Name: tipo_materia; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".tipo_materia (
    tipo_materia smallint,
    nombre_tipo character(120)
);


ALTER TABLE "ITE".tipo_materia OWNER TO amaterasu;

--
-- Name: tipos_evaluacion; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".tipos_evaluacion (
    plan_de_estudios character(1) NOT NULL,
    tipo_evaluacion character(2) NOT NULL,
    descripcion_evaluacion character varying(80),
    descripcion_corta_evaluacion character varying(10),
    calif_minima_aprobatoria smallint,
    usocurso character(1),
    nosegundas character(1),
    prioridad smallint
);


ALTER TABLE "ITE".tipos_evaluacion OWNER TO amaterasu;

--
-- Name: tipos_ingreso; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".tipos_ingreso (
    id smallint NOT NULL,
    descripcion character(20) NOT NULL
);


ALTER TABLE "ITE".tipos_ingreso OWNER TO amaterasu;

--
-- Name: users; Type: TABLE; Schema: ITE; Owner: amaterasu
--

CREATE TABLE "ITE".users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    two_factor_secret text
);


ALTER TABLE "ITE".users OWNER TO amaterasu;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: ITE; Owner: amaterasu
--

CREATE SEQUENCE "ITE".users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ITE".users_id_seq OWNER TO amaterasu;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: ITE; Owner: amaterasu
--

ALTER SEQUENCE "ITE".users_id_seq OWNED BY "ITE".users.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO amaterasu;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO amaterasu;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO amaterasu;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: amaterasu
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO amaterasu;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amaterasu
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO amaterasu;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO amaterasu;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: amaterasu
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO amaterasu;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amaterasu
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO amaterasu;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: amaterasu
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO amaterasu;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amaterasu
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO amaterasu;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO amaterasu;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: amaterasu
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO amaterasu;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amaterasu
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO amaterasu;

--
-- Name: users; Type: TABLE; Schema: public; Owner: amaterasu
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    current_team_id bigint,
    profile_photo_path character varying(2048),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    two_factor_secret text,
    two_factor_recovery_codes text,
    two_factor_confirmed_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO amaterasu;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: amaterasu
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO amaterasu;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amaterasu
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: aulas id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".aulas ALTER COLUMN id SET DEFAULT nextval('"ITE".aulas_id_seq'::regclass);


--
-- Name: aulas_aspirantes id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".aulas_aspirantes ALTER COLUMN id SET DEFAULT nextval('"ITE".aulas_aspirantes_id_seq'::regclass);


--
-- Name: baja_cespeciales id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".baja_cespeciales ALTER COLUMN id SET DEFAULT nextval('"ITE".baja_cespeciales_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".categorias ALTER COLUMN id SET DEFAULT nextval('"ITE"."categorías_id_seq"'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".failed_jobs ALTER COLUMN id SET DEFAULT nextval('"ITE".failed_jobs_id_seq'::regclass);


--
-- Name: fecha_evaluacion id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".fecha_evaluacion ALTER COLUMN id SET DEFAULT nextval('"ITE".fecha_evaluacion_id_seq'::regclass);


--
-- Name: folio_constancias id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".folio_constancias ALTER COLUMN id SET DEFAULT nextval('"ITE".folios_constancias_id_seq'::regclass);


--
-- Name: idiomas id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas ALTER COLUMN id SET DEFAULT nextval('"ITE".idiomas_id_seq'::regclass);


--
-- Name: idiomas_docentes id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_docentes ALTER COLUMN id SET DEFAULT nextval('"ITE".idiomas_docentes_id_seq'::regclass);


--
-- Name: idiomas_grupos id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_grupos ALTER COLUMN id SET DEFAULT nextval('"ITE".idiomas_grupos_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".migrations ALTER COLUMN id SET DEFAULT nextval('"ITE".migrations_id_seq'::regclass);


--
-- Name: motivos id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".motivos ALTER COLUMN id SET DEFAULT nextval('"ITE".motivos_id_seq'::regclass);


--
-- Name: municipios id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".municipios ALTER COLUMN id SET DEFAULT nextval('"ITE".municipios_id_seq'::regclass);


--
-- Name: parametros id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".parametros ALTER COLUMN id SET DEFAULT nextval('"ITE".parametros_id_seq'::regclass);


--
-- Name: parametros_fichas id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".parametros_fichas ALTER COLUMN id SET DEFAULT nextval('"ITE".parametros_fichas_id_seq'::regclass);


--
-- Name: personal id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_access_tokens_id_seq'::regclass);


--
-- Name: personal_carreras id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_carreras ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_carreras_id_seq'::regclass);


--
-- Name: personal_datos id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_datos ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_datos_id_seq'::regclass);


--
-- Name: personal_estudios id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_estudios ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_estudios_id_seq'::regclass);


--
-- Name: personal_instit_estudios id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_instit_estudios ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_instit_estudio_id_seq'::regclass);


--
-- Name: personal_nivel_estudios id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_nivel_estudios ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_nivel_estudios_id_seq'::regclass);


--
-- Name: personal_nombramientos id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_nombramientos ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_nombramientos_id_seq'::regclass);


--
-- Name: personal_plazas id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_plazas ALTER COLUMN id SET DEFAULT nextval('"ITE".personal_plazas_id_seq'::regclass);


--
-- Name: role_user id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".role_user ALTER COLUMN id SET DEFAULT nextval('"ITE".role_user_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".roles ALTER COLUMN id SET DEFAULT nextval('"ITE".roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".users ALTER COLUMN id SET DEFAULT nextval('"ITE".users_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: actividades_apoyo; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".actividades_apoyo (actividad, descripcion_actividad) FROM stdin;
AA	ASESORIA A ALUMNOS
AA01	REALIZACION DE ACTIVIDADES ADMINISTRATIVAS
AD	PREPARACION CONTROL Y EVALUACION DE CLASES
ANL	ANALISTA
AP01	DISEÑO CONST. INST. OPE. Y CONS. DE EQUIPO Y DISP
AP02	DISEÑO CONST. INST. OPE. Y CONS. DE SISTEMAS
ARP	ASESORIA DE RESIDENCIAS PROFESIONALES/PRACTICAS PROFESIONALES
ART	ASESORIA Y REVISION DE TRABAJO PARA TITULACION
ATP	ASESORIA DE TESIS DE POSGRADO
AUX	AUXILIAR
CA01	REV. ACT. Y  ELAB. DE PLANES Y PROG. DE ESTUDIO
CA02	ELABORACION DE APUNTES NOTAS Y TEXTOS DE ASESORIA
CA03	ELABORACION DE MATERIAL DIDACTICO
CA04	DIRECCION O ASESORIA DE TESIS
CA05	COORD. DE PRACTICAS O RESIDENCIAS PROFESIONALES
CA06	COORDINACION DE SERVICIO SOCIAL
CA07	ASISTENCIA A REUNIONES DE ACADEMIA
CA08	ASISTENCIA A REUNIONES DE DEPARTAMENTO
CA09	SINODALIA DE EXAMENES PROFESIONALES Y DE OPOSICION
CA10	IMPARTICION DE CURSOS EXTRACURRICULARES
CA11	IMPARTICION DE SEMINARIOS CONFERENCIAS ETC.
CA12	REALIZACION DE SERVICIO EXTERNO Y DE APOYO A COM.
CA13	SUPERVISION DE LA ENSEÑANZA
CAP	CAPTURISTA
CE	CENTRO DE EVALUACION DE PYMES
CHO	CHOFER
CO	COORDINACION
DAT	DIRECCION O ASESORIA DE TESIS
DC01	DIFUSION DE LA CULTURA (ESPECIFICAR)
DIR	DIRECTOR
DO01	PREPARACION DE CLASES
DO02	PREPARACION DE PRACTICAS
DO03	ATENCION DE ALUMNOS
DO04	ELABORACION DE EXAMENES
DO05	EVALUACION DE EXAMENES
DOC	ESTUDIOS DE DOCTORADO
DTUD	DIFERENCIA TABULADOR UNICO DE DIRECTIVO
EE	ELABORACION DE EXAMENES
EMD	ELABORACION DE MATERIAL DIDACTICO
ENC	ENCARGADO DEL LABORATORIO DE ECOTOXICOLOGIA
EO	ENCARGADA DE OFICINA
EVE	EVALUACION DE EXAMENES
FOT	FOTOGRAFO
IN01	REALIZACION DE PROYECTOS DE INVESTIGACION
JD	JEFE DE DEPARTAMENTO
JL	JEFE DE LABORATORIO
JO	JEFATURA DE OFICINA
JP	JEFE DE PROYECTO
L	HORAS DE LACTANCIA
ME	MEDICO ESCOLAR
OP	OPERADOR
OT01	OTRAS:
PA	PRESIDENTE DE ACADEMIA
PI	PROYECTO INDIVIDUAL
PP	PREPARACION DE PRACTICAS
PPE	REVISION ACTUALIZACION Y ELABORACION DE PLANES Y PROGRAMAS DE ESTUDIO
PRE	PREFECTO
PRG	PROGRAMADOR
PRM	PROMOTOR
RPI	REALIZACION DE PROYECTOS DE INVESTIGACION
SA	SECRETARIO DE ACADEMIA
SA01	REALIZACION DE ESTUDIOS DE ACTUALIZACION
SA02	REALIZACION DE ESTUDIOS DE ESPECIALIZACION
SA03	REALIZACION DE ESTUDIOS DE MAESTRIA
SA04	REALIZACION DE ESTUDIOS DE DOCTORADO
SA05	ASISTENCIA A EVENTOS ACADEMICOS
SA06	REALIZACION DE CURSOS DE IDIOMAS
SEC	SECRETARIA
SET	SUPERVISOR DE EQUIPO DE TELECOMUNICACIONES
SG	SEGUIMIENTO DE EGRESADOS
SUB	SUBDIRECTOR
T	TUTORIAS
TM	TECNICO EN MATENIMIENTO
TP	TUTORIA PRONABE
\.


--
-- Data for Name: acumulado_historico; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".acumulado_historico (periodo, no_de_control, estatus_periodo_alumno, creditos_cursados, creditos_aprobados, promedio_ponderado, promedio_ponderado_acumulado, promedio_aritmetico, promedio_aritmetico_acumulado, promedio_certificado, materias_cursadas, materias_reprobadas, materias_a_examen_especial, materias_especial_reprobadas, indice_reprobacion_semestre, creditos_autorizados, indice_reprobacion_acumulado) FROM stdin;
\.


--
-- Data for Name: alumnos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".alumnos (no_de_control, carrera, reticula, especialidad, nivel_escolar, semestre, estatus_alumno, plan_de_estudios, apellido_paterno, apellido_materno, nombre_alumno, curp_alumno, fecha_nacimiento, sexo, estado_civil, tipo_ingreso, periodo_ingreso_it, ultimo_periodo_inscrito, promedio_periodo_anterior, promedio_aritmetico_acumulado, creditos_aprobados, creditos_cursados, promedio_final_alcanzado, escuela_procedencia, entidad_procedencia, ciudad_procedencia, correo_electronico, periodos_revalidacion, becado_por, nip, fecha_titulacion, opcion_titulacion, periodo_titulacion, nss, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alumnos_generales; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".alumnos_generales (no_de_control, domicilio_calle, domicilio_colonia, codigo_postal, telefono, facebook, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: apoyo_docencia; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".apoyo_docencia (periodo, rfc, actividad, consecutivo, especifica_actividad) FROM stdin;
\.


--
-- Data for Name: aulas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".aulas (id, aula, ubicacion, capacidad, estatus, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: aulas_aspirantes; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".aulas_aspirantes (id, periodo, aula, capacidad, disponibles, carrera, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: avisos_reinscripcion; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".avisos_reinscripcion (periodo, no_de_control, autoriza_escolar, recibo_pago, fecha_recibo, cuenta_pago, fecha_hora_seleccion, lugar_seleccion, fecha_hora_pago, lugar_pago, adeuda_escolar, adeuda_biblioteca, adeuda_financieros, otro_mensaje, baja, motivo_aviso_baja, egresa, encuesto, vobo_adelanta_sel, regular, indice_reprobacion, creditos_autorizados, estatus_reinscripcion, semestre, promedio, adeudo_especial, promedio_acumulado, proareas, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: baja_cespeciales; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".baja_cespeciales (id, periodo, no_de_control, materia) FROM stdin;
\.


--
-- Data for Name: carreras; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".carreras (carrera, reticula, nivel_escolar, clave_oficial, nombre_carrera, nombre_reducido, siglas, carga_maxima, carga_minima, creditos_totales, modalidad, nreal, ofertar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".categorias (id, categoria, descripcion, horas, horas_grupo, nivel, created_at, updated_at) FROM stdin;
345	A9001	SECRETARIA BILINGUE -A-	36	\N	\N	2024-07-04 14:49:00	\N
346	A9002	SECRETARIA BILINGUE -B-	36	\N	\N	2024-07-04 14:49:01	\N
347	A9003	SECRETARIA BILINGUE -C-	36	\N	\N	2024-07-04 14:49:02	\N
348	A9004	SECRETARIA FUNCION. -A-	36	\N	\N	2024-07-04 14:49:03	\N
349	A9005	SECRETARIA FUNCION. -B-	36	\N	\N	2024-07-04 14:49:04	\N
350	A9006	SECRETARIA FUNCION. -C-	36	\N	\N	2024-07-04 14:49:05	\N
351	A9007	SECRETARIA JEFE DEPTO. -A-	36	\N	\N	2024-07-04 14:49:06	\N
352	A9008	SECRETARIA JEFE DEPTO. -B-	36	\N	\N	2024-07-04 14:49:07	\N
353	A9009	SECRETARIA JEFE DEPTO. -C-	36	\N	\N	2024-07-04 14:49:08	\N
354	A9010	TAQUIMECANOGRAFA -A-	36	\N	\N	2024-07-04 14:49:09	\N
355	A9011	TAQUIMECANOGRAFA -B-	36	\N	\N	2024-07-04 14:49:10	\N
356	A9012	TAQUIMECANOGRAFA -C-	36	\N	\N	2024-07-04 14:49:11	\N
357	A9013	MECANOGRAFA -A-	36	\N	\N	2024-07-04 14:49:12	\N
358	A9014	MECANOGRAFA -B-	36	\N	\N	2024-07-04 14:49:13	\N
359	A9015	MECANOGRAFA -C-	36	\N	\N	2024-07-04 14:49:14	\N
360	A9101	OFI.ADMINIS.ESP. -A-	36	\N	\N	2024-07-04 14:49:15	\N
361	A9102	OFI.ADMINIS.ESP. -B-	36	\N	\N	2024-07-04 14:49:16	\N
362	A9103	OFI.ADMINIS.ESP. -C-	36	\N	\N	2024-07-04 14:49:17	\N
363	A9104	OFI.ADMINIS. -A-	36	\N	\N	2024-07-04 14:49:18	\N
364	A9105	OFI.ADMINIS. -B-	36	\N	\N	2024-07-04 14:49:19	\N
365	A9106	OFI.ADMINIS. -C-	36	\N	\N	2024-07-04 14:49:20	\N
366	A9107	AUX.ADMINIS -A-	36	\N	\N	2024-07-04 14:49:21	\N
367	A9108	AUX.ADMINIS. -B-	36	\N	\N	2024-07-04 14:49:22	\N
368	A9109	AUX.ADMINIS. -C-	36	\N	\N	2024-07-04 14:49:23	\N
369	E3501	PREINCORPORADO -A-	1	\N	\N	2024-07-04 14:49:24	\N
370	E3503	PREINCORPORADO -B-	3	\N	\N	2024-07-04 14:49:25	\N
371	E3505	TEC. DOC. (ES) -A-	1	1	\N	2024-07-04 14:49:26	\N
372	E3505	TEC. DOC. (ES) -A-	2	2	\N	2024-07-04 14:49:27	\N
373	E3505	TEC. DOC. (ES) -A-	3	3	\N	2024-07-04 14:49:28	\N
374	E3505	TEC. DOC. (ES) -A-	4	4	\N	2024-07-04 14:49:29	\N
375	E3505	TEC. DOC. (ES) -A-	5	5	\N	2024-07-04 14:49:30	\N
376	E3505	TEC. DOC. (ES) -A-	6	6	\N	2024-07-04 14:49:31	\N
377	E3505	TEC. DOC. (ES) -A-	7	7	\N	2024-07-04 14:49:32	\N
378	E3505	TEC. DOC. (ES) -A-	8	8	\N	2024-07-04 14:49:33	\N
379	E3505	TEC. DOC. (ES) -A-	9	9	\N	2024-07-04 14:49:34	\N
380	E3505	TEC. DOC. (ES) -A-	10	10	\N	2024-07-04 14:49:35	\N
381	E3505	TEC. DOC. (ES) -A-	11	11	\N	2024-07-04 14:49:36	\N
382	E3505	TEC. DOC. (ES) -A-	12	12	\N	2024-07-04 14:49:37	\N
383	E3505	TEC. DOC. (ES) -A-	13	13	\N	2024-07-04 14:49:38	\N
384	E3505	TEC. DOC. (ES) -A-	14	14	\N	2024-07-04 14:49:39	\N
385	E3505	TEC. DOC. (ES) -A-	15	15	\N	2024-07-04 14:49:40	\N
386	E3505	TEC. DOC. (ES) -A-	16	16	\N	2024-07-04 14:49:41	\N
387	E3505	TEC. DOC. (ES) -A-	17	17	\N	2024-07-04 14:49:42	\N
388	E3505	TEC. DOC. (ES) -A-	18	18	\N	2024-07-04 14:49:43	\N
389	E3505	TEC. DOC. (ES) -A-	19	19	\N	2024-07-04 14:49:44	\N
390	E3507	TEC DOC. (ES) -B-	1	1	\N	2024-07-04 14:49:45	\N
391	E3507	TEC DOC. (ES) -B-	2	2	\N	2024-07-04 14:49:46	\N
392	E3507	TEC DOC. (ES) -B-	3	3	\N	2024-07-04 14:49:47	\N
393	E3507	TEC DOC. (ES) -B-	4	4	\N	2024-07-04 14:49:48	\N
394	E3507	TEC DOC. (ES) -B-	5	5	\N	2024-07-04 14:49:49	\N
395	E3507	TEC DOC. (ES) -B-	6	6	\N	2024-07-04 14:49:50	\N
396	E3507	TEC DOC. (ES) -B-	7	7	\N	2024-07-04 14:49:51	\N
397	E3507	TEC DOC. (ES) -B-	8	8	\N	2024-07-04 14:49:52	\N
398	E3507	TEC DOC. (ES) -B-	9	9	\N	2024-07-04 14:49:53	\N
399	E3507	TEC DOC. (ES) -B-	10	10	\N	2024-07-04 14:49:54	\N
400	E3507	TEC DOC. (ES) -B-	11	11	\N	2024-07-04 14:49:55	\N
401	E3507	TEC DOC. (ES) -B-	12	12	\N	2024-07-04 14:49:56	\N
402	E3507	TEC DOC. (ES) -B-	13	13	\N	2024-07-04 14:49:57	\N
403	E3507	TEC DOC. (ES) -B-	14	14	\N	2024-07-04 14:49:58	\N
404	E3507	TEC DOC. (ES) -B-	15	15	\N	2024-07-04 14:49:59	\N
405	E3507	TEC DOC. (ES) -B-	16	16	\N	2024-07-04 14:50:00	\N
406	E3507	TEC DOC. (ES) -B-	17	17	\N	2024-07-04 14:50:01	\N
407	E3507	TEC DOC. (ES) -B-	18	18	\N	2024-07-04 14:50:02	\N
408	E3507	TEC DOC. (ES) -B-	19	19	\N	2024-07-04 14:50:03	\N
409	E3509	TEC DOC. (ES) -C-	1	1	\N	2024-07-04 14:50:04	\N
410	E3509	TEC DOC. (ES) -C-	2	2	\N	2024-07-04 14:50:05	\N
411	E3509	TEC DOC. (ES) -C-	3	3	\N	2024-07-04 14:50:06	\N
412	E3509	TEC DOC. (ES) -C-	4	4	\N	2024-07-04 14:50:07	\N
413	E3509	TEC DOC. (ES) -C-	5	5	\N	2024-07-04 14:50:08	\N
414	E3509	TEC DOC. (ES) -C-	6	6	\N	2024-07-04 14:50:09	\N
415	E3509	TEC DOC. (ES) -C-	7	7	\N	2024-07-04 14:50:10	\N
416	E3509	TEC DOC. (ES) -C-	8	8	\N	2024-07-04 14:50:11	\N
417	E3509	TEC DOC. (ES) -C-	9	9	\N	2024-07-04 14:50:12	\N
418	E3509	TEC DOC. (ES) -C-	10	10	\N	2024-07-04 14:50:13	\N
419	E3509	TEC DOC. (ES) -C-	11	11	\N	2024-07-04 14:50:14	\N
420	E3509	TEC DOC. (ES) -C-	12	12	\N	2024-07-04 14:50:15	\N
421	E3509	TEC DOC. (ES) -C-	13	13	\N	2024-07-04 14:50:16	\N
422	E3509	TEC DOC. (ES) -C-	14	14	\N	2024-07-04 14:50:17	\N
423	E3509	TEC DOC. (ES) -C-	15	15	\N	2024-07-04 14:50:18	\N
424	E3509	TEC DOC. (ES) -C-	16	16	\N	2024-07-04 14:50:19	\N
425	E3509	TEC DOC. (ES) -C-	17	17	\N	2024-07-04 14:50:20	\N
426	E3509	TEC DOC. (ES) -C-	18	18	\N	2024-07-04 14:50:21	\N
427	E3509	TEC DOC. (ES) -C-	19	19	\N	2024-07-04 14:50:22	\N
428	E3511	TEC. DOC. (EMS) -A-	1	1	\N	2024-07-04 14:50:23	\N
429	E3511	TEC. DOC. (EMS) -A-	2	2	\N	2024-07-04 14:50:24	\N
430	E3511	TEC. DOC. (EMS) -A-	3	3	\N	2024-07-04 14:50:25	\N
431	E3511	TEC. DOC. (EMS) -A-	4	4	\N	2024-07-04 14:50:26	\N
432	E3511	TEC. DOC. (EMS) -A-	5	5	\N	2024-07-04 14:50:27	\N
433	E3511	TEC. DOC. (EMS) -A-	6	6	\N	2024-07-04 14:50:28	\N
434	E3511	TEC. DOC. (EMS) -A-	7	7	\N	2024-07-04 14:50:29	\N
435	E3511	TEC. DOC. (EMS) -A-	8	8	\N	2024-07-04 14:50:30	\N
436	E3511	TEC. DOC. (EMS) -A-	9	9	\N	2024-07-04 14:50:31	\N
437	E3511	TEC. DOC. (EMS) -A-	10	10	\N	2024-07-04 14:50:32	\N
438	E3511	TEC. DOC. (EMS) -A-	11	11	\N	2024-07-04 14:50:33	\N
439	E3511	TEC. DOC. (EMS) -A-	12	12	\N	2024-07-04 14:50:34	\N
440	E3511	TEC. DOC. (EMS) -A-	13	13	\N	2024-07-04 14:50:35	\N
441	E3511	TEC. DOC. (EMS) -A-	14	14	\N	2024-07-04 14:50:36	\N
442	E3511	TEC. DOC. (EMS) -A-	15	15	\N	2024-07-04 14:50:37	\N
443	E3511	TEC. DOC. (EMS) -A-	16	16	\N	2024-07-04 14:50:38	\N
444	E3511	TEC. DOC. (EMS) -A-	17	17	\N	2024-07-04 14:50:39	\N
445	E3511	TEC. DOC. (EMS) -A-	18	18	\N	2024-07-04 14:50:40	\N
446	E3511	TEC. DOC. (EMS) -A-	19	19	\N	2024-07-04 14:50:41	\N
447	E3513	TEC. DOC. (EMS) -B-	1	1	\N	2024-07-04 14:50:42	\N
448	E3513	TEC. DOC. (EMS) -B-	2	2	\N	2024-07-04 14:50:43	\N
449	E3513	TEC. DOC. (EMS) -B-	3	3	\N	2024-07-04 14:50:44	\N
450	E3513	TEC. DOC. (EMS) -B-	4	4	\N	2024-07-04 14:50:45	\N
451	E3513	TEC. DOC. (EMS) -B-	5	5	\N	2024-07-04 14:50:46	\N
452	E3513	TEC. DOC. (EMS) -B-	6	6	\N	2024-07-04 14:50:47	\N
453	E3513	TEC. DOC. (EMS) -B-	7	7	\N	2024-07-04 14:50:48	\N
454	E3513	TEC. DOC. (EMS) -B-	8	8	\N	2024-07-04 14:50:49	\N
455	E3513	TEC. DOC. (EMS) -B-	9	9	\N	2024-07-04 14:50:50	\N
456	E3513	TEC. DOC. (EMS) -B-	10	10	\N	2024-07-04 14:50:51	\N
457	E3513	TEC. DOC. (EMS) -B-	11	11	\N	2024-07-04 14:50:52	\N
458	E3513	TEC. DOC. (EMS) -B-	12	12	\N	2024-07-04 14:50:53	\N
459	E3513	TEC. DOC. (EMS) -B-	13	13	\N	2024-07-04 14:50:54	\N
460	E3513	TEC. DOC. (EMS) -B-	14	14	\N	2024-07-04 14:50:55	\N
461	E3513	TEC. DOC. (EMS) -B-	15	15	\N	2024-07-04 14:50:56	\N
462	E3513	TEC. DOC. (EMS) -B-	16	16	\N	2024-07-04 14:50:57	\N
463	E3513	TEC. DOC. (EMS) -B-	17	17	\N	2024-07-04 14:50:58	\N
464	E3513	TEC. DOC. (EMS) -B-	18	18	\N	2024-07-04 14:50:59	\N
465	E3513	TEC. DOC. (EMS) -B-	19	19	\N	2024-07-04 14:51:00	\N
466	E3515	PROF. ASIG. (EMS) -A-	15	\N	\N	2024-07-04 14:51:01	\N
467	E3517	PROF. ASIG. (EMS) -B-	17	\N	\N	2024-07-04 14:51:02	\N
468	E3519	PROF. ASIG. (ES) -A-	1	1	\N	2024-07-04 14:51:03	\N
469	E3519	PROF. ASIG. (ES) -A-	2	2	\N	2024-07-04 14:51:04	\N
470	E3519	PROF. ASIG. (ES) -A-	3	3	\N	2024-07-04 14:51:05	\N
471	E3519	PROF. ASIG. (ES) -A-	4	4	\N	2024-07-04 14:51:06	\N
472	E3519	PROF. ASIG. (ES) -A-	5	5	\N	2024-07-04 14:51:07	\N
473	E3519	PROF. ASIG. (ES) -A-	6	6	\N	2024-07-04 14:51:08	\N
474	E3519	PROF. ASIG. (ES) -A-	7	7	\N	2024-07-04 14:51:09	\N
475	E3519	PROF. ASIG. (ES) -A-	8	8	\N	2024-07-04 14:51:10	\N
476	E3519	PROF. ASIG. (ES) -A-	9	9	\N	2024-07-04 14:51:11	\N
477	E3519	PROF. ASIG. (ES) -A-	10	10	\N	2024-07-04 14:51:12	\N
478	E3519	PROF. ASIG. (ES) -A-	11	11	\N	2024-07-04 14:51:13	\N
479	E3519	PROF. ASIG. (ES) -A-	12	12	\N	2024-07-04 14:51:14	\N
480	E3519	PROF. ASIG. (ES) -A-	13	13	\N	2024-07-04 14:51:15	\N
481	E3519	PROF. ASIG. (ES) -A-	14	14	\N	2024-07-04 14:51:16	\N
482	E3519	PROF. ASIG. (ES) -A-	15	15	\N	2024-07-04 14:51:17	\N
483	E3519	PROF. ASIG. (ES) -A-	16	16	\N	2024-07-04 14:51:18	\N
484	E3519	PROF. ASIG. (ES) -A-	17	17	\N	2024-07-04 14:51:19	\N
485	E3519	PROF. ASIG. (ES) -A-	18	18	\N	2024-07-04 14:51:20	\N
486	E3519	PROF. ASIG. (ES) -A-	19	19	\N	2024-07-04 14:51:21	\N
487	E3521	PROF. ASIG. (ES) -B-	1	1	\N	2024-07-04 14:51:22	\N
488	E3521	PROF. ASIG. (ES) -B-	2	2	\N	2024-07-04 14:51:23	\N
489	E3521	PROF. ASIG. (ES) -B-	3	3	\N	2024-07-04 14:51:24	\N
490	E3521	PROF. ASIG. (ES) -B-	4	4	\N	2024-07-04 14:51:25	\N
491	E3521	PROF. ASIG. (ES) -B-	5	5	\N	2024-07-04 14:51:26	\N
492	E3521	PROF. ASIG. (ES) -B-	6	6	\N	2024-07-04 14:51:27	\N
493	E3521	PROF. ASIG. (ES) -B-	7	7	\N	2024-07-04 14:51:28	\N
494	E3521	PROF. ASIG. (ES) -B-	8	8	\N	2024-07-04 14:51:29	\N
495	E3521	PROF. ASIG. (ES) -B-	9	9	\N	2024-07-04 14:51:30	\N
496	E3521	PROF. ASIG. (ES) -B-	10	10	\N	2024-07-04 14:51:31	\N
497	E3521	PROF. ASIG. (ES) -B-	11	11	\N	2024-07-04 14:51:32	\N
498	E3521	PROF. ASIG. (ES) -B-	12	12	\N	2024-07-04 14:51:33	\N
499	E3521	PROF. ASIG. (ES) -B-	13	13	\N	2024-07-04 14:51:34	\N
500	E3521	PROF. ASIG. (ES) -B-	14	14	\N	2024-07-04 14:51:35	\N
501	E3521	PROF. ASIG. (ES) -B-	15	15	\N	2024-07-04 14:51:36	\N
502	E3521	PROF. ASIG. (ES) -B-	16	16	\N	2024-07-04 14:51:37	\N
503	E3521	PROF. ASIG. (ES) -B-	17	17	\N	2024-07-04 14:51:38	\N
504	E3521	PROF. ASIG. (ES) -B-	18	18	\N	2024-07-04 14:51:39	\N
505	E3521	PROF. ASIG. (ES) -B-	19	19	\N	2024-07-04 14:51:40	\N
506	E3523	PROF. ASIG. (EMS) -C-	23	\N	\N	2024-07-04 14:51:41	\N
507	E3525	PROF. ASIG.(ES) -C-	1	1	\N	2024-07-04 14:51:42	\N
508	E3525	PROF. ASIG.(ES) -C-	2	2	\N	2024-07-04 14:51:43	\N
509	E3525	PROF. ASIG.(ES) -C-	3	3	\N	2024-07-04 14:51:44	\N
510	E3525	PROF. ASIG.(ES) -C-	4	4	\N	2024-07-04 14:51:45	\N
511	E3525	PROF. ASIG.(ES) -C-	5	5	\N	2024-07-04 14:51:46	\N
512	E3525	PROF. ASIG.(ES) -C-	6	6	\N	2024-07-04 14:51:47	\N
513	E3525	PROF. ASIG.(ES) -C-	7	7	\N	2024-07-04 14:51:48	\N
514	E3525	PROF. ASIG.(ES) -C-	8	8	\N	2024-07-04 14:51:49	\N
515	E3525	PROF. ASIG.(ES) -C-	9	9	\N	2024-07-04 14:51:50	\N
516	E3525	PROF. ASIG.(ES) -C-	10	10	\N	2024-07-04 14:51:51	\N
517	E3525	PROF. ASIG.(ES) -C-	11	11	\N	2024-07-04 14:51:52	\N
518	E3525	PROF. ASIG.(ES) -C-	12	12	\N	2024-07-04 14:51:53	\N
519	E3525	PROF. ASIG.(ES) -C-	13	13	\N	2024-07-04 14:51:54	\N
520	E3525	PROF. ASIG.(ES) -C-	14	14	\N	2024-07-04 14:51:55	\N
521	E3525	PROF. ASIG.(ES) -C-	15	15	\N	2024-07-04 14:51:56	\N
522	E3525	PROF. ASIG.(ES) -C-	16	16	\N	2024-07-04 14:51:57	\N
523	E3525	PROF. ASIG.(ES) -C-	17	17	\N	2024-07-04 14:51:58	\N
524	E3525	PROF. ASIG.(ES) -C-	18	18	\N	2024-07-04 14:51:59	\N
525	E3525	PROF. ASIG.(ES) -C-	19	19	\N	2024-07-04 14:52:00	\N
526	E3601	PROF. AS. (ES) -A-	20	12	\N	2024-07-04 14:52:01	\N
527	E3603	PROF. AS. (ES) -B-	20	12	\N	2024-07-04 14:52:02	\N
528	E3605	PROF. AS (ES) -C-	20	12	\N	2024-07-04 14:52:03	\N
529	E3607	PROF. ASO (ES) -A-	20	12	\N	2024-07-04 14:52:04	\N
530	E3609	PROF. ASO (ES) -B-	20	12	\N	2024-07-04 14:52:05	\N
531	E3611	PROF. ASO (ES) -C-	20	12	\N	2024-07-04 14:52:06	\N
532	E3613	PROF. TIT. (ES) -A-	20	12	\N	2024-07-04 14:52:07	\N
533	E3615	PROF. TIT. (ES) -B-	20	12	\N	2024-07-04 14:52:08	\N
534	E3617	PROF. TIT. (ES) -C-	20	12	\N	2024-07-04 14:52:09	\N
535	E3619	PROF. AS. (EMS) -A-	20	\N	\N	2024-07-04 14:52:10	\N
536	E3621	PROF. AS. (EMS) -B-	20	\N	\N	2024-07-04 14:52:11	\N
537	E3623	PROF. ASO (EMS) -A-	20	\N	\N	2024-07-04 14:52:12	\N
538	E3625	PROF. ASO. (EMS) -B-	20	\N	\N	2024-07-04 14:52:13	\N
539	E3627	PROF. TIT. (EMS) -A-	20	\N	\N	2024-07-04 14:52:14	\N
540	E3629	PROF. TIT. (EMS) -B-	20	\N	\N	2024-07-04 14:52:15	\N
541	E3631	TEC. DOC. (ES) -A-	20	18	\N	2024-07-04 14:52:16	\N
542	E3633	TEC. DOC. (ES) -B-	20	18	\N	2024-07-04 14:52:17	\N
543	E3635	TEC. DOC. (ES) -C-	20	18	\N	2024-07-04 14:52:18	\N
544	E3637	TEC. DOC. AS. -A-	20	18	\N	2024-07-04 14:52:19	\N
545	E3639	TEC. DOC. AS. -B-	20	18	\N	2024-07-04 14:52:20	\N
546	E3641	TEC. DOC. AS. -C-	20	18	\N	2024-07-04 14:52:21	\N
547	E3643	T. TIT. (ES) -A-	20	18	\N	2024-07-04 14:52:22	\N
548	E3645	T. TIT. (ES) -B-	20	18	\N	2024-07-04 14:52:23	\N
549	E3647	TEC. DOC. AUX. -A-	20	\N	\N	2024-07-04 14:52:24	\N
550	E3649	TEC. DOC. AUX. -B-	20	\N	\N	2024-07-04 14:52:25	\N
551	E3651	TEC. DOC. AUX. -C-	20	\N	\N	2024-07-04 14:52:26	\N
552	E3653	TEC. DOC. ASO. -A-	20	\N	\N	2024-07-04 14:52:27	\N
553	E3655	TEC. DOC. ASO. -B-	20	\N	\N	2024-07-04 14:52:28	\N
554	E3657	TEC. DOC. ASO. -C-	20	\N	\N	2024-07-04 14:52:29	\N
555	E3659	PROF. TIT. -A-	20	6	\N	2024-07-04 14:52:30	\N
556	E3661	PROF. TIT. -B-	20	6	\N	2024-07-04 14:52:31	\N
557	E3663	PROF. TIT. -C-	20	6	\N	2024-07-04 14:52:32	\N
558	E3667	PROF. ASOCIADO -C- (EMS)	20	\N	\N	2024-07-04 14:52:33	\N
559	E3669	PROF. TITULAR -C- (EMS)	20	\N	\N	2024-07-04 14:52:34	\N
560	E3675	TECNICO TITULAR -C- (ES)	20	\N	\N	2024-07-04 14:52:35	\N
561	E3701	PROF. ASI. -A-	30	\N	\N	2024-07-04 14:52:36	\N
562	E3703	PROF. ASI. -B-	30	\N	\N	2024-07-04 14:52:37	\N
563	E3705	PROF. ASI. -C-	30	\N	\N	2024-07-04 14:52:38	\N
564	E3707	PROF. ASO. -A-	30	18	\N	2024-07-04 14:52:39	\N
565	E3709	PROF. ASO. -B-	30	18	\N	2024-07-04 14:52:40	\N
566	E3711	PROF. ASO. -C-	30	18	\N	2024-07-04 14:52:41	\N
567	E3713	PROF. TIT. -A-	30	18	\N	2024-07-04 14:52:42	\N
568	E3715	PROF. TIT. -B-	30	18	\N	2024-07-04 14:52:43	\N
569	E3717	PROF. TIT. -C-	30	18	\N	2024-07-04 14:52:44	\N
570	E3719	PROF. ASI. (EMS) -A-	30	14	\N	2024-07-04 14:52:45	\N
571	E3721	PROF. ASI. (EMS) -B-	30	\N	\N	2024-07-04 14:52:46	\N
572	E3723	PROF. ASO. (EMS) -A-	30	\N	\N	2024-07-04 14:52:47	\N
573	E3725	PROF. ASO. (EMS) -B-	30	\N	\N	2024-07-04 14:52:48	\N
574	E3727	PROF. TIT. (EMS) -A-	30	\N	\N	2024-07-04 14:52:49	\N
575	E3729	PROF. TIT. (EMS) -B-	30	\N	\N	2024-07-04 14:52:50	\N
576	E3731	TEC. DOC. AUX. -A-	30	28	\N	2024-07-04 14:52:51	\N
577	E3733	TEC. DOC. AUX. -B-	30	28	\N	2024-07-04 14:52:52	\N
578	E3735	TEC. DOC. AUX. -C-	30	28	\N	2024-07-04 14:52:53	\N
579	E3737	TEC. DOC. ASOC. -A-	30	26	\N	2024-07-04 14:52:54	\N
580	E3739	TEC. DOC. ASOC. -B-	30	28	\N	2024-07-04 14:52:55	\N
581	E3741	TEC. DOC. ASOC. -C-	30	28	\N	2024-07-04 14:52:56	\N
582	E3743	TEC. TIT. (ES) -A-	30	28	\N	2024-07-04 14:52:57	\N
583	E3745	TEC. TIT. (ES) -B-	30	28	\N	2024-07-04 14:52:58	\N
584	E3747	TEC. DOC. AUX. (EMS) -A-	30	\N	\N	2024-07-04 14:52:59	\N
585	E3749	TEC. DOC. AUX. (EMS) -B-	30	\N	\N	2024-07-04 14:53:00	\N
586	E3751	TEC. DOC. AUX. (EMS) -C-	30	\N	\N	2024-07-04 14:53:01	\N
587	E3753	TEC. DOC. ASO. (EMS) -A-	30	\N	\N	2024-07-04 14:53:02	\N
588	E3755	TEC. DOC. ASO. (EMS) -B-	30	\N	\N	2024-07-04 14:53:03	\N
589	E3757	TEC. DOC. ASO. (EMS) -C-	30	\N	\N	2024-07-04 14:53:04	\N
590	E3759	PROF. INV. (ES) -A-	30	10	\N	2024-07-04 14:53:05	\N
591	E3761	PROF. INV. (ES) -B-	30	10	\N	2024-07-04 14:53:06	\N
592	E3763	PROF. INV. (ES) -C-	30	10	\N	2024-07-04 14:53:07	\N
593	E3775	TECNICO TITULAR -C- (ES)	30	\N	\N	2024-07-04 14:53:08	\N
594	E3807	PROF. AS. (ES) -A-	40	22	\N	2024-07-04 14:53:09	\N
595	E3809	PROF. AS. (ES) -B-	40	22	\N	2024-07-04 14:53:10	\N
596	E3811	PROF. AS. (ES) -C-	40	22	\N	2024-07-04 14:53:11	\N
597	E3813	PROF. TIT. (ES) -A-	40	20	\N	2024-07-04 14:53:12	\N
598	E3815	PROF. TIT. (ES) -B-	40	20	\N	2024-07-04 14:53:13	\N
599	E3817	PROF. TIT. (ES) -C-	40	20	\N	2024-07-04 14:53:14	\N
600	E3819	PENDIENTE	40	14	\N	2024-07-04 14:53:15	\N
601	E3837	TEC. DOC. ASOC. -A- (ES) TIEMPO COMPLETO	40	34	\N	2024-07-04 14:53:16	\N
602	E3839	TEC. DOC. ASOC. -B- (ES) TIEMPO COMPLETO	40	34	\N	2024-07-04 14:53:17	\N
603	E3861	PROF. INV. TIT -A-(ES) TIEMPO COMPLETO	40	20	\N	2024-07-04 14:53:18	\N
604	E3863	PROF. INV. TIT. -C- (ES) TIEMPO COMPLETO	40	20	\N	2024-07-04 14:53:19	\N
605	E5019	PROF. ASIG. (ES) -A-	1	1	\N	2024-07-04 14:53:20	\N
606	E5019	PROF. ASIG. (ES) -A-	2	2	\N	2024-07-04 14:53:21	\N
607	E5019	PROF. ASIG. (ES) -A-	3	3	\N	2024-07-04 14:53:22	\N
608	E5019	PROF. ASIG. (ES) -A-	4	4	\N	2024-07-04 14:53:23	\N
609	E5019	PROF. ASIG. (ES) -A-	5	5	\N	2024-07-04 14:53:24	\N
610	E5019	PROF. ASIG. (ES) -A-	6	6	\N	2024-07-04 14:53:25	\N
611	E5019	PROF. ASIG. (ES) -A-	7	7	\N	2024-07-04 14:53:26	\N
612	E5019	PROF. ASIG. (ES) -A-	8	8	\N	2024-07-04 14:53:27	\N
613	E5019	PROF. ASIG. (ES) -A-	9	9	\N	2024-07-04 14:53:28	\N
614	E5019	PROF. ASIG. (ES) -A-	10	10	\N	2024-07-04 14:53:29	\N
615	E5019	PROF. ASIG. (ES) -A-	11	11	\N	2024-07-04 14:53:30	\N
616	E5019	PROF. ASIG. (ES) -A-	12	12	\N	2024-07-04 14:53:31	\N
617	E5019	PROF. ASIG. (ES) -A-	13	13	\N	2024-07-04 14:53:32	\N
618	E5019	PROF. ASIG. (ES) -A-	14	14	\N	2024-07-04 14:53:33	\N
619	E5019	PROF. ASIG. (ES) -A-	16	16	\N	2024-07-04 14:53:34	\N
620	E5019	PROF. ASIG. (ES) -A-	17	17	\N	2024-07-04 14:53:35	\N
621	E5019	PROF. ASIG. (ES) -A-	18	18	\N	2024-07-04 14:53:36	\N
622	E5019	PROF. ASIG. (ES) -A-	19	19	\N	2024-07-04 14:53:37	\N
623	E5021	PROF. ASIG. (ES) -B-	1	1	\N	2024-07-04 14:53:38	\N
624	E5021	PROF. ASIG. (ES) -B-	2	2	\N	2024-07-04 14:53:39	\N
625	E5021	PROF. ASIG. (ES) -B-	3	3	\N	2024-07-04 14:53:40	\N
626	E5021	PROF. ASIG. (ES) -B-	4	4	\N	2024-07-04 14:53:41	\N
627	E5021	PROF. ASIG. (ES) -B-	5	5	\N	2024-07-04 14:53:42	\N
628	E5021	PROF. ASIG. (ES) -B-	6	6	\N	2024-07-04 14:53:43	\N
629	E5021	PROF. ASIG. (ES) -B-	7	7	\N	2024-07-04 14:53:44	\N
630	E5021	PROF. ASIG. (ES) -B-	8	8	\N	2024-07-04 14:53:45	\N
631	E5021	PROF. ASIG. (ES) -B-	9	9	\N	2024-07-04 14:53:46	\N
632	E5021	PROF. ASIG. (ES) -B-	10	10	\N	2024-07-04 14:53:47	\N
633	E5021	PROF. ASIG. (ES) -B-	11	11	\N	2024-07-04 14:53:48	\N
634	E5021	PROF. ASIG. (ES) -B-	12	12	\N	2024-07-04 14:53:49	\N
635	E5021	PROF. ASIG. (ES) -B-	13	13	\N	2024-07-04 14:53:50	\N
636	E5021	PROF. ASIG. (ES) -B-	14	14	\N	2024-07-04 14:53:51	\N
637	E5021	PROF. ASIG. (ES) -B-	15	15	\N	2024-07-04 14:53:52	\N
638	E5021	PROF. ASIG. (ES) -B-	16	16	\N	2024-07-04 14:53:53	\N
639	E5021	PROF. ASIG. (ES) -B-	17	17	\N	2024-07-04 14:53:54	\N
640	E5021	PROF. ASIG. (ES) -B-	18	18	\N	2024-07-04 14:53:55	\N
641	E5021	PROF. ASIG. (ES) -B-	19	19	\N	2024-07-04 14:53:56	\N
642	E5025	PROF. ASIG. (ES) -C-	1	1	\N	2024-07-04 14:53:57	\N
643	E5025	PROF. ASIG. (ES) -C-	2	2	\N	2024-07-04 14:53:58	\N
644	E5025	PROF. ASIG. (ES) -C-	3	3	\N	2024-07-04 14:53:59	\N
645	E5025	PROF. ASIG. (ES) -C-	4	4	\N	2024-07-04 14:54:00	\N
646	E5025	PROF. ASIG. (ES) -C-	5	5	\N	2024-07-04 14:54:01	\N
647	E5025	PROF. ASIG. (ES) -C-	6	6	\N	2024-07-04 14:54:02	\N
648	E5025	PROF. ASIG. (ES) -C-	7	7	\N	2024-07-04 14:54:03	\N
649	E5025	PROF. ASIG. (ES) -C-	8	8	\N	2024-07-04 14:54:04	\N
650	E5025	PROF. ASIG. (ES) -C-	9	9	\N	2024-07-04 14:54:05	\N
651	E5025	PROF. ASIG. (ES) -C-	10	10	\N	2024-07-04 14:54:06	\N
652	E5025	PROF. ASIG. (ES) -C-	11	11	\N	2024-07-04 14:54:07	\N
653	E5025	PROF. ASIG. (ES) -C-	12	12	\N	2024-07-04 14:54:08	\N
654	E5025	PROF. ASIG. (ES) -C-	13	13	\N	2024-07-04 14:54:09	\N
655	E5025	PROF. ASIG. (ES) -C-	14	14	\N	2024-07-04 14:54:10	\N
656	E5025	PROF. ASIG. (ES) -C-	15	15	\N	2024-07-04 14:54:11	\N
657	E5025	PROF. ASIG. (ES) -C-	16	16	\N	2024-07-04 14:54:12	\N
658	E5025	PROF. ASIG. (ES) -C-	17	17	\N	2024-07-04 14:54:13	\N
659	E5025	PROF. ASIG. (ES) -C-	18	18	\N	2024-07-04 14:54:14	\N
660	E5025	PROF. ASIG. (ES) -C-	19	19	\N	2024-07-04 14:54:15	\N
661	E5317	PROF. TIT. (ES) -C-	40	20	\N	2024-07-04 14:54:16	\N
662	IA01001	JEFE DE OFICINA	36	\N	\N	2024-07-04 14:54:17	\N
663	IA01004	JEFE DE MESA	36	\N	6	2024-07-04 14:54:18	\N
664	IA01009	JEFE DE PROYECTO	36	\N	12	2024-07-04 14:54:19	\N
665	IA01026	AUXILIAR ADMINISTRATIVO	36	\N	3	2024-07-04 14:54:20	\N
666	IA04003	ANALISTAS DE SISTEMAS ADMINISTRATIVOS	36	\N	9	2024-07-04 14:54:21	\N
667	IA08003	SECRETARIA BILINGUE	36	\N	9	2024-07-04 14:54:22	\N
668	IA08004	TAQUIMECANOGRAFA	36	\N	\N	2024-07-04 14:54:23	\N
669	IA08005	MECANOGRAFA	36	\N	\N	2024-07-04 14:54:24	\N
670	IA08016	SECRETARIA DE DIRECTOR DE PLANTEL (ES)	36	\N	8	2024-07-04 14:54:25	\N
671	IA08029	SECRETARIA DE JEFE DE DEPARTAMENTO	36	\N	5	2024-07-04 14:54:26	\N
672	IP01002	ANALISTA ESPECIALIZADO	36	\N	9	2024-07-04 14:54:27	\N
673	IP07539	ANALISTA TECNICO ESPECIALIZADO	36	\N	15	2024-07-04 14:54:28	\N
674	IS06006	AUXILIAR DE INTENDENCIA	36	\N	1	2024-07-04 14:54:29	\N
675	IS07002	OFICIAL DE SERVICIOS ESPECIALIZADOS	36	\N	7	2024-07-04 14:54:30	\N
676	IS08012	OFICIAL DE SERVICIOS	36	\N	3	2024-07-04 14:54:31	\N
677	IT03002	ANALISTA TECNICO	36	\N	10	2024-07-04 14:54:32	\N
678	IT03004	AUXILIAR DE ANALISTA TECNICO	36	\N	7	2024-07-04 14:54:33	\N
679	IT05003	BIBLIOTECARIO	36	\N	6	2024-07-04 14:54:34	\N
680	IT05010	AUXILIAR DE BIBLIOTECA	36	\N	\N	2024-07-04 14:54:35	\N
681	IT06011	ANALISTA PROGRAMADOR	36	\N	11	2024-07-04 14:54:36	\N
682	IT06018	TECNICO PROGRAMADOR	36	\N	\N	2024-07-04 14:54:37	\N
683	IT06026	AUXILIAR DE PROGRAMADOR	36	\N	5	2024-07-04 14:54:38	\N
684	IT07503	TECNICO BIBLIOTECARIO	36	\N	8	2024-07-04 14:54:39	\N
685	P0100	PENDIENTE	40	20	\N	2024-07-04 14:54:40	\N
686	T075030	TECNICO BIBLIOTECARIO	36	\N	\N	2024-07-04 14:54:41	\N
687	YA0100 	SECRETARIA	36	\N	\N	2024-07-04 14:54:42	\N
688	YT02009	AUXILIAR DE CAMPO AGROPECUARIO FORESTAL E HIDRAULICO YT02009	36	\N	\N	2024-07-04 14:54:43	\N
\.


--
-- Data for Name: entidades_federativas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".entidades_federativas (entidad_federativa, nombre_entidad, clave_entidad) FROM stdin;
1	Aguascalientes	AS
2	Baja California	BC
3	Baja California Sur	BS
4	Campeche	CC
5	Coahuila	CS
6	Colima	CH
7	Chiapas	CL
8	Chihuahua	CM
9	Ciudad de México	DF
10	Durango	DG
11	Guanajuato	GT
12	Guerrero	GR
13	Hidalgo	HG
14	Jalisco	JC
15	Mexico Estado de	MC
16	Michoacan	MN
17	Morelos	MS
18	Nayarit	NT
19	Nuevo Leon	NL
20	Oaxaca	OC
21	Puebla	PL
22	Queretaro	QT
23	Quintana Roo	QR
24	San Luis Potosi	SP
25	Sinaloa	SL
26	Sonora	SR
27	Tabasco	TC
28	Tamaulipas	TS
29	Tlaxcala	TL
30	Veracruz	VZ
31	Yucatan	YN
32	Zacatecas	ZS
34	Extranjero	NE
\.


--
-- Data for Name: especialidades; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".especialidades (especialidad, carrera, reticula, nombre_especialidad, creditos_optativos, creditos_especialidad, activa, nombre_corto, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: estatus_alumno; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".estatus_alumno (estatus, descripcion) FROM stdin;
ACT	Activo                                                                                              
BT1	Baja temporal Voluntaria                                                                            
BT2	Baja temporal por adeudo de examenes especiales                                                     
BT3	Baja temporal por no inscripcion                                                                    
BD1	Baja definitiva voluntaria                                                                          
BD2	Baja definitiva por reprobacion en primer semestre                                                  
BD3	Baja definitiva por examen especial reprobado                                                       
BD4	Baja definitiva por alcanzar el numero maximo de semestres permitidos                               
BD5	Baja definitiva por no inscripcion a segundo semestre                                               
BD6	Baja definitiva por no cumplir con requisito de inscripcion                                         
EGR	Egresado                                                                                            
TIT	Titulado                                                                                            
BT4	Baja Temporal por Enfermedad                                                                        
BD7	Baja Definitiva por acumulación de cursos especiales                                                
BD8	Baja Definitiva traslado S.A.                                                                       
BD9	Baja Definitiva traslado otro Tec                                                                   
BDA	Baja Definitiva 3 periodos fuera                                                                    
BDB	Baja Definitiva Fallecimiento                                                                       
BDC	Baja Definitiva Indisciplina                                                                        
BDE	Baja Definitiva por emision de certificado parcial                                                  
BDF	Baja por anulacion de numero de control                                                             
BDR	Baja Definitiva por reprobacion de curso especial                                                   
TRS	Traslado                                                                                            
BDG	Baja Definitiva                                                                                     
\.


--
-- Data for Name: evaluacion_alumnos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".evaluacion_alumnos (periodo, no_de_control, materia, grupo, rfc, clave_area, encuesta, respuestas, resp_abierta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evaluacion_aspectos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".evaluacion_aspectos (aspecto, encuesta, descripcion, consecutivo) FROM stdin;
A	A	Planeación del curso	1
A	A	Dominio de la asignatura	2
A	D	Docencia	1
A	D	Formación	2
A	I	Planeacion del curso	1
B	A	Aprendizaje significativo	1
B	A	Planificación del curso	2
B	D	Investigación	1
B	D	Gestión	2
B	I	Aprendizaje significativo	1
C	A	Dominio de la materia	1
C	A	Ambientes de aprendizaje	2
C	D	Gestión	1
C	D	Vinculación	2
C	I	Dominio de la materia	1
D	A	Ética y desarrollo sustentable	1
D	A	Estrategias - métodos y técnicas	2
D	D	Tutoría	1
D	D	Investigación	2
D	I	Etica y desarrollo sustentable	1
E	A	Evaluación	1
E	A	Motivación	2
E	D	Vinculación	1
E	D	Tutoria	2
E	I	Evaluacion	1
F	A	Desempeño docente	1
F	A	Evaluación	2
F	D	Formación	1
F	I	Desempeño docente	1
G	A	Comunicación	2
G	D	Desempeño docente	1
H	A	Gestión del curso	2
H	D	Percepcion en Desempeño	1
I	A	Tecnologías de la información y comunicación	2
J	A	Satisfacción general	2
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".failed_jobs (id, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: fecha_evaluacion; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".fecha_evaluacion (id, periodo, encuesta, fecha_inicio, fecha_final, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fechas_carreras; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".fechas_carreras (carrera, fecha_inscripcion, fecha_inicio, fecha_fin, intervalo, personas, periodo, puntero, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fichas_configuracion; Type: TABLE DATA; Schema: ITE; Owner: postgres
--

COPY "ITE".fichas_configuracion (periodo, fecha_inicio_solicitudes, fecha_termino_solicitudes, fecha_examen_ceneval, direccion_url_ceneval, hora_examen_ceneval, hora_inicio_dia_atencion, hora_fin_dia_atencion, folios_por_dia_atencion, costo_examen, banco, cuenta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: folio_constancias; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".folio_constancias (id, folio, periodo, control, tipo, fecha, anio, quien, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: generar_listas_temporales; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".generar_listas_temporales (no_de_control, apellido_paterno, apellido_materno, nombre_alumno, semestre, fecha_hora_seleccion, promedio_ponderado, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".grupos (periodo, materia, grupo, estatus_grupo, capacidad_grupo, alumnos_inscritos, folio_acta, paralelo_de, exclusivo_carrera, exclusivo_reticula, rfc, tipo_personal, exclusivo, entrego, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: historia_alumno; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".historia_alumno (periodo, no_de_control, materia, grupo, calificacion, tipo_evaluacion, fecha_calificacion, plan_de_estudios, estatus_materia, nopresento, usuario, periodo_acredita_materia, created_at, updated_at, fecha_actualizacion) FROM stdin;
\.


--
-- Data for Name: horario_administrativo; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".horario_administrativo (periodo, rfc, consecutivo_admvo, descripcion_horario, fcaptura) FROM stdin;
\.


--
-- Data for Name: horario_observaciones; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".horario_observaciones (periodo, rfc, observaciones, depto, cuando) FROM stdin;
\.


--
-- Data for Name: horarios; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".horarios (periodo, rfc, tipo_horario, dia_semana, hora_inicial, hora_final, materia, grupo, aula, actividad, consecutivo, vigencia_inicio, vigencia_fin, consecutivo_admvo, tipo_personal, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: idiomas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas (id, idiomas, abrev) FROM stdin;
\.


--
-- Data for Name: idiomas_docentes; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas_docentes (id, rfc, appat, apmat, nombre, status) FROM stdin;
\.


--
-- Data for Name: idiomas_grupos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas_grupos (id, periodo, idioma, clave, nombre_completo, nombre_abrev, ya_eval) FROM stdin;
\.


--
-- Data for Name: idiomas_horario; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas_horario (periodo, idioma, lun_ini, lun_fin, mar_ini, mar_fin, mie_ini, mie_fin, jue_ini, jue_fin, vie_ini, vie_fin, sab_ini, sab_fin, clave, asesor, lugar, capacidad) FROM stdin;
\.


--
-- Data for Name: idiomas_inscripcion; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas_inscripcion (periodo, control, carrera, reticula, idioma, clave, calif, fecha_hora_selecc, quien) FROM stdin;
\.


--
-- Data for Name: idiomas_liberacion; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".idiomas_liberacion (periodo, control, calif, liberacion, idioma, opcion) FROM stdin;
\.


--
-- Data for Name: jefes; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".jefes (clave_area, descripcion_area, jefe_area, rfc, correo, ext, correo2) FROM stdin;
\.


--
-- Data for Name: materias; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".materias (materia, nivel_escolar, tipo_materia, clave_area, nombre_completo_materia, nombre_abreviado_materia, caracterizacion, generales, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: materias_carreras; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".materias_carreras (carrera, reticula, materia, creditos_materia, horas_teoricas, horas_practicas, orden_certificado, semestre_reticula, creditos_prerrequisito, especialidad, clave_oficial_materia, renglon, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".migrations (id, migration, batch) FROM stdin;
\.


--
-- Data for Name: motivos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".motivos (id, motivo, descripcion, created_at, updated_at) FROM stdin;
49	10	ALTA DEFINITIVA	2024-07-07 11:12:00	\N
50	20	ALTA INTERINA LIMITADA	2024-07-07 11:12:01	\N
51	24	ALTA EN GRAVIDEZ	2024-07-07 11:12:02	\N
52	25	ALTA EN PENSION	2024-07-07 11:12:03	\N
53	31	BAJA POR DEFUNCION	2024-07-07 11:12:04	\N
54	32	BAJA POR RENUNCIA	2024-07-07 11:12:05	\N
55	33	BAJA POR JUBILACION O PENSION	2024-07-07 11:12:06	\N
56	34	BAJA POR ABANDONO DE EMPLEO	2024-07-07 11:12:07	\N
57	35	BAJA POR TERMINO DE NOMBRAMIENTO	2024-07-07 11:12:08	\N
58	36	BAJA POR DICTAMEN ESCALAFONARIO	2024-07-07 11:12:09	\N
59	37	BAJA POR PASAR A OTRO EMPLEO	2024-07-07 11:12:10	\N
60	38	BAJA POR INSUBSISTENCIA DE NOMBRAMIENTO	2024-07-07 11:12:11	\N
61	39	BAJA POR REGULARIZACION DE PLANTILLA	2024-07-07 11:12:12	\N
62	4	P.N.C.	2024-07-07 11:12:13	\N
63	40	LIC.POR CRIANZA DE HIJOS MENORES DE 2 A.	2024-07-07 11:12:14	\N
64	41	LIC.POR ASUNTOS PART. SIN GOCE DE SUELDO	2024-07-07 11:12:15	\N
65	42	LIC. POR PASAR A OTRO EMPLEO	2024-07-07 11:12:16	\N
66	43	LIC.COMISION SINDICAL O ELECCION POPULAR	2024-07-07 11:12:17	\N
67	44	LICENCIA POR GRAVIDEZ	2024-07-07 11:12:18	\N
68	45	LIC.POR INCAPACIDAD MED.CON MEDIO SUELDO	2024-07-07 11:12:19	\N
69	46	LIC.INCAPACIDAD MED. SIN SUELDO	2024-07-07 11:12:20	\N
70	47	LIC. POR BECA EN EL EXTRANJERO	2024-07-07 11:12:21	\N
71	48	LICENCIA PREPENSIONARIA	2024-07-07 11:12:22	\N
72	50	PRORROGA DE LICENCIA X CRIANZA DE HIJOS	2024-07-07 11:12:23	\N
73	51	PRORROGA DE LIC.POR ASUNTOS PARTICULARES	2024-07-07 11:12:24	\N
74	52	PRORROGA DE LICENCIA POR OTRO EMPLEO	2024-07-07 11:12:25	\N
75	53	PRORROGA LIC.COMISION SIND.O ELECC.POPU.	2024-07-07 11:12:26	\N
76	55	PRORROGA LIC.INC.MEDICA C/SUELDO O ½ SUELDO	2024-07-07 11:12:27	\N
77	56	PRORROGA LIC.INCAPACIDAD MED.SIN SUELDO	2024-07-07 11:12:28	\N
78	57	PRORROGA LIC. POR BECA EN EL EXTRANJERO	2024-07-07 11:12:29	\N
79	6	PLAZA CANCELADA	2024-07-07 11:12:30	\N
80	60	REANUDACION LIC.CRIANZA HIJOS MENORES 2A	2024-07-07 11:12:31	\N
81	61	REANUDACION DE LIC.ASUNTOS PARTICULARES	2024-07-07 11:12:32	\N
82	62	REANUDACION DE LICENCIA POR OTRO EMPLEO	2024-07-07 11:12:33	\N
83	63	REANUDACION LIC.COM.SIND.O ELECC.POPULAR	2024-07-07 11:12:34	\N
84	64	REANUDACION LIC. POR GRAVIDEZ	2024-07-07 11:12:35	\N
85	65	REANUDACION LIC.INC.MED.CON MEDIO SUELDO	2024-07-07 11:12:36	\N
86	66	REANUDACION LIC.INC. MEDICA SIN SUELDO	2024-07-07 11:12:37	\N
87	67	REANUDACION LIC.POR BECA EN EXTRANJERO	2024-07-07 11:12:38	\N
88	68	REANUDACION LIC. PREPENSIONARIA	2024-07-07 11:12:39	\N
89	69	REANUDACION LIC.PLAZA CONG.POR TITULAR	2024-07-07 11:12:40	\N
90	73	BAJA POR SENTENCIA JUDICIAL	2024-07-07 11:12:41	\N
91	74	BAJA RESO.TRI.CONCILIACION Y ARBITRAJE	2024-07-07 11:12:42	\N
92	75	BAJA POR INCAPACIDAD I.S.S.S.T.E.	2024-07-07 11:12:43	\N
93	76	BAJA POR CAMBIO DE ADSCRIPCION	2024-07-07 11:12:44	\N
94	79	CAMBIO DE ADSCRIPCION	2024-07-07 11:12:45	\N
95	95	ALTA PROVISIONAL	2024-07-07 11:12:46	\N
96	96	ALTA DE CONFIANZA	2024-07-07 11:12:47	\N
\.


--
-- Data for Name: municipios; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".municipios (id, id_estado, id_municipio, municipio, created_at, updated_at) FROM stdin;
9857	1	1	AGUASCALIENTES	2022-11-11 12:31:55	\N
9858	1	2	ASIENTOS	2022-11-11 12:31:55	\N
9859	1	3	CALVILLO	2022-11-11 12:31:55	\N
9860	1	4	COSIO	2022-11-11 12:31:55	\N
9861	1	5	JESUS MARIA	2022-11-11 12:31:55	\N
9862	1	6	PABELLON DE ARTEAGA	2022-11-11 12:31:55	\N
9863	1	7	RINCON DE ROMOS	2022-11-11 12:31:55	\N
9864	1	8	SAN JOSE DE GRACIA	2022-11-11 12:31:55	\N
9865	1	9	TEPEZALA	2022-11-11 12:31:55	\N
9866	1	10	EL LLANO	2022-11-11 12:31:55	\N
9867	1	11	SAN FRANCISCO DE LOS ROMO	2022-11-11 12:31:55	\N
9868	1	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9869	2	1	ENSENADA	2022-11-11 12:31:55	\N
9870	2	2	MEXICALI	2022-11-11 12:31:55	\N
9871	2	3	TECATE	2022-11-11 12:31:55	\N
9872	2	4	TIJUANA	2022-11-11 12:31:55	\N
9873	2	5	PLAYAS DE ROSARITO	2022-11-11 12:31:55	\N
9874	2	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9875	3	1	COMONDU	2022-11-11 12:31:55	\N
9876	3	2	MULEGE	2022-11-11 12:31:55	\N
9877	3	3	LA PAZ	2022-11-11 12:31:55	\N
9878	3	5	PLAYAS DE ROSARITO	2022-11-11 12:31:55	\N
9879	3	8	LOS CABOS	2022-11-11 12:31:55	\N
9880	3	9	LORETO	2022-11-11 12:31:55	\N
9881	3	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9882	4	1	CALKINI	2022-11-11 12:31:55	\N
9883	4	2	CAMPECHE	2022-11-11 12:31:55	\N
9884	4	3	CARMEN	2022-11-11 12:31:55	\N
9885	4	4	CHAMPOTON	2022-11-11 12:31:55	\N
9886	4	5	HECELCHAKAN	2022-11-11 12:31:55	\N
9887	4	6	HOPELCHEN	2022-11-11 12:31:55	\N
9888	4	7	PALIZADA	2022-11-11 12:31:55	\N
9889	4	8	TENABO	2022-11-11 12:31:55	\N
9890	4	9	ESCARCEGA	2022-11-11 12:31:55	\N
9891	4	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9892	5	1	ABASOLO	2022-11-11 12:31:55	\N
9893	5	2	ACUÑA	2022-11-11 12:31:55	\N
9894	5	3	ALLENDE	2022-11-11 12:31:55	\N
9895	5	4	ARTEAGA	2022-11-11 12:31:55	\N
9896	5	5	CANDELA	2022-11-11 12:31:55	\N
9897	5	6	CASTAÑOS	2022-11-11 12:31:55	\N
9898	5	7	CUATROCIENEGAS	2022-11-11 12:31:55	\N
9899	5	8	ESCOBEDO	2022-11-11 12:31:55	\N
9900	5	9	FRANCISCO I. MADERO	2022-11-11 12:31:55	\N
9901	5	10	FRONTERA	2022-11-11 12:31:55	\N
9902	5	11	GENERAL CEPEDA	2022-11-11 12:31:55	\N
9903	5	12	GUERRERO	2022-11-11 12:31:55	\N
9904	5	13	HIDALGO	2022-11-11 12:31:55	\N
9905	5	14	JIMENEZ	2022-11-11 12:31:55	\N
9906	5	15	JUAREZ	2022-11-11 12:31:55	\N
9907	5	16	LAMADRID	2022-11-11 12:31:55	\N
9908	5	17	MATAMOROS	2022-11-11 12:31:55	\N
9909	5	18	MONCLOVA	2022-11-11 12:31:55	\N
9910	5	19	MORELOS	2022-11-11 12:31:55	\N
9911	5	20	MUZQUIZ	2022-11-11 12:31:55	\N
9912	5	21	NADADORES	2022-11-11 12:31:55	\N
9913	5	22	NAVA	2022-11-11 12:31:55	\N
9914	5	23	OCAMPO	2022-11-11 12:31:55	\N
9915	5	24	PARRAS	2022-11-11 12:31:55	\N
9916	5	25	PIEDRAS NEGRAS	2022-11-11 12:31:55	\N
9917	5	26	PROGRESO	2022-11-11 12:31:55	\N
9918	5	27	RAMOS ARIZPE	2022-11-11 12:31:55	\N
9919	5	28	SABINAS	2022-11-11 12:31:55	\N
9920	5	29	SACRAMENTO	2022-11-11 12:31:55	\N
9921	5	30	SALTILLO	2022-11-11 12:31:55	\N
9922	5	31	SAN BUENAVENTURA	2022-11-11 12:31:55	\N
9923	5	32	SAN JUAN DE SABINAS	2022-11-11 12:31:55	\N
9924	5	33	SAN PEDRO	2022-11-11 12:31:55	\N
9925	5	34	SIERRA MOJADA	2022-11-11 12:31:55	\N
9926	5	35	TORREON	2022-11-11 12:31:55	\N
9927	5	36	VIESCA	2022-11-11 12:31:55	\N
9928	5	37	VILLA UNION	2022-11-11 12:31:55	\N
9929	5	38	ZARAGOZA	2022-11-11 12:31:55	\N
9930	5	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9931	6	1	ARMERIA	2022-11-11 12:31:55	\N
9932	6	2	COLIMA	2022-11-11 12:31:55	\N
9933	6	3	COMALA	2022-11-11 12:31:55	\N
9934	6	4	COQUIMATLAN	2022-11-11 12:31:55	\N
9935	6	5	CUAUHTEMOC	2022-11-11 12:31:55	\N
9936	6	6	IXTLAHUACAN	2022-11-11 12:31:55	\N
9937	6	7	MANZANILLO	2022-11-11 12:31:55	\N
9938	6	8	MINATITLAN	2022-11-11 12:31:55	\N
9939	6	9	TECOMAN	2022-11-11 12:31:55	\N
9940	6	10	VILLA DE ALVAREZ	2022-11-11 12:31:55	\N
9941	6	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
9942	7	1	ACACOYAGUA	2022-11-11 12:31:55	\N
9943	7	2	ACALA	2022-11-11 12:31:55	\N
9944	7	3	ACAPETAHUA	2022-11-11 12:31:55	\N
9945	7	4	ALTAMIRANO	2022-11-11 12:31:55	\N
9946	7	5	AMATAN	2022-11-11 12:31:55	\N
9947	7	6	AMATENANGO DE LA FRONTERA	2022-11-11 12:31:55	\N
9948	7	7	AMATENANGO DEL VALLE	2022-11-11 12:31:55	\N
9949	7	8	ANGEL ALBINO CORZO	2022-11-11 12:31:55	\N
9950	7	9	ARRIAGA	2022-11-11 12:31:55	\N
9951	7	10	BEJUCAL DE OCAMPO	2022-11-11 12:31:55	\N
9952	7	11	BELLA VISTA	2022-11-11 12:31:55	\N
9953	7	12	BERRIOZABAL	2022-11-11 12:31:55	\N
9954	7	13	BOCHIL	2022-11-11 12:31:55	\N
9955	7	14	BOSQUE, EL	2022-11-11 12:31:55	\N
9956	7	15	CACAHOATAN	2022-11-11 12:31:55	\N
9957	7	16	CATAZAJA	2022-11-11 12:31:55	\N
9958	7	17	CINTALAPA	2022-11-11 12:31:55	\N
9959	7	18	COAPILLA	2022-11-11 12:31:55	\N
9960	7	19	COMITAN DE DOMINGUEZ	2022-11-11 12:31:55	\N
9961	7	20	LA CONCORDIA	2022-11-11 12:31:55	\N
9962	7	21	COPAINALA	2022-11-11 12:31:55	\N
9963	7	22	CHALCHIHUITAN	2022-11-11 12:31:55	\N
9964	7	23	CHAMULA	2022-11-11 12:31:55	\N
9965	7	24	CHANAL	2022-11-11 12:31:55	\N
9966	7	25	CHAPULTENANGO	2022-11-11 12:31:55	\N
9967	7	26	CHENALHO	2022-11-11 12:31:55	\N
9968	7	27	CHIAPA DE CORZO	2022-11-11 12:31:55	\N
9969	7	28	CHIAPILLA	2022-11-11 12:31:55	\N
9970	7	29	CHICOASEN	2022-11-11 12:31:55	\N
9971	7	30	CHICOMUSELO	2022-11-11 12:31:55	\N
9972	7	31	CHILON	2022-11-11 12:31:55	\N
9973	7	32	ESCUINTLA	2022-11-11 12:31:55	\N
9974	7	33	FRANCISCO LEON	2022-11-11 12:31:55	\N
9975	7	34	FRONTERA COMALAPA	2022-11-11 12:31:55	\N
9976	7	35	FRONTERA HIDALGO	2022-11-11 12:31:55	\N
9977	7	36	LA GRANDEZA	2022-11-11 12:31:55	\N
9978	7	37	HUEHUETAN	2022-11-11 12:31:55	\N
9979	7	38	HUIXTAN	2022-11-11 12:31:55	\N
9980	7	39	HUITIUPAN	2022-11-11 12:31:55	\N
9981	7	40	HUIXTLA	2022-11-11 12:31:55	\N
9982	7	41	LA INDEPENDENCIA	2022-11-11 12:31:55	\N
9983	7	42	IXHUATAN	2022-11-11 12:31:55	\N
9984	7	43	IXTACOMITAN	2022-11-11 12:31:55	\N
9985	7	44	IXTAPA	2022-11-11 12:31:55	\N
9986	7	45	IXTAPANGAJOYA	2022-11-11 12:31:55	\N
9987	7	46	JIQUIPILAS	2022-11-11 12:31:55	\N
9988	7	47	JITOTOL	2022-11-11 12:31:55	\N
9989	7	48	JUAREZ	2022-11-11 12:31:55	\N
9990	7	49	LARRAINZAR	2022-11-11 12:31:55	\N
9991	7	50	LA LIBERTAD	2022-11-11 12:31:55	\N
9992	7	51	MAPASTEPEC	2022-11-11 12:31:55	\N
9993	7	52	MARGARITAS, LAS	2022-11-11 12:31:55	\N
9994	7	53	MAZAPA DE MADERO	2022-11-11 12:31:55	\N
9995	7	54	MAZATAN	2022-11-11 12:31:55	\N
9996	7	55	METAPA	2022-11-11 12:31:55	\N
9997	7	56	MITONTIC	2022-11-11 12:31:55	\N
9998	7	57	MOTOZINTLA	2022-11-11 12:31:55	\N
9999	7	58	NICOLAS RUIZ	2022-11-11 12:31:55	\N
10000	7	59	OCOSINGO	2022-11-11 12:31:55	\N
10001	7	60	OCOTEPEC	2022-11-11 12:31:55	\N
10002	7	61	OCOZOCOAUTLA DE ESPINOSA	2022-11-11 12:31:55	\N
10003	7	62	OSTUACAN	2022-11-11 12:31:55	\N
10004	7	63	OSUMACINTA	2022-11-11 12:31:55	\N
10005	7	64	OXCHUC	2022-11-11 12:31:55	\N
10006	7	65	PALENQUE	2022-11-11 12:31:55	\N
10007	7	66	PANTELHO	2022-11-11 12:31:55	\N
10008	7	67	PANTEPEC	2022-11-11 12:31:55	\N
10009	7	68	PICHUCALCO	2022-11-11 12:31:55	\N
10010	7	69	PIJIJIAPAN	2022-11-11 12:31:55	\N
10011	7	70	EL PORVENIR	2022-11-11 12:31:55	\N
10012	7	71	VILLA COMALTITLAN	2022-11-11 12:31:55	\N
10013	7	72	PUEBLO NUEVO SOLISTAHUACAN	2022-11-11 12:31:55	\N
10014	7	73	RAYON	2022-11-11 12:31:55	\N
10015	7	74	REFORMA	2022-11-11 12:31:55	\N
10016	7	75	LAS ROSAS	2022-11-11 12:31:55	\N
10017	7	76	SABANILLA	2022-11-11 12:31:55	\N
10018	7	77	SALTO DE AGUA	2022-11-11 12:31:55	\N
10019	7	78	SAN CRISTOBAL DE LAS CASAS	2022-11-11 12:31:55	\N
10020	7	79	SAN FERNANDO	2022-11-11 12:31:55	\N
10021	7	80	SILTEPEC	2022-11-11 12:31:55	\N
10022	7	81	SIMOJOVEL	2022-11-11 12:31:55	\N
10023	7	82	SITALA	2022-11-11 12:31:55	\N
10024	7	83	SOCOLTENANGO	2022-11-11 12:31:55	\N
10025	7	84	SOLOSUCHIAPA	2022-11-11 12:31:55	\N
10026	7	85	SOYALO	2022-11-11 12:31:55	\N
10027	7	86	SUCHIAPA	2022-11-11 12:31:55	\N
10028	7	87	SUCHIATE	2022-11-11 12:31:55	\N
10029	7	88	SUNUAPA	2022-11-11 12:31:55	\N
10030	7	89	TAPACHULA	2022-11-11 12:31:55	\N
10031	7	90	TAPALAPA	2022-11-11 12:31:55	\N
10032	7	91	TAPILULA	2022-11-11 12:31:55	\N
10033	7	92	TECPATAN	2022-11-11 12:31:55	\N
10034	7	93	TENEJAPA	2022-11-11 12:31:55	\N
10035	7	94	TEOPISCA	2022-11-11 12:31:55	\N
10036	7	96	TILA	2022-11-11 12:31:55	\N
10037	7	97	TONALA	2022-11-11 12:31:55	\N
10038	7	98	TOTOLAPA	2022-11-11 12:31:55	\N
10039	7	99	TRINITARIA, LA	2022-11-11 12:31:55	\N
10040	7	100	TUMBALA	2022-11-11 12:31:55	\N
10041	7	101	TUXTLA GUTIERREZ	2022-11-11 12:31:55	\N
10042	7	102	TUXTLA CHICO	2022-11-11 12:31:55	\N
10043	7	103	TUZANTAN	2022-11-11 12:31:55	\N
10044	7	104	TZIMOL	2022-11-11 12:31:55	\N
10045	7	105	UNION JUAREZ	2022-11-11 12:31:55	\N
10046	7	106	VENUSTIANO CARRANZA	2022-11-11 12:31:55	\N
10047	7	107	VILLA CORZO	2022-11-11 12:31:55	\N
10048	7	108	VILLAFLORES	2022-11-11 12:31:55	\N
10049	7	109	YAJALON	2022-11-11 12:31:55	\N
10050	7	110	SAN LUCAS	2022-11-11 12:31:55	\N
10051	7	111	ZINACANTAN	2022-11-11 12:31:55	\N
10052	7	112	SAN JUAN CANCUC	2022-11-11 12:31:55	\N
10053	7	715	RESTO DE LOS MUNICIPIOS	2022-11-11 12:31:55	\N
10054	7	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10055	8	1	AHUMADA	2022-11-11 12:31:55	\N
10056	8	2	ALDAMA	2022-11-11 12:31:55	\N
10057	8	3	ALLENDE	2022-11-11 12:31:55	\N
10058	8	4	AQUILES SERDAN	2022-11-11 12:31:55	\N
10059	8	5	ASCENSION	2022-11-11 12:31:55	\N
10060	8	6	BACHINIVA	2022-11-11 12:31:55	\N
10061	8	7	BALLEZA	2022-11-11 12:31:55	\N
10062	8	8	BATOPILAS	2022-11-11 12:31:55	\N
10063	8	9	BOCOYNA	2022-11-11 12:31:55	\N
10064	8	10	BUENAVENTURA	2022-11-11 12:31:55	\N
10065	8	11	CAMARGO	2022-11-11 12:31:55	\N
10066	8	12	CARICHI	2022-11-11 12:31:55	\N
10067	8	13	CASAS GRANDES	2022-11-11 12:31:55	\N
10068	8	14	CORONADO	2022-11-11 12:31:55	\N
10069	8	15	COYAME	2022-11-11 12:31:55	\N
10070	8	16	LA CRUZ	2022-11-11 12:31:55	\N
10071	8	17	CUAUHTEMOC	2022-11-11 12:31:55	\N
10072	8	18	CUSIHUIRIACHI	2022-11-11 12:31:55	\N
10073	8	19	CHIHUAHUA	2022-11-11 12:31:55	\N
10074	8	20	CHINIPAS	2022-11-11 12:31:55	\N
10075	8	21	DELICIAS	2022-11-11 12:31:55	\N
10076	8	22	DOCTOR BELISARIO DOMINGUEZ	2022-11-11 12:31:55	\N
10077	8	23	GALEANA	2022-11-11 12:31:55	\N
10078	8	24	GENERAL TRIAS	2022-11-11 12:31:55	\N
10079	8	25	GOMEZ FARIAS	2022-11-11 12:31:55	\N
10080	8	26	GRAN MORELOS	2022-11-11 12:31:55	\N
10081	8	27	GUACHOCHI	2022-11-11 12:31:55	\N
10082	8	28	GUADALUPE	2022-11-11 12:31:55	\N
10083	8	29	GUADALUPE Y CALVO	2022-11-11 12:31:55	\N
10084	8	30	GUAZAPARES	2022-11-11 12:31:55	\N
10085	8	31	GUERRERO	2022-11-11 12:31:55	\N
10086	8	32	HIDALGO DEL PARRAL	2022-11-11 12:31:55	\N
10087	8	33	HUEJOTITAN	2022-11-11 12:31:55	\N
10088	8	34	IGNACIO ZARAGOZA	2022-11-11 12:31:55	\N
10089	8	35	JANOS	2022-11-11 12:31:55	\N
10090	8	36	JIMENEZ	2022-11-11 12:31:55	\N
10091	8	37	JUAREZ	2022-11-11 12:31:55	\N
10092	8	38	JULIMES	2022-11-11 12:31:55	\N
10093	8	39	LOPEZ	2022-11-11 12:31:55	\N
10094	8	40	MADERA	2022-11-11 12:31:55	\N
10095	8	41	MAGUARICHI	2022-11-11 12:31:55	\N
10096	8	42	MANUEL BENAVIDES	2022-11-11 12:31:55	\N
10097	8	43	MATACHI	2022-11-11 12:31:55	\N
10098	8	44	MATAMOROS	2022-11-11 12:31:55	\N
10099	8	45	MEOQUI	2022-11-11 12:31:55	\N
10100	8	46	MORELOS	2022-11-11 12:31:55	\N
10101	8	47	MORIS	2022-11-11 12:31:55	\N
10102	8	48	NAMIQUIPA	2022-11-11 12:31:55	\N
10103	8	49	NONOAVA	2022-11-11 12:31:55	\N
10104	8	50	NUEVO CASAS GRANDES	2022-11-11 12:31:55	\N
10105	8	51	OCAMPO	2022-11-11 12:31:55	\N
10106	8	52	OJINAGA	2022-11-11 12:31:55	\N
10107	8	53	PRAXEDIS G. GUERRERO	2022-11-11 12:31:55	\N
10108	8	54	RIVA PALACIO	2022-11-11 12:31:55	\N
10109	8	55	ROSALES	2022-11-11 12:31:55	\N
10110	8	56	ROSARIO	2022-11-11 12:31:55	\N
10111	8	57	SAN FRANCISCO DE BORJA	2022-11-11 12:31:55	\N
10112	8	58	SAN FRANCISCO DE CONCHOS	2022-11-11 12:31:55	\N
10113	8	59	SAN FRANCISCO DEL ORO	2022-11-11 12:31:55	\N
10114	8	60	SANTA BARBARA	2022-11-11 12:31:55	\N
10115	8	61	SATEVO	2022-11-11 12:31:55	\N
10116	8	62	SAUCILLO	2022-11-11 12:31:55	\N
10117	8	63	TEMOSACHI	2022-11-11 12:31:55	\N
10118	8	64	EL TULE	2022-11-11 12:31:55	\N
10119	8	65	URIQUE	2022-11-11 12:31:55	\N
10120	8	66	URUACHI	2022-11-11 12:31:55	\N
10121	8	67	VALLE DE ZARAGOZA	2022-11-11 12:31:55	\N
10122	8	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10123	9	1	ALVARO OBREGON	2022-11-11 12:31:55	\N
10124	9	2	AZCAPOTZALCO	2022-11-11 12:31:55	\N
10125	9	3	BENITO JUAREZ	2022-11-11 12:31:55	\N
10126	9	4	COYOACAN	2022-11-11 12:31:55	\N
10127	9	5	CUAJIMALPA DE MORELOS	2022-11-11 12:31:55	\N
10128	9	6	CUAUHTEMOC	2022-11-11 12:31:55	\N
10129	9	7	GUSTAVO A. MADERO	2022-11-11 12:31:55	\N
10130	9	8	IZTACALCO	2022-11-11 12:31:55	\N
10131	9	9	IZTAPALAPA	2022-11-11 12:31:55	\N
10132	9	10	MAGDALENA CONTRERAS, LA	2022-11-11 12:31:55	\N
10133	9	11	MIGUEL HIDALGO	2022-11-11 12:31:55	\N
10134	9	12	MILPA ALTA	2022-11-11 12:31:55	\N
10135	9	13	TLAHUAC	2022-11-11 12:31:55	\N
10136	9	14	TLALPAN	2022-11-11 12:31:55	\N
10137	9	15	VENUSTIANO CARRANZA	2022-11-11 12:31:55	\N
10138	9	16	XOCHIMILCO	2022-11-11 12:31:55	\N
10139	9	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10140	10	1	CANATLAN	2022-11-11 12:31:55	\N
10141	10	2	CANELAS	2022-11-11 12:31:55	\N
10142	10	3	CONETO DE COMONFORT	2022-11-11 12:31:55	\N
10143	10	4	CUENCAME	2022-11-11 12:31:55	\N
10144	10	5	DURANGO	2022-11-11 12:31:55	\N
10145	10	6	GENERAL SIMON BOLIVAR	2022-11-11 12:31:55	\N
10146	10	7	GOMEZ PALACIO	2022-11-11 12:31:55	\N
10147	10	8	GUADALUPE VICTORIA	2022-11-11 12:31:55	\N
10148	10	9	GUANACEVI	2022-11-11 12:31:55	\N
10149	10	10	HIDALGO	2022-11-11 12:31:55	\N
10150	10	11	INDE	2022-11-11 12:31:55	\N
10151	10	12	LERDO	2022-11-11 12:31:55	\N
10152	10	13	MAPIMI	2022-11-11 12:31:55	\N
10153	10	14	MEZQUITAL	2022-11-11 12:31:55	\N
10154	10	15	NAZAS	2022-11-11 12:31:55	\N
10155	10	16	NOMBRE DE DIOS	2022-11-11 12:31:55	\N
10156	10	17	OCAMPO	2022-11-11 12:31:55	\N
10157	10	18	EL ORO	2022-11-11 12:31:55	\N
10158	10	19	OTAEZ	2022-11-11 12:31:55	\N
10159	10	20	PANUCO DE CORONADO	2022-11-11 12:31:55	\N
10160	10	21	PEÑON BLANCO	2022-11-11 12:31:55	\N
10161	10	22	POANAS	2022-11-11 12:31:55	\N
10162	10	23	PUEBLO NUEVO	2022-11-11 12:31:55	\N
10163	10	24	RODEO	2022-11-11 12:31:55	\N
10164	10	25	SAN BERNARDO	2022-11-11 12:31:55	\N
10165	10	26	SAN DIMAS	2022-11-11 12:31:55	\N
10166	10	27	SAN JUAN DE GUADALUPE	2022-11-11 12:31:55	\N
10167	10	28	SAN JUAN DEL RIO	2022-11-11 12:31:55	\N
10168	10	29	SAN LUIS DEL CORDERO	2022-11-11 12:31:55	\N
10169	10	30	SAN PEDRO DEL GALLO	2022-11-11 12:31:55	\N
10170	10	31	SANTA CLARA	2022-11-11 12:31:55	\N
10171	10	32	SANTIAGO PAPASQUIARO	2022-11-11 12:31:55	\N
10172	10	33	SUCHIL	2022-11-11 12:31:55	\N
10173	10	34	TAMAZULA	2022-11-11 12:31:55	\N
10174	10	35	TEPEHUANES	2022-11-11 12:31:55	\N
10175	10	36	TLAHUALILO	2022-11-11 12:31:55	\N
10176	10	37	TOPIA	2022-11-11 12:31:55	\N
10177	10	38	VICENTE GUERRERO	2022-11-11 12:31:55	\N
10178	10	39	NUEVO IDEAL	2022-11-11 12:31:55	\N
10179	10	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10180	11	1	ABASOLO	2022-11-11 12:31:55	\N
10181	11	2	ACAMBARO	2022-11-11 12:31:55	\N
10182	11	3	ALLENDE	2022-11-11 12:31:55	\N
10183	11	4	APASEO EL ALTO	2022-11-11 12:31:55	\N
10184	11	5	APASEO EL GRANDE	2022-11-11 12:31:55	\N
10185	11	6	ATARJEA	2022-11-11 12:31:55	\N
10186	11	7	CELAYA	2022-11-11 12:31:55	\N
10187	11	8	MANUEL DOBLADO	2022-11-11 12:31:55	\N
10188	11	9	COMONFORT	2022-11-11 12:31:55	\N
10189	11	10	CORONEO	2022-11-11 12:31:55	\N
10190	11	11	CORTAZAR	2022-11-11 12:31:55	\N
10191	11	12	CUERAMARO	2022-11-11 12:31:55	\N
10192	11	13	DOCTOR MORA	2022-11-11 12:31:55	\N
10193	11	14	DOLORES HIDALGO	2022-11-11 12:31:55	\N
10194	11	15	GUANAJUATO	2022-11-11 12:31:55	\N
10195	11	16	HUANIMARO	2022-11-11 12:31:55	\N
10196	11	17	IRAPUATO	2022-11-11 12:31:55	\N
10197	11	18	JARAL DEL PROGRESO	2022-11-11 12:31:55	\N
10198	11	19	JERECUARO	2022-11-11 12:31:55	\N
10199	11	20	LEON	2022-11-11 12:31:55	\N
10200	11	21	MOROLEON	2022-11-11 12:31:55	\N
10201	11	22	OCAMPO	2022-11-11 12:31:55	\N
10202	11	23	PENJAMO	2022-11-11 12:31:55	\N
10203	11	24	PUEBLO NUEVO	2022-11-11 12:31:55	\N
10204	11	25	PURISIMA DEL RINCON	2022-11-11 12:31:55	\N
10205	11	26	ROMITA	2022-11-11 12:31:55	\N
10206	11	27	SALAMANCA	2022-11-11 12:31:55	\N
10207	11	28	SALVATIERRA	2022-11-11 12:31:55	\N
10208	11	29	SAN DIEGO DE LA UNION	2022-11-11 12:31:55	\N
10209	11	30	SAN FELIPE	2022-11-11 12:31:55	\N
10210	11	31	SAN FRANCISCO DEL RINCON	2022-11-11 12:31:55	\N
10211	11	32	SAN JOSE ITURBIDE	2022-11-11 12:31:55	\N
10212	11	33	SAN LUIS DE LA PAZ	2022-11-11 12:31:55	\N
10213	11	34	SANTA CATARINA	2022-11-11 12:31:55	\N
10214	11	35	SANTA CRUZ DE JUVENTINO ROSAS	2022-11-11 12:31:55	\N
10215	11	36	SANTIAGO MARAVATIO	2022-11-11 12:31:55	\N
10216	11	37	SILAO	2022-11-11 12:31:55	\N
10217	11	38	TARANDACUAO	2022-11-11 12:31:55	\N
10218	11	39	TARIMORO	2022-11-11 12:31:55	\N
10219	11	40	TIERRA BLANCA	2022-11-11 12:31:55	\N
10220	11	41	URIANGATO	2022-11-11 12:31:55	\N
10221	11	42	VALLE DE SANTIAGO	2022-11-11 12:31:55	\N
10222	11	43	VICTORIA	2022-11-11 12:31:55	\N
10223	11	44	VILLAGRAN	2022-11-11 12:31:55	\N
10224	11	45	XICHU	2022-11-11 12:31:55	\N
10225	11	46	YURIRIA	2022-11-11 12:31:55	\N
10226	11	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10227	12	1	ACAPULCO DE JUAREZ	2022-11-11 12:31:55	\N
10228	12	2	AHUACUOTZINGO	2022-11-11 12:31:55	\N
10229	12	3	AJUCHITLAN DEL PROGRESO	2022-11-11 12:31:55	\N
10230	12	4	ALCOZAUCA DE GUERRERO	2022-11-11 12:31:55	\N
10231	12	5	ALPOYECA	2022-11-11 12:31:55	\N
10232	12	6	APAXTLA	2022-11-11 12:31:55	\N
10233	12	7	ARCELIA	2022-11-11 12:31:55	\N
10234	12	8	ATENANGO DEL RIO	2022-11-11 12:31:55	\N
10235	12	9	ATLAMAJALCINGO DEL MONTE	2022-11-11 12:31:55	\N
10236	12	10	ATLIXTAC	2022-11-11 12:31:55	\N
10237	12	11	ATOYAC DE ALVAREZ	2022-11-11 12:31:55	\N
10238	12	12	AYUTLA DE LOS LIBRES	2022-11-11 12:31:55	\N
10239	12	13	AZOYU	2022-11-11 12:31:55	\N
10240	12	14	BENITO JUAREZ	2022-11-11 12:31:55	\N
10241	12	15	BUENAVISTA DE CUELLAR	2022-11-11 12:31:55	\N
10242	12	16	COAHUAYUTLA DE JOSE MARIA IZAZ	2022-11-11 12:31:55	\N
10243	12	17	COCULA	2022-11-11 12:31:55	\N
10244	12	18	COPALA	2022-11-11 12:31:55	\N
10245	12	19	COPALILLO	2022-11-11 12:31:55	\N
10246	12	20	COPANATOYAC	2022-11-11 12:31:55	\N
10247	12	21	COYUCA DE BENITEZ	2022-11-11 12:31:55	\N
10248	12	22	COYUCA DE CATALAN	2022-11-11 12:31:55	\N
10249	12	23	CUAJINICUILAPA	2022-11-11 12:31:55	\N
10250	12	24	CUALAC	2022-11-11 12:31:55	\N
10251	12	25	CUAUTEPEC	2022-11-11 12:31:55	\N
10252	12	26	CUETZALA DEL PROGRESO	2022-11-11 12:31:55	\N
10253	12	27	CUTZAMALA DE PINZON	2022-11-11 12:31:55	\N
10254	12	28	CHILAPA DE ALVAREZ	2022-11-11 12:31:55	\N
10255	12	29	CHILPANCINGO DE LOS BRAVO	2022-11-11 12:31:55	\N
10256	12	30	FLORENCIO VILLARREAL	2022-11-11 12:31:55	\N
10257	12	31	GENERAL CANUTO A. NERI	2022-11-11 12:31:55	\N
10258	12	32	GENERAL HELIODORO CASTILLO	2022-11-11 12:31:55	\N
10259	12	33	HUAMUXTITLAN	2022-11-11 12:31:55	\N
10260	12	34	HUITZUCO DE LOS FIGUEROA	2022-11-11 12:31:55	\N
10261	12	35	IGUALA DE LA INDEPENDENCIA	2022-11-11 12:31:55	\N
10262	12	36	IGUALAPA	2022-11-11 12:31:55	\N
10263	12	37	IXCATEOPAN DE CUAUHTEMOC	2022-11-11 12:31:55	\N
10264	12	38	JOSE AZUETA	2022-11-11 12:31:55	\N
10265	12	39	JUAN R. ESCUDERO	2022-11-11 12:31:55	\N
10266	12	40	LEONARDO BRAVO	2022-11-11 12:31:55	\N
10267	12	41	MALINALTEPEC	2022-11-11 12:31:55	\N
10268	12	42	MARTIR DE CUILAPAN	2022-11-11 12:31:55	\N
10269	12	43	METLATONOC	2022-11-11 12:31:55	\N
10270	12	44	MOCHITLAN	2022-11-11 12:31:55	\N
10271	12	45	OLINALA	2022-11-11 12:31:55	\N
10272	12	46	OMETEPEC	2022-11-11 12:31:55	\N
10273	12	47	PEDRO ASCENCIO ALQUISIRAS	2022-11-11 12:31:55	\N
10274	12	48	PETATLAN	2022-11-11 12:31:55	\N
10275	12	49	PILCAYA	2022-11-11 12:31:55	\N
10276	12	50	PUNGARABATO	2022-11-11 12:31:55	\N
10277	12	51	QUECHULTENANGO	2022-11-11 12:31:55	\N
10278	12	52	SAN LUIS ACATLAN	2022-11-11 12:31:55	\N
10279	12	53	SAN MARCOS	2022-11-11 12:31:55	\N
10280	12	54	SAN MIGUEL TOTOLAPAN	2022-11-11 12:31:55	\N
10281	12	55	TAXCO DE ALARCON	2022-11-11 12:31:55	\N
10282	12	56	TECOANAPA	2022-11-11 12:31:55	\N
10283	12	57	TECPAN DE GALEANA	2022-11-11 12:31:55	\N
10284	12	58	TELOLOAPAN	2022-11-11 12:31:55	\N
10285	12	59	TEPECOACUILCO DE TRUJANO	2022-11-11 12:31:55	\N
10286	12	60	TETIPAC	2022-11-11 12:31:55	\N
10287	12	61	TIXTLA DE GUERRERO	2022-11-11 12:31:55	\N
10288	12	62	TLACOACHISTLAHUACA	2022-11-11 12:31:55	\N
10289	12	63	TLACOAPA	2022-11-11 12:31:55	\N
10290	12	64	TLALCHAPA	2022-11-11 12:31:55	\N
10291	12	65	TLALIXTAQUILLA DE MALDONADO	2022-11-11 12:31:55	\N
10292	12	66	TLAPA DE COMONFORT	2022-11-11 12:31:55	\N
10293	12	67	TLAPEHUALA	2022-11-11 12:31:55	\N
10294	12	68	UNION, LA	2022-11-11 12:31:55	\N
10295	12	69	XALPATLAHUAC	2022-11-11 12:31:55	\N
10296	12	70	XOCHIHUEHUETLAN	2022-11-11 12:31:55	\N
10297	12	71	XOCHISTLAHUACA	2022-11-11 12:31:55	\N
10298	12	72	ZAPOTITLAN TABLAS	2022-11-11 12:31:55	\N
10299	12	73	ZIRANDARO	2022-11-11 12:31:55	\N
10300	12	74	ZITLALA	2022-11-11 12:31:55	\N
10301	12	75	EDUARDO NERI	2022-11-11 12:31:55	\N
10302	12	76	ACATEPEC	2022-11-11 12:31:55	\N
10303	12	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10304	13	1	ACATLAN	2022-11-11 12:31:55	\N
10305	13	2	ACAXOCHITLAN	2022-11-11 12:31:55	\N
10306	13	3	ACTOPAN	2022-11-11 12:31:55	\N
10307	13	4	AGUA BLANCA DE ITURBIDE	2022-11-11 12:31:55	\N
10308	13	5	AJACUBA	2022-11-11 12:31:55	\N
10309	13	6	ALFAJAYUCAN	2022-11-11 12:31:55	\N
10310	13	7	ALMOLOYA	2022-11-11 12:31:55	\N
10311	13	8	APAN	2022-11-11 12:31:55	\N
10312	13	9	ARENAL, EL	2022-11-11 12:31:55	\N
10313	13	10	ATITALAQUIA	2022-11-11 12:31:55	\N
10314	13	11	ATLAPEXCO	2022-11-11 12:31:55	\N
10315	13	12	ATOTONILCO EL GRANDE	2022-11-11 12:31:55	\N
10316	13	13	ATOTONILCO DE TULA	2022-11-11 12:31:55	\N
10317	13	14	CALNALI	2022-11-11 12:31:55	\N
10318	13	15	CARDONAL	2022-11-11 12:31:55	\N
10319	13	16	CUAUTEPEC DE HINOJOSA	2022-11-11 12:31:55	\N
10320	13	17	CHAPANTONGO	2022-11-11 12:31:55	\N
10321	13	18	CHAPULHUACAN	2022-11-11 12:31:55	\N
10322	13	19	CHILCUAUTLA	2022-11-11 12:31:55	\N
10323	13	20	ELOXOCHITLAN	2022-11-11 12:31:55	\N
10324	13	21	EMILIANO ZAPATA	2022-11-11 12:31:55	\N
10325	13	22	EPAZOYUCAN	2022-11-11 12:31:55	\N
10326	13	23	FRANCISCO I. MADERO	2022-11-11 12:31:55	\N
10327	13	24	HUASCA DE OCAMPO	2022-11-11 12:31:55	\N
10328	13	25	HUAUTLA	2022-11-11 12:31:55	\N
10329	13	26	HUAZALINGO	2022-11-11 12:31:55	\N
10330	13	27	HUEHUETLA	2022-11-11 12:31:55	\N
10331	13	28	HUEJUTLA DE REYES	2022-11-11 12:31:55	\N
10332	13	29	HUICHAPAN	2022-11-11 12:31:55	\N
10333	13	30	IXMIQUILPAN	2022-11-11 12:31:55	\N
10334	13	31	JACALA DE LEDEZMA	2022-11-11 12:31:55	\N
10335	13	32	JALTOCAN	2022-11-11 12:31:55	\N
10336	13	33	JUAREZ HIDALGO	2022-11-11 12:31:55	\N
10337	13	34	LOLOTLA	2022-11-11 12:31:55	\N
10338	13	35	METEPEC	2022-11-11 12:31:55	\N
10339	13	36	SAN AGUSTIN METZQUITITLAN	2022-11-11 12:31:55	\N
10340	13	37	METZTITLAN	2022-11-11 12:31:55	\N
10341	13	38	MINERAL DEL CHICO	2022-11-11 12:31:55	\N
10342	13	39	MINERAL DEL MONTE	2022-11-11 12:31:55	\N
10343	13	40	MISION, LA	2022-11-11 12:31:55	\N
10344	13	41	MIXQUIAHUALA DE JUAREZ	2022-11-11 12:31:55	\N
10345	13	42	MOLANGO DE ESCAMILLA	2022-11-11 12:31:55	\N
10346	13	43	NICOLAS FLORES	2022-11-11 12:31:55	\N
10347	13	44	NOPALA DE VILLAGRAN	2022-11-11 12:31:55	\N
10348	13	45	OMITLAN DE JUAREZ	2022-11-11 12:31:55	\N
10349	13	46	SAN FELIPE ORIZATLAN	2022-11-11 12:31:55	\N
10350	13	47	PACULA	2022-11-11 12:31:55	\N
10351	13	48	PACHUCA DE SOTO	2022-11-11 12:31:55	\N
10352	13	49	PISAFLORES	2022-11-11 12:31:55	\N
10353	13	50	PROGRESO DE OBREGON	2022-11-11 12:31:55	\N
10354	13	51	MINERAL DE LA REFORMA	2022-11-11 12:31:55	\N
10355	13	52	SAN AGUSTIN TLAXIACA	2022-11-11 12:31:55	\N
10356	13	53	SAN BARTOLO TUTOTEPEC	2022-11-11 12:31:55	\N
10357	13	54	SAN SALVADOR	2022-11-11 12:31:55	\N
10358	13	55	SANTIAGO DE ANAYA	2022-11-11 12:31:55	\N
10359	13	56	SANTIAGO TULANTEPEC DE LUGO GU	2022-11-11 12:31:55	\N
10360	13	57	SINGUILUCAN	2022-11-11 12:31:55	\N
10361	13	58	TASQUILLO	2022-11-11 12:31:55	\N
10362	13	59	TECOZAUTLA	2022-11-11 12:31:55	\N
10363	13	60	TENANGO DE DORIA	2022-11-11 12:31:55	\N
10364	13	61	TEPEAPULCO	2022-11-11 12:31:55	\N
10365	13	62	TEPEHUACAN DE GUERRERO	2022-11-11 12:31:55	\N
10366	13	63	TEPEJI DEL RIO DE OCAMPO	2022-11-11 12:31:55	\N
10367	13	64	TEPETITLAN	2022-11-11 12:31:55	\N
10368	13	65	TETEPANGO	2022-11-11 12:31:55	\N
10369	13	66	VILLA DE TEZONTEPEC	2022-11-11 12:31:55	\N
10370	13	67	TEZONTEPEC DE ALDAMA	2022-11-11 12:31:55	\N
10371	13	68	TIANGUISTENGO	2022-11-11 12:31:55	\N
10372	13	69	TIZAYUCA	2022-11-11 12:31:55	\N
10373	13	70	TLAHUELILPAN	2022-11-11 12:31:55	\N
10374	13	71	TLAHUILTEPA	2022-11-11 12:31:55	\N
10375	13	72	TLANALAPA	2022-11-11 12:31:55	\N
10376	13	73	TLANCHINOL	2022-11-11 12:31:55	\N
10377	13	74	TLAXCOAPAN	2022-11-11 12:31:55	\N
10378	13	75	TOLCAYUCA	2022-11-11 12:31:55	\N
10379	13	76	TULA DE ALLENDE	2022-11-11 12:31:55	\N
10380	13	77	TULANCINGO DE BRAVO	2022-11-11 12:31:55	\N
10381	13	78	XOCHIATIPAN	2022-11-11 12:31:55	\N
10382	13	79	XOCHICOATLAN	2022-11-11 12:31:55	\N
10383	13	80	YAHUALICA	2022-11-11 12:31:55	\N
10384	13	81	ZACUALTIPAN DE ANGELES	2022-11-11 12:31:55	\N
10385	13	82	ZAPOTLAN DE JUAREZ	2022-11-11 12:31:55	\N
10386	13	83	ZEMPOALA	2022-11-11 12:31:55	\N
10387	13	84	ZIMAPAN	2022-11-11 12:31:55	\N
10388	13	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10389	14	1	ACATIC	2022-11-11 12:31:55	\N
10390	14	2	ACATLAN DE JUAREZ	2022-11-11 12:31:55	\N
10391	14	3	AHUALULCO DE MERCADO	2022-11-11 12:31:55	\N
10392	14	4	AMACUECA	2022-11-11 12:31:55	\N
10393	14	5	AMATITAN	2022-11-11 12:31:55	\N
10394	14	6	AMECA	2022-11-11 12:31:55	\N
10395	14	7	ANTONIO ESCOBEDO	2022-11-11 12:31:55	\N
10396	14	8	ARANDAS	2022-11-11 12:31:55	\N
10397	14	9	ARENAL	2022-11-11 12:31:55	\N
10398	14	10	ATEMAJAC DE BRIZUELA	2022-11-11 12:31:55	\N
10399	14	11	ATENGO	2022-11-11 12:31:55	\N
10400	14	12	ATENGUILLO	2022-11-11 12:31:55	\N
10401	14	13	ATOTONILCO EL ALTO	2022-11-11 12:31:55	\N
10402	14	14	ATOYAC	2022-11-11 12:31:55	\N
10403	14	15	AUTLAN DE NAVARRO	2022-11-11 12:31:55	\N
10404	14	16	AYOTLAN	2022-11-11 12:31:55	\N
10405	14	17	AYUTLA	2022-11-11 12:31:55	\N
10406	14	18	BARCA, LA	2022-11-11 12:31:55	\N
10407	14	19	BOLA¥OS	2022-11-11 12:31:55	\N
10408	14	20	CABO CORRIENTES	2022-11-11 12:31:55	\N
10409	14	21	CASIMIRO CASTILLO	2022-11-11 12:31:55	\N
10410	14	22	CIHUATLAN	2022-11-11 12:31:55	\N
10411	14	23	CIUDAD GUZMAN	2022-11-11 12:31:55	\N
10412	14	24	COCULA	2022-11-11 12:31:55	\N
10413	14	25	COLOTLAN	2022-11-11 12:31:55	\N
10414	14	26	CONCEPCION DE BUENOS AIRES	2022-11-11 12:31:55	\N
10415	14	27	CUAUTITLAN	2022-11-11 12:31:55	\N
10416	14	28	CUAUTLA	2022-11-11 12:31:55	\N
10417	14	29	CUQUIO	2022-11-11 12:31:55	\N
10418	14	30	CHAPALA	2022-11-11 12:31:55	\N
10419	14	31	CHIMALTITAN	2022-11-11 12:31:55	\N
10420	14	32	CHIQUILISTLAN	2022-11-11 12:31:55	\N
10421	14	33	DEGOLLADO	2022-11-11 12:31:55	\N
10422	14	34	EJUTLA	2022-11-11 12:31:55	\N
10423	14	35	ENCARNACION DE DIAZ	2022-11-11 12:31:55	\N
10424	14	36	ETZATLAN	2022-11-11 12:31:55	\N
10425	14	37	GRULLO, EL	2022-11-11 12:31:55	\N
10426	14	38	GUACHINANGO	2022-11-11 12:31:55	\N
10427	14	39	GUADALAJARA	2022-11-11 12:31:55	\N
10428	14	40	HOSTOTIPAQUILLO	2022-11-11 12:31:55	\N
10429	14	41	HUEJUCAR	2022-11-11 12:31:55	\N
10430	14	42	HUEJUQUILLA EL ALTO	2022-11-11 12:31:55	\N
10431	14	43	HUERTA, LA	2022-11-11 12:31:55	\N
10432	14	44	IXTLAHUACAN DE LOS MEMBRILLOS	2022-11-11 12:31:55	\N
10433	14	45	IXTLAHUACAN DEL RIO	2022-11-11 12:31:55	\N
10434	14	46	JALOSTOTITLAN	2022-11-11 12:31:55	\N
10435	14	47	JAMAY	2022-11-11 12:31:55	\N
10436	14	48	JESUS MARIA	2022-11-11 12:31:55	\N
10437	14	49	JILOTLAN DE LOS DOLORES	2022-11-11 12:31:55	\N
10438	14	50	JOCOTEPEC	2022-11-11 12:31:55	\N
10439	14	51	JUANACATLAN	2022-11-11 12:31:55	\N
10440	14	52	JUCHITLAN	2022-11-11 12:31:55	\N
10441	14	53	LAGOS DE MORENO	2022-11-11 12:31:55	\N
10442	14	54	EL LIMON	2022-11-11 12:31:55	\N
10443	14	55	MAGDALENA	2022-11-11 12:31:55	\N
10444	14	56	MANUEL M. DIEGUEZ	2022-11-11 12:31:55	\N
10445	14	57	LA MANZANILLA DE LA PAZ	2022-11-11 12:31:55	\N
10446	14	58	MASCOTA	2022-11-11 12:31:55	\N
10447	14	59	MAZAMITLA	2022-11-11 12:31:55	\N
10448	14	60	MEXTICACAN	2022-11-11 12:31:55	\N
10449	14	61	MEZQUITIC	2022-11-11 12:31:55	\N
10450	14	62	MIXTLAN	2022-11-11 12:31:55	\N
10451	14	63	OCOTLAN	2022-11-11 12:31:55	\N
10452	14	64	OJUELOS DE JALISCO	2022-11-11 12:31:55	\N
10453	14	65	PIHUAMO	2022-11-11 12:31:55	\N
10454	14	66	PONCITLAN	2022-11-11 12:31:55	\N
10455	14	67	PUERTO VALLARTA	2022-11-11 12:31:55	\N
10456	14	68	VILLA PURIFICACION	2022-11-11 12:31:55	\N
10457	14	69	QUITUPAN	2022-11-11 12:31:55	\N
10458	14	70	EL SALTO	2022-11-11 12:31:55	\N
10459	14	71	SAN CRISTOBAL DE LA BARRANCA	2022-11-11 12:31:55	\N
10460	14	72	SAN DIEGO DE ALEJANDRIA	2022-11-11 12:31:55	\N
10461	14	73	SAN JUAN DE LOS LAGOS	2022-11-11 12:31:55	\N
10462	14	74	SAN JULIAN	2022-11-11 12:31:55	\N
10463	14	75	SAN MARCOS	2022-11-11 12:31:55	\N
10464	14	76	SAN MARTIN DE BOLAÑOS	2022-11-11 12:31:55	\N
10465	14	77	SAN MARTIN HIDALGO	2022-11-11 12:31:55	\N
10466	14	78	SAN MIGUEL EL ALTO	2022-11-11 12:31:55	\N
10467	14	79	GOMEZ FARIAS	2022-11-11 12:31:55	\N
10468	14	80	SAN SEBASTIAN DEL OESTE	2022-11-11 12:31:55	\N
10469	14	81	SANTA MARIA DE LOS ANGELES	2022-11-11 12:31:55	\N
10470	14	82	SAYULA	2022-11-11 12:31:55	\N
10471	14	83	TALA	2022-11-11 12:31:55	\N
10472	14	84	TALPA DE ALLENDE	2022-11-11 12:31:55	\N
10473	14	85	TAMAZULA DE GORDIANO	2022-11-11 12:31:55	\N
10474	14	86	TAPALPA	2022-11-11 12:31:55	\N
10475	14	87	TECALITLAN	2022-11-11 12:31:55	\N
10476	14	88	TECOLOTLAN	2022-11-11 12:31:55	\N
10477	14	89	TECHALUTA DE MONTENEGRO	2022-11-11 12:31:55	\N
10478	14	90	TENAMAXTLAN	2022-11-11 12:31:55	\N
10479	14	91	TEOCALTICHE	2022-11-11 12:31:55	\N
10480	14	92	TEOCUITATLAN DE CORONA	2022-11-11 12:31:55	\N
10481	14	93	TEPATITLAN DE MORELOS	2022-11-11 12:31:55	\N
10482	14	94	TEQUILA	2022-11-11 12:31:55	\N
10483	14	95	TEUCHITLAN	2022-11-11 12:31:55	\N
10484	14	96	TIZAPAN EL ALTO	2022-11-11 12:31:55	\N
10485	14	97	TLAJOMULCO DE ZUÑIGA	2022-11-11 12:31:55	\N
10486	14	98	TLAQUEPAQUE	2022-11-11 12:31:55	\N
10487	14	99	TOLIMAN	2022-11-11 12:31:55	\N
10488	14	100	TOMATLAN	2022-11-11 12:31:55	\N
10489	14	101	TONALA	2022-11-11 12:31:55	\N
10490	14	102	TONAYA	2022-11-11 12:31:55	\N
10491	14	103	TONILA	2022-11-11 12:31:55	\N
10492	14	104	TOTATACHE	2022-11-11 12:31:55	\N
10493	14	105	TOTOTLAN	2022-11-11 12:31:55	\N
10494	14	106	TUXCACUESCO	2022-11-11 12:31:55	\N
10495	14	107	TUXCUECA	2022-11-11 12:31:55	\N
10496	14	108	TUXPAN	2022-11-11 12:31:55	\N
10497	14	109	UNION DE SAN ANTONIO	2022-11-11 12:31:55	\N
10498	14	110	UNION DE TULA	2022-11-11 12:31:55	\N
10499	14	111	VALLE DE GUADALUPE	2022-11-11 12:31:55	\N
10500	14	112	VALLE DE JUAREZ	2022-11-11 12:31:55	\N
10501	14	113	CIUDAD VENUSTIANO CARRANZA	2022-11-11 12:31:55	\N
10502	14	114	VILLA CORONA	2022-11-11 12:31:55	\N
10503	14	115	VILLA GUERRERO	2022-11-11 12:31:55	\N
10504	14	116	VILLA HIDALGO	2022-11-11 12:31:55	\N
10505	14	117	CAÑADAS DE OBREGON	2022-11-11 12:31:55	\N
10506	14	118	YAHUALICA DE GONZALEZ GALLO	2022-11-11 12:31:55	\N
10507	14	119	ZACOALCO DE TORRES	2022-11-11 12:31:55	\N
10508	14	120	ZAPOPAN	2022-11-11 12:31:55	\N
10509	14	121	ZAPOTILTIC	2022-11-11 12:31:55	\N
10510	14	122	ZAPOTITLAN DE VADILLO	2022-11-11 12:31:55	\N
10511	14	123	ZAPOTLAN DEL REY	2022-11-11 12:31:55	\N
10512	14	124	ZAPOTLANEJO	2022-11-11 12:31:55	\N
10513	14	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10514	15	1	ACAMBAY	2022-11-11 12:31:55	\N
10515	15	2	ACOLMAN	2022-11-11 12:31:55	\N
10516	15	3	ACULCO	2022-11-11 12:31:55	\N
10517	15	4	ALMOLOYA DE ALQUISIRAS	2022-11-11 12:31:55	\N
10518	15	5	ALMOLOYA DE JUAREZ	2022-11-11 12:31:55	\N
10519	15	6	ALMOLOYA DEL RIO	2022-11-11 12:31:55	\N
10520	15	7	AMANALCO	2022-11-11 12:31:55	\N
10521	15	8	AMATEPEC	2022-11-11 12:31:55	\N
10522	15	9	AMECAMECA	2022-11-11 12:31:55	\N
10523	15	10	APAXCO	2022-11-11 12:31:55	\N
10524	15	11	ATENCO	2022-11-11 12:31:55	\N
10525	15	12	ATIZAPAN	2022-11-11 12:31:55	\N
10526	15	13	ATIZAPAN DE ZARAGOZA	2022-11-11 12:31:55	\N
10527	15	14	ATLACOMULCO	2022-11-11 12:31:55	\N
10528	15	15	ATLAUTLA	2022-11-11 12:31:55	\N
10529	15	16	AXAPUSCO	2022-11-11 12:31:55	\N
10530	15	17	AYAPANGO	2022-11-11 12:31:55	\N
10531	15	18	CALIMAYA	2022-11-11 12:31:55	\N
10532	15	19	CAPULHUAC	2022-11-11 12:31:55	\N
10533	15	20	COACALCO	2022-11-11 12:31:55	\N
10534	15	21	COATEPEC HARINAS	2022-11-11 12:31:55	\N
10535	15	22	COCOTITLAN	2022-11-11 12:31:55	\N
10536	15	23	COYOTEPEC	2022-11-11 12:31:55	\N
10537	15	24	CUAUTITLAN	2022-11-11 12:31:55	\N
10538	15	25	CHALCO	2022-11-11 12:31:55	\N
10539	15	26	CHAPA DE MOTA	2022-11-11 12:31:55	\N
10540	15	27	CHAPULTEPEC	2022-11-11 12:31:55	\N
10541	15	28	CHIAUTLA	2022-11-11 12:31:55	\N
10542	15	29	CHICOLOAPAN	2022-11-11 12:31:55	\N
10543	15	30	CHICONCUAC	2022-11-11 12:31:55	\N
10544	15	31	CHIMALHUACAN	2022-11-11 12:31:55	\N
10545	15	32	DONATO GUERRA	2022-11-11 12:31:55	\N
10546	15	33	ECATEPEC	2022-11-11 12:31:55	\N
10547	15	34	ECATZINGO	2022-11-11 12:31:55	\N
10548	15	35	HUEHUETOCA	2022-11-11 12:31:55	\N
10549	15	36	HUEYPOXTLA	2022-11-11 12:31:55	\N
10550	15	37	HUIXQUILUCAN	2022-11-11 12:31:55	\N
10551	15	38	ISIDRO FABELA	2022-11-11 12:31:55	\N
10552	15	39	IXTAPALUCA	2022-11-11 12:31:55	\N
10553	15	40	IXTAPAN DE LA SAL	2022-11-11 12:31:55	\N
10554	15	41	IXTAPAN DEL ORO	2022-11-11 12:31:55	\N
10555	15	42	IXTLAHUACA	2022-11-11 12:31:55	\N
10556	15	43	JALATLACO	2022-11-11 12:31:55	\N
10557	15	44	JALTENCO	2022-11-11 12:31:55	\N
10558	15	45	JILOTEPEC	2022-11-11 12:31:55	\N
10559	15	46	JILOTZINGO	2022-11-11 12:31:55	\N
10560	15	47	JIQUIPILCO	2022-11-11 12:31:55	\N
10561	15	48	JOCOTITLAN	2022-11-11 12:31:55	\N
10562	15	49	JOQUICINGO	2022-11-11 12:31:55	\N
10563	15	50	JUCHITEPEC	2022-11-11 12:31:55	\N
10564	15	51	LERMA	2022-11-11 12:31:55	\N
10565	15	52	MALINALCO	2022-11-11 12:31:55	\N
10566	15	53	MELCHOR OCAMPO	2022-11-11 12:31:55	\N
10567	15	54	METEPEC	2022-11-11 12:31:55	\N
10568	15	55	MEXICALCINGO	2022-11-11 12:31:55	\N
10569	15	56	MORELOS	2022-11-11 12:31:55	\N
10570	15	57	NAUCALPAN	2022-11-11 12:31:55	\N
10571	15	58	NEZAHUALCOYOTL	2022-11-11 12:31:55	\N
10572	15	59	NEXTLALPAN	2022-11-11 12:31:55	\N
10573	15	60	NICOLAS ROMERO	2022-11-11 12:31:55	\N
10574	15	61	NOPALTEPEC	2022-11-11 12:31:55	\N
10575	15	62	OCOYOACAC	2022-11-11 12:31:55	\N
10576	15	63	OCUILAN	2022-11-11 12:31:55	\N
10577	15	64	ORO, EL	2022-11-11 12:31:55	\N
10578	15	65	OTUMBA	2022-11-11 12:31:55	\N
10579	15	66	OTZOLOAPAN	2022-11-11 12:31:55	\N
10580	15	67	OTZOLOTEPEC	2022-11-11 12:31:55	\N
10581	15	68	OZUMBA	2022-11-11 12:31:55	\N
10582	15	69	PAPALOTLA	2022-11-11 12:31:55	\N
10583	15	70	PAZ, LA	2022-11-11 12:31:55	\N
10584	15	71	POLOTITLAN	2022-11-11 12:31:55	\N
10585	15	72	RAYON	2022-11-11 12:31:55	\N
10586	15	73	SAN ANTONIO LA ISLA	2022-11-11 12:31:55	\N
10587	15	74	SAN FELIPE DEL PROGRESO	2022-11-11 12:31:55	\N
10588	15	75	SAN MARTIN DE LAS PIRAMIDES	2022-11-11 12:31:55	\N
10589	15	76	SAN MATEO ATENCO	2022-11-11 12:31:55	\N
10590	15	77	SAN SIMON DE GUERRERO	2022-11-11 12:31:55	\N
10591	15	78	SANTO TOMAS	2022-11-11 12:31:55	\N
10592	15	79	SOYANIQUILPAN DE JUAREZ	2022-11-11 12:31:55	\N
10593	15	80	SULTEPEC	2022-11-11 12:31:55	\N
10594	15	81	TECAMAC	2022-11-11 12:31:55	\N
10595	15	82	TEJUPILCO	2022-11-11 12:31:55	\N
10596	15	83	TEMAMATLA	2022-11-11 12:31:55	\N
10597	15	84	TEMASCALAPA	2022-11-11 12:31:55	\N
10598	15	85	TEMASCALCINGO	2022-11-11 12:31:55	\N
10599	15	86	TEMASCALTEPEC	2022-11-11 12:31:55	\N
10600	15	87	TEMOAYA	2022-11-11 12:31:55	\N
10601	15	88	TENANCINGO	2022-11-11 12:31:55	\N
10602	15	89	TENANGO DEL AIRE	2022-11-11 12:31:55	\N
10603	15	90	TENANGO DEL VALLE	2022-11-11 12:31:55	\N
10604	15	91	TEOLOYUCAN	2022-11-11 12:31:55	\N
10605	15	92	TEOTIHUACAN	2022-11-11 12:31:55	\N
10606	15	93	TEPETLAOXTOC	2022-11-11 12:31:55	\N
10607	15	94	TEPETLIXPA	2022-11-11 12:31:55	\N
10608	15	95	TEPOTZOTLAN	2022-11-11 12:31:55	\N
10609	15	96	TEQUIXQUIAC	2022-11-11 12:31:55	\N
10610	15	97	TEXCALTITLAN	2022-11-11 12:31:55	\N
10611	15	98	TEXCALYACAC	2022-11-11 12:31:55	\N
10612	15	99	TEXCOCO	2022-11-11 12:31:55	\N
10613	15	100	TEZOYUCA	2022-11-11 12:31:55	\N
10614	15	101	TIANGUISTENCO	2022-11-11 12:31:55	\N
10615	15	102	TIMILPAN	2022-11-11 12:31:55	\N
10616	15	103	TLALMANALCO	2022-11-11 12:31:55	\N
10617	15	104	TLALNEPANTLA	2022-11-11 12:31:55	\N
10618	15	105	TLATLAYA	2022-11-11 12:31:55	\N
10619	15	106	TOLUCA	2022-11-11 12:31:55	\N
10620	15	107	TONATICO	2022-11-11 12:31:55	\N
10621	15	108	TULTEPEC	2022-11-11 12:31:55	\N
10622	15	109	TULTITLAN	2022-11-11 12:31:55	\N
10623	15	110	VALLE DE BRAVO	2022-11-11 12:31:55	\N
10624	15	111	VILLA DE ALLENDE	2022-11-11 12:31:55	\N
10625	15	112	VILLA DEL CARBON	2022-11-11 12:31:55	\N
10626	15	113	VILLA GUERRERO	2022-11-11 12:31:55	\N
10627	15	114	VILLA VICTORIA	2022-11-11 12:31:55	\N
10628	15	115	XONACATLAN	2022-11-11 12:31:55	\N
10629	15	116	ZACAZONAPAN	2022-11-11 12:31:55	\N
10630	15	117	ZACUALPAN	2022-11-11 12:31:55	\N
10631	15	118	ZINACANTEPEC	2022-11-11 12:31:55	\N
10632	15	119	ZUMPAHUACAN	2022-11-11 12:31:55	\N
10633	15	120	ZUMPANGO	2022-11-11 12:31:55	\N
10634	15	121	CUAUTITLAN IZCALLI	2022-11-11 12:31:55	\N
10635	15	122	VALLE DE CHALCO	2022-11-11 12:31:55	\N
10636	15	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10637	16	1	ACUITZIO	2022-11-11 12:31:55	\N
10638	16	2	AGUILILLA	2022-11-11 12:31:55	\N
10639	16	3	ALVARO OBREGON	2022-11-11 12:31:55	\N
10640	16	4	ANGAMACUTIRO	2022-11-11 12:31:55	\N
10641	16	5	ANGANGUEO	2022-11-11 12:31:55	\N
10642	16	6	APATZINGAN	2022-11-11 12:31:55	\N
10643	16	7	APORO	2022-11-11 12:31:55	\N
10644	16	8	AQUILA	2022-11-11 12:31:55	\N
10645	16	9	ARIO	2022-11-11 12:31:55	\N
10646	16	10	ARTEAGA	2022-11-11 12:31:55	\N
10647	16	11	BRISEÑAS	2022-11-11 12:31:55	\N
10648	16	12	BUENAVISTA	2022-11-11 12:31:55	\N
10649	16	13	CARACUARO	2022-11-11 12:31:55	\N
10650	16	14	COAHUAYANA	2022-11-11 12:31:55	\N
10651	16	15	COALCOMAN DE VAZQUEZ PALLARES	2022-11-11 12:31:55	\N
10652	16	16	COENEO	2022-11-11 12:31:55	\N
10653	16	17	CONTEPEC	2022-11-11 12:31:55	\N
10654	16	18	COPANDARO	2022-11-11 12:31:55	\N
10655	16	19	COTIJA	2022-11-11 12:31:55	\N
10656	16	20	CUITZEO	2022-11-11 12:31:55	\N
10657	16	21	CHARAPAN	2022-11-11 12:31:55	\N
10658	16	22	CHARO	2022-11-11 12:31:55	\N
10659	16	23	CHAVINDA	2022-11-11 12:31:55	\N
10660	16	24	CHERAN	2022-11-11 12:31:55	\N
10661	16	25	CHILCHOTA	2022-11-11 12:31:55	\N
10662	16	26	CHINICUILA	2022-11-11 12:31:55	\N
10663	16	27	CHUCANDIRO	2022-11-11 12:31:55	\N
10664	16	28	CHURINTZIO	2022-11-11 12:31:55	\N
10665	16	29	CHURUMUCO	2022-11-11 12:31:55	\N
10666	16	30	ECUANDUREO	2022-11-11 12:31:55	\N
10667	16	31	EPITACIO HUERTA	2022-11-11 12:31:55	\N
10668	16	32	ERONGARICUARO	2022-11-11 12:31:55	\N
10669	16	33	GABRIEL ZAMORA	2022-11-11 12:31:55	\N
10670	16	34	HIDALGO	2022-11-11 12:31:55	\N
10671	16	35	HUACANA, LA	2022-11-11 12:31:55	\N
10672	16	36	HUANDACAREO	2022-11-11 12:31:55	\N
10673	16	37	HUANIQUEO	2022-11-11 12:31:55	\N
10674	16	38	HUETAMO	2022-11-11 12:31:55	\N
10675	16	39	HUIRAMBA	2022-11-11 12:31:55	\N
10676	16	40	INDAPARAPEO	2022-11-11 12:31:55	\N
10677	16	41	IRIMBO	2022-11-11 12:31:55	\N
10678	16	42	IXTLAN	2022-11-11 12:31:55	\N
10679	16	43	JACONA	2022-11-11 12:31:55	\N
10680	16	44	JIMENEZ	2022-11-11 12:31:55	\N
10681	16	45	JIQUILPAN	2022-11-11 12:31:55	\N
10682	16	46	JUAREZ	2022-11-11 12:31:55	\N
10683	16	47	JUNGAPEO	2022-11-11 12:31:55	\N
10684	16	48	LAGUNILLAS	2022-11-11 12:31:55	\N
10685	16	49	MADERO	2022-11-11 12:31:55	\N
10686	16	50	MARAVATIO	2022-11-11 12:31:55	\N
10687	16	51	MARCOS CASTELLANOS	2022-11-11 12:31:55	\N
10688	16	52	LAZARO CARDENAS	2022-11-11 12:31:55	\N
10689	16	53	MORELIA	2022-11-11 12:31:55	\N
10690	16	54	MORELOS	2022-11-11 12:31:55	\N
10691	16	55	MUGICA	2022-11-11 12:31:55	\N
10692	16	56	NAHUATZEN	2022-11-11 12:31:55	\N
10693	16	57	NOCUPETARO	2022-11-11 12:31:55	\N
10694	16	58	NUEVO PARANGARICUTIRO	2022-11-11 12:31:55	\N
10695	16	59	NUEVO URECHO	2022-11-11 12:31:55	\N
10696	16	60	NUMARAN	2022-11-11 12:31:55	\N
10697	16	61	OCAMPO	2022-11-11 12:31:55	\N
10698	16	62	PAJACUARAN	2022-11-11 12:31:55	\N
10699	16	63	PANINDICUARO	2022-11-11 12:31:55	\N
10700	16	64	PARACUARO	2022-11-11 12:31:55	\N
10701	16	65	PARACHO	2022-11-11 12:31:55	\N
10702	16	66	PATZCUARO	2022-11-11 12:31:55	\N
10703	16	67	PENJAMILLO	2022-11-11 12:31:55	\N
10704	16	68	PERIBAN	2022-11-11 12:31:55	\N
10705	16	69	LA PIEDAD	2022-11-11 12:31:55	\N
10706	16	70	PUREPERO	2022-11-11 12:31:55	\N
10707	16	71	PURUANDIRO	2022-11-11 12:31:55	\N
10708	16	72	QUERENDARO	2022-11-11 12:31:55	\N
10709	16	73	QUIROGA	2022-11-11 12:31:55	\N
10710	16	74	COJUMATLAN DE REGULES	2022-11-11 12:31:55	\N
10711	16	75	LOS REYES	2022-11-11 12:31:55	\N
10712	16	76	SAHUAYO	2022-11-11 12:31:55	\N
10713	16	77	SAN LUCAS	2022-11-11 12:31:55	\N
10714	16	78	SANTA ANA MAYA	2022-11-11 12:31:55	\N
10715	16	79	SALVADOR ESCALANTE	2022-11-11 12:31:55	\N
10716	16	80	SENGUIO	2022-11-11 12:31:55	\N
10717	16	81	SUSUPUATO	2022-11-11 12:31:55	\N
10718	16	82	TACAMBARO	2022-11-11 12:31:55	\N
10719	16	83	TANCITARO	2022-11-11 12:31:55	\N
10720	16	84	TANGAMANDAPIO	2022-11-11 12:31:55	\N
10721	16	85	TANGANCICUARO	2022-11-11 12:31:55	\N
10722	16	86	TANHUATO	2022-11-11 12:31:55	\N
10723	16	87	TARETAN	2022-11-11 12:31:55	\N
10724	16	88	TARIMBARO	2022-11-11 12:31:55	\N
10725	16	89	TEPALCATEPEC	2022-11-11 12:31:55	\N
10726	16	90	TINGAMBATO	2022-11-11 12:31:55	\N
10727	16	91	TINGUINDIN	2022-11-11 12:31:55	\N
10728	16	92	TIQUICHEO DE NICOLAS ROMERO	2022-11-11 12:31:55	\N
10729	16	93	TLALPUJAHUA	2022-11-11 12:31:55	\N
10730	16	94	TLAZAZALCA	2022-11-11 12:31:55	\N
10731	16	95	TOCUMBO	2022-11-11 12:31:55	\N
10732	16	96	TUMBISCATIO	2022-11-11 12:31:55	\N
10733	16	97	TURICATO	2022-11-11 12:31:55	\N
10734	16	98	TUXPAN	2022-11-11 12:31:55	\N
10735	16	99	TUZANTLA	2022-11-11 12:31:55	\N
10736	16	100	TZINTZUNTZAN	2022-11-11 12:31:55	\N
10737	16	101	TZITZIO	2022-11-11 12:31:55	\N
10738	16	102	URUAPAN	2022-11-11 12:31:55	\N
10739	16	103	VENUSTIANO CARRANZA	2022-11-11 12:31:55	\N
10740	16	104	VILLAMAR	2022-11-11 12:31:55	\N
10741	16	105	VISTA HERMOSA	2022-11-11 12:31:55	\N
10742	16	106	YURECUARO	2022-11-11 12:31:55	\N
10743	16	107	ZACAPU	2022-11-11 12:31:55	\N
10744	16	108	ZAMORA	2022-11-11 12:31:55	\N
10745	16	109	ZINAPARO	2022-11-11 12:31:55	\N
10746	16	110	ZINAPECUARO	2022-11-11 12:31:55	\N
10747	16	111	ZIRACUARETIRO	2022-11-11 12:31:55	\N
10748	16	112	ZITACUARO	2022-11-11 12:31:55	\N
10749	16	113	JOSE SIXTO VERDUZCO	2022-11-11 12:31:55	\N
10750	16	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10751	17	1	AMACUZAC	2022-11-11 12:31:55	\N
10752	17	2	ATLATLAHUCAN	2022-11-11 12:31:55	\N
10753	17	3	AXOCHIAPAN	2022-11-11 12:31:55	\N
10754	17	4	AYALA	2022-11-11 12:31:55	\N
10755	17	5	COATLAN DEL RIO	2022-11-11 12:31:55	\N
10756	17	6	CUAUTLA	2022-11-11 12:31:55	\N
10757	17	7	CUERNAVACA	2022-11-11 12:31:55	\N
10758	17	8	EMILIANO ZAPATA	2022-11-11 12:31:55	\N
10759	17	9	HUITZILAC	2022-11-11 12:31:55	\N
10760	17	10	JANTETELCO	2022-11-11 12:31:55	\N
10761	17	11	JIUTEPEC	2022-11-11 12:31:55	\N
10762	17	12	JOJUTLA	2022-11-11 12:31:55	\N
10763	17	13	JONACATEPEC	2022-11-11 12:31:55	\N
10764	17	14	MAZATEPEC	2022-11-11 12:31:55	\N
10765	17	15	MIACATLAN	2022-11-11 12:31:55	\N
10766	17	16	OCUITUCO	2022-11-11 12:31:55	\N
10767	17	17	PUENTE DE IXTLA	2022-11-11 12:31:55	\N
10768	17	18	TEMIXCO	2022-11-11 12:31:55	\N
10769	17	19	TEPALCINGO	2022-11-11 12:31:55	\N
10770	17	20	TEPOZTLAN	2022-11-11 12:31:55	\N
10771	17	21	TETECALA	2022-11-11 12:31:55	\N
10772	17	22	TETELA DEL VOLCAN	2022-11-11 12:31:55	\N
10773	17	23	TLALNEPANTLA	2022-11-11 12:31:55	\N
10774	17	24	TLALTIZAPAN	2022-11-11 12:31:55	\N
10775	17	25	TLAQUILTENANGO	2022-11-11 12:31:55	\N
10776	17	26	TLAYACAPAN	2022-11-11 12:31:55	\N
10777	17	27	TOTOLAPAN	2022-11-11 12:31:55	\N
10778	17	28	XOCHITEPEC	2022-11-11 12:31:55	\N
10779	17	29	YAUTEPEC	2022-11-11 12:31:55	\N
10780	17	30	YECAPIXTLA	2022-11-11 12:31:55	\N
10781	17	31	ZACATEPEC	2022-11-11 12:31:55	\N
10782	17	32	ZACUALPAN	2022-11-11 12:31:55	\N
10783	17	33	ZTEMOAC	2022-11-11 12:31:55	\N
10784	17	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10785	18	1	ACAPONETA	2022-11-11 12:31:55	\N
10786	18	2	AHUACATLAN	2022-11-11 12:31:55	\N
10787	18	3	AMATLAN DE CAÑAS	2022-11-11 12:31:55	\N
10788	18	4	COMPOSTELA	2022-11-11 12:31:55	\N
10789	18	5	HUAJICORI	2022-11-11 12:31:55	\N
10790	18	6	IXTLAN DEL RIO	2022-11-11 12:31:55	\N
10791	18	7	JALA	2022-11-11 12:31:55	\N
10792	18	8	XALISCO	2022-11-11 12:31:55	\N
10793	18	9	NAYAR, EL	2022-11-11 12:31:55	\N
10794	18	10	ROSAMORADA	2022-11-11 12:31:55	\N
10795	18	11	RUIZ	2022-11-11 12:31:55	\N
10796	18	12	SAN BLAS	2022-11-11 12:31:55	\N
10797	18	13	SAN PEDRO LAGUNILLAS	2022-11-11 12:31:55	\N
10798	18	14	SANTA MARIA DEL ORO	2022-11-11 12:31:55	\N
10799	18	15	SANTIAGO IXCUINTLA	2022-11-11 12:31:55	\N
10800	18	16	TECUALA	2022-11-11 12:31:55	\N
10801	18	17	TEPIC	2022-11-11 12:31:55	\N
10802	18	18	TUXPAN	2022-11-11 12:31:55	\N
10803	18	19	YESCA, LA	2022-11-11 12:31:55	\N
10804	18	20	BAHIA DE BANDERAS	2022-11-11 12:31:55	\N
10805	18	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10806	19	1	ABASOLO	2022-11-11 12:31:55	\N
10807	19	2	AGUALEGUAS	2022-11-11 12:31:55	\N
10808	19	3	ALDAMAS, LOS	2022-11-11 12:31:55	\N
10809	19	4	ALLENDE	2022-11-11 12:31:55	\N
10810	19	5	ANAHUAC	2022-11-11 12:31:55	\N
10811	19	6	APODACA	2022-11-11 12:31:55	\N
10812	19	7	ARAMBERRI	2022-11-11 12:31:55	\N
10813	19	8	BUSTAMANTE	2022-11-11 12:31:55	\N
10814	19	9	CADEREYTA JIMENEZ	2022-11-11 12:31:55	\N
10815	19	10	CARMEN	2022-11-11 12:31:55	\N
10816	19	11	CERRALVO	2022-11-11 12:31:55	\N
10817	19	12	CIENEGA DE FLORES	2022-11-11 12:31:55	\N
10818	19	13	CHINA	2022-11-11 12:31:55	\N
10819	19	14	DOCTOR ARROYO	2022-11-11 12:31:55	\N
10820	19	15	DOCTOR COSS	2022-11-11 12:31:55	\N
10821	19	16	DOCTOR GONZALEZ	2022-11-11 12:31:55	\N
10822	19	17	GALEANA	2022-11-11 12:31:55	\N
10823	19	18	GARCIA	2022-11-11 12:31:55	\N
10824	19	19	SAN PEDRO GARZA GARCIA	2022-11-11 12:31:55	\N
10825	19	20	GENERAL BRAVO	2022-11-11 12:31:55	\N
10826	19	21	GENERAL ESCOBEDO	2022-11-11 12:31:55	\N
10827	19	22	GENERAL TERAN	2022-11-11 12:31:55	\N
10828	19	23	GENERAL TREVIÑO	2022-11-11 12:31:55	\N
10829	19	24	GENERAL ZARAGOZA	2022-11-11 12:31:55	\N
10830	19	25	GENERAL ZUAZUA	2022-11-11 12:31:55	\N
10831	19	26	GUADALUPE	2022-11-11 12:31:55	\N
10832	19	27	HERRERAS, LOS	2022-11-11 12:31:55	\N
10833	19	28	HIGUERAS	2022-11-11 12:31:55	\N
10834	19	29	HUALAHUISES	2022-11-11 12:31:55	\N
10835	19	30	ITURBIDE	2022-11-11 12:31:55	\N
10836	19	31	JUAREZ	2022-11-11 12:31:55	\N
10837	19	32	LAMPAZOS DE NARANJO	2022-11-11 12:31:55	\N
10838	19	33	LINARES	2022-11-11 12:31:55	\N
10839	19	34	MARIN	2022-11-11 12:31:55	\N
10840	19	35	MELCHOR OCAMPO	2022-11-11 12:31:55	\N
10841	19	36	MIER Y NORIEGA	2022-11-11 12:31:55	\N
10842	19	37	MINA	2022-11-11 12:31:55	\N
10843	19	38	MONTEMORELOS	2022-11-11 12:31:55	\N
10844	19	39	MONTERREY	2022-11-11 12:31:55	\N
10845	19	40	PARAS	2022-11-11 12:31:55	\N
10846	19	41	PESQUERIA	2022-11-11 12:31:55	\N
10847	19	42	RAMONES, LOS	2022-11-11 12:31:55	\N
10848	19	43	RAYONES	2022-11-11 12:31:55	\N
10849	19	44	SABINAS HIDALGO	2022-11-11 12:31:55	\N
10850	19	45	SALINAS VICTORIA	2022-11-11 12:31:55	\N
10851	19	46	SAN NICOLAS DE LOS GARZA	2022-11-11 12:31:55	\N
10852	19	47	HIDALGO	2022-11-11 12:31:55	\N
10853	19	48	SANTA CATARINA	2022-11-11 12:31:55	\N
10854	19	49	SANTIAGO	2022-11-11 12:31:55	\N
10855	19	50	VALLECILLO	2022-11-11 12:31:55	\N
10856	19	51	VILLALDAMA	2022-11-11 12:31:55	\N
10857	19	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
10858	20	1	ABEJONES	2022-11-11 12:31:55	\N
10859	20	2	ACATLAN DE PEREZ FIGUEROA	2022-11-11 12:31:55	\N
10860	20	3	ASUNCION CACALOTEPEC	2022-11-11 12:31:55	\N
10861	20	4	ASUNCION CUYOTEPEJI	2022-11-11 12:31:55	\N
10862	20	5	ASUNCION IXTALTEPEC	2022-11-11 12:31:55	\N
10863	20	6	ASUNCION NOCHIXTLAN	2022-11-11 12:31:55	\N
10864	20	7	ASUNCION OCOTLAN	2022-11-11 12:31:55	\N
10865	20	8	ASUNCION TLACOLULITA	2022-11-11 12:31:55	\N
10866	20	9	AYOTZINTEPEC	2022-11-11 12:31:55	\N
10867	20	10	BARRIO DE LA SOLEDAD, EL	2022-11-11 12:31:55	\N
10868	20	11	CALIHUALA	2022-11-11 12:31:55	\N
10869	20	12	CANDELARIA LOXICHA	2022-11-11 12:31:55	\N
10870	20	13	CIENEGA DE ZIMATLAN (LA CIENEG	2022-11-11 12:31:55	\N
10871	20	14	CIUDAD IXTEPEC	2022-11-11 12:31:55	\N
10872	20	15	COATECAS ALTAS	2022-11-11 12:31:55	\N
10873	20	16	COICOYAN DE LAS FLORES	2022-11-11 12:31:55	\N
10874	20	17	COMPAÑIA, LA	2022-11-11 12:31:55	\N
10875	20	18	CONCEPCION BUENAVISTA	2022-11-11 12:31:55	\N
10876	20	19	CONCEPCION PAPALO	2022-11-11 12:31:55	\N
10877	20	20	CONSTANCIA DEL ROSARIO	2022-11-11 12:31:55	\N
10878	20	21	COSOLAPA	2022-11-11 12:31:55	\N
10879	20	22	COSOLTEPEC	2022-11-11 12:31:55	\N
10880	20	23	CUILAPAM DE GUERRERO	2022-11-11 12:31:55	\N
10881	20	24	CUYAMECALCO VILLA DE ZARAGOZA	2022-11-11 12:31:55	\N
10882	20	25	CHAHUITES	2022-11-11 12:31:55	\N
10883	20	26	CHALCATONGO DE HIDALGO	2022-11-11 12:31:55	\N
10884	20	27	SAN JUAN CHIQUIHUITLAN	2022-11-11 12:31:55	\N
10885	20	28	EJUTLA DE CRESPO	2022-11-11 12:31:55	\N
10886	20	29	ELOXOCHITLAN DE FLORES MAGON	2022-11-11 12:31:55	\N
10887	20	30	ESPINAL, EL	2022-11-11 12:31:55	\N
10888	20	31	TAMAZULAPAM DEL ESPIRITU SANTO	2022-11-11 12:31:55	\N
10889	20	32	FRESNILLO DE TRUJANO	2022-11-11 12:31:55	\N
10890	20	33	GUADALUPE ETLA	2022-11-11 12:31:55	\N
10891	20	34	GUADALUPE RAMIREZ	2022-11-11 12:31:55	\N
10892	20	35	GUELATAO DE JUAREZ	2022-11-11 12:31:55	\N
10893	20	36	GUEVEA DE HUMBOLDT	2022-11-11 12:31:55	\N
10894	20	37	MESONES HIDALGO	2022-11-11 12:31:55	\N
10895	20	38	VILLA HIDALGO	2022-11-11 12:31:55	\N
10896	20	39	HUAJUAPAM DE LEON	2022-11-11 12:31:55	\N
10897	20	40	HUAUTEPEC	2022-11-11 12:31:55	\N
10898	20	41	HUAUTLA DE JIMENEZ	2022-11-11 12:31:55	\N
10899	20	42	IXTLAN DE JUAREZ	2022-11-11 12:31:55	\N
10900	20	43	JUCHITAN DE ZARAGOZA	2022-11-11 12:31:55	\N
10901	20	44	LOMA BONITA	2022-11-11 12:31:55	\N
10902	20	45	MAGDALENA APASCO	2022-11-11 12:31:55	\N
10903	20	46	MAGDALENA JALTEPEC	2022-11-11 12:31:55	\N
10904	20	47	SANTA MAGDALENA JICOTLAN	2022-11-11 12:31:55	\N
10905	20	48	MAGDALENA MIXTEPEC	2022-11-11 12:31:55	\N
10906	20	49	MAGDALENA OCOTLAN	2022-11-11 12:31:55	\N
10907	20	50	MAGDALENA PEÑASCO	2022-11-11 12:31:55	\N
10908	20	51	MAGDALENA TEITIPAC	2022-11-11 12:31:55	\N
10909	20	52	MAGDALENA TEQUISISTLAN	2022-11-11 12:31:55	\N
10910	20	53	MAGDALENA TLACOTEPEC	2022-11-11 12:31:55	\N
10911	20	54	MAGDALENA ZAHUATLAN	2022-11-11 12:31:55	\N
10912	20	55	MARISCALA DE JUAREZ	2022-11-11 12:31:55	\N
10913	20	56	MARTIRES DE TACUBAYA	2022-11-11 12:31:55	\N
10914	20	57	MATIAS ROMERO	2022-11-11 12:31:55	\N
10915	20	58	MAZATLAN VILLA DE FLORES	2022-11-11 12:31:55	\N
10916	20	59	MIAHUATLAN DE PORFIRIO DIAZ	2022-11-11 12:31:55	\N
10917	20	60	MIXISTLAN DE LA REFORMA	2022-11-11 12:31:55	\N
10918	20	61	MONJAS	2022-11-11 12:31:55	\N
10919	20	62	NATIVIDAD	2022-11-11 12:31:55	\N
10920	20	63	NAZARENO ETLA	2022-11-11 12:31:55	\N
10921	20	64	NEJAPA DE MADERO	2022-11-11 12:31:55	\N
10922	20	65	IXPANTEPEC NIEVES	2022-11-11 12:31:55	\N
10923	20	66	SANTIAGO NILTEPEC	2022-11-11 12:31:55	\N
10924	20	67	OAXACA DE JUAREZ	2022-11-11 12:31:55	\N
10925	20	68	OCOTLAN DE MORELOS	2022-11-11 12:31:55	\N
10926	20	69	PE, LA	2022-11-11 12:31:55	\N
10927	20	70	PINOTEPA DE DON LUIS	2022-11-11 12:31:55	\N
10928	20	71	PLUMA HIDALGO	2022-11-11 12:31:55	\N
10929	20	72	SAN JOSE DEL PROGRESO	2022-11-11 12:31:55	\N
10930	20	73	PUTLA VILLA DE GUERRERO	2022-11-11 12:31:55	\N
10931	20	74	SANTA CATARINA QUIOQUITANI	2022-11-11 12:31:55	\N
10932	20	75	REFORMA DE PINEDA	2022-11-11 12:31:55	\N
10933	20	76	REFORMA, LA	2022-11-11 12:31:55	\N
10934	20	77	REYES ETLA	2022-11-11 12:31:55	\N
10935	20	78	ROJAS DE CUAUHTEMOC	2022-11-11 12:31:55	\N
10936	20	79	SALINA CRUZ	2022-11-11 12:31:55	\N
10937	20	80	SAN AGUSTIN AMATENGO	2022-11-11 12:31:55	\N
10938	20	81	SAN AGUSTIN ATENANGO	2022-11-11 12:31:55	\N
10939	20	82	SAN AGUSTIN CHAYUCO	2022-11-11 12:31:55	\N
10940	20	83	SAN AGUSTIN DE LAS JUNTAS	2022-11-11 12:31:55	\N
10941	20	84	SAN AGUSTIN ETLA	2022-11-11 12:31:55	\N
10942	20	85	SAN AGUSTIN LOXICHA	2022-11-11 12:31:55	\N
10943	20	86	SAN AGUSTIN TLACOTEPEC	2022-11-11 12:31:55	\N
10944	20	87	SAN AGUSTIN YATARENI	2022-11-11 12:31:55	\N
10945	20	88	SAN ANDRES CABECERA NUEVA	2022-11-11 12:31:55	\N
10946	20	89	SAN ANDRES DINICUITI	2022-11-11 12:31:55	\N
10947	20	90	SAN ANDRES HUAXPALTEPEC	2022-11-11 12:31:55	\N
10948	20	91	SAN ANDRES HUAYAPAM	2022-11-11 12:31:55	\N
10949	20	92	SAN ANDRES IXTLAHUACA	2022-11-11 12:31:55	\N
10950	20	93	SAN ANDRES LAGUNAS	2022-11-11 12:31:55	\N
10951	20	94	SAN ANDRES NUXIÑO	2022-11-11 12:31:55	\N
10952	20	95	SAN ANDRES PAXTLAN	2022-11-11 12:31:55	\N
10953	20	96	SAN ANDRES SINAXTLA	2022-11-11 12:31:55	\N
10954	20	97	SAN ANDRES SOLAGA	2022-11-11 12:31:55	\N
10955	20	98	SAN ANDRES TEOTILALPAM	2022-11-11 12:31:55	\N
10956	20	99	SAN ANDRES TEPETLAPA	2022-11-11 12:31:55	\N
10957	20	100	SAN ANDRES YAA	2022-11-11 12:31:55	\N
10958	20	101	SAN ANDRES ZABACHE	2022-11-11 12:31:55	\N
10959	20	102	SAN ANDRES ZAUTLA	2022-11-11 12:31:55	\N
10960	20	103	SAN ANTONINO CASTILLO VELASCO	2022-11-11 12:31:55	\N
10961	20	104	SAN ANTONINO EL ALTO	2022-11-11 12:31:55	\N
10962	20	105	SAN ANTONINO MONTE VERDE	2022-11-11 12:31:55	\N
10963	20	106	SAN ANTONIO ACUTLA	2022-11-11 12:31:55	\N
10964	20	107	SAN ANTONIO DE LA CAL	2022-11-11 12:31:55	\N
10965	20	108	SAN ANTONIO HUITEPEC	2022-11-11 12:31:55	\N
10966	20	109	SAN ANTONIO NANAHUATIPAM	2022-11-11 12:31:55	\N
10967	20	110	SAN ANTONIO SINICAHUA	2022-11-11 12:31:55	\N
10968	20	111	SAN ANTONIO TEPETLAPA	2022-11-11 12:31:55	\N
10969	20	112	SAN BALTAZAR CHICHICAPAM	2022-11-11 12:31:55	\N
10970	20	113	SAN BALTAZAR LOXICHA	2022-11-11 12:31:55	\N
10971	20	114	SAN BALTAZAR YATZACHI EL BAJO	2022-11-11 12:31:55	\N
10972	20	115	SAN BARTOLO COYOTEPEC	2022-11-11 12:31:55	\N
10973	20	116	SAN BARTOLOME AYAUTLA	2022-11-11 12:31:55	\N
10974	20	117	SAN BARTOLOME LOXICHA	2022-11-11 12:31:55	\N
10975	20	118	SAN BARTOLOME QUIALANA	2022-11-11 12:31:55	\N
10976	20	119	SAN BARTOLOME YUCUA¥E	2022-11-11 12:31:55	\N
10977	20	120	SAN BARTOLOME ZOOGOCHO	2022-11-11 12:31:55	\N
10978	20	121	SAN BARTOLO SOYALTEPEC	2022-11-11 12:31:55	\N
10979	20	122	SAN BARTOLO YAUTEPEC	2022-11-11 12:31:55	\N
10980	20	123	SAN BERNARDO MIXTEPEC	2022-11-11 12:31:55	\N
10981	20	124	SAN BLAS ATEMPA	2022-11-11 12:31:55	\N
10982	20	125	SAN CARLOS YAUTEPEC	2022-11-11 12:31:55	\N
10983	20	126	SAN CRISTOBAL AMATLAN	2022-11-11 12:31:55	\N
10984	20	127	SAN CRISTOBAL AMOLTEPEC	2022-11-11 12:31:55	\N
10985	20	128	SAN CRISTOBAL LACHIRIOAG	2022-11-11 12:31:55	\N
10986	20	129	SAN CRISTOBAL SUCHIXTLAHUACA	2022-11-11 12:31:55	\N
10987	20	130	SAN DIONISIO DEL MAR	2022-11-11 12:31:55	\N
10988	20	131	SAN DIONISIO OCOTEPEC	2022-11-11 12:31:55	\N
10989	20	132	SAN DIONISIO OCOTLAN	2022-11-11 12:31:55	\N
10990	20	133	SAN ESTEBAN ATATLAHUCA	2022-11-11 12:31:55	\N
10991	20	134	SAN FELIPE JALAPA DE DIAZ	2022-11-11 12:31:55	\N
10992	20	135	SAN FELIPE TEJALAPAM	2022-11-11 12:31:55	\N
10993	20	136	SAN FELIPE USILA	2022-11-11 12:31:55	\N
10994	20	137	SAN FRANCISCO CAHUACUA	2022-11-11 12:31:55	\N
10995	20	138	SAN FRANCISCO CAJONOS	2022-11-11 12:31:55	\N
10996	20	139	SAN FRANCISCO CHAPULAPA	2022-11-11 12:31:55	\N
10997	20	140	SAN FRANCISCO CHINDUA	2022-11-11 12:31:55	\N
10998	20	141	SAN FRANCISCO DEL MAR	2022-11-11 12:31:55	\N
10999	20	142	SAN FRANCISCO HUEHUETLAN	2022-11-11 12:31:55	\N
11000	20	143	SAN FRANCISCO IXHUATAN	2022-11-11 12:31:55	\N
11001	20	144	SAN FRANCISCO JALTEPETONGO	2022-11-11 12:31:55	\N
11002	20	145	SAN FRANCISCO LACHIGOLO	2022-11-11 12:31:55	\N
11003	20	146	SAN FRANCISCO LOGUECHE	2022-11-11 12:31:55	\N
11004	20	147	SAN FRANCISCO NUXAÑO	2022-11-11 12:31:55	\N
11005	20	148	SAN FRANCISCO OZOLOTEPEC	2022-11-11 12:31:55	\N
11006	20	149	SAN FRANCISCO SOLA	2022-11-11 12:31:55	\N
11007	20	150	SAN FRANCISCO TELIXTLAHUACA	2022-11-11 12:31:55	\N
11008	20	151	SAN FRANCISCO TEOPAN	2022-11-11 12:31:55	\N
11009	20	152	SAN FRANCISCO TLAPANCINGO	2022-11-11 12:31:55	\N
11010	20	153	SAN GABRIEL MIXTEPEC	2022-11-11 12:31:55	\N
11011	20	154	SAN ILDEFONSO AMATLAN	2022-11-11 12:31:55	\N
11012	20	155	SAN ILDEFONSO SOLA	2022-11-11 12:31:55	\N
11013	20	156	SAN ILDEFONSO VILLA ALTA	2022-11-11 12:31:55	\N
11014	20	157	SAN JACINTO AMILPAS	2022-11-11 12:31:55	\N
11015	20	158	SAN JACINTO TLACOTEPEC	2022-11-11 12:31:55	\N
11016	20	159	SAN JERONIMO COATLAN	2022-11-11 12:31:55	\N
11017	20	160	SAN JERONIMO SILACAYOAPILLA	2022-11-11 12:31:55	\N
11018	20	161	SAN JERONIMO SOSOLA	2022-11-11 12:31:55	\N
11019	20	162	SAN JERONIMO TAVICHE	2022-11-11 12:31:55	\N
11020	20	163	SAN JERONIMO TECOATL	2022-11-11 12:31:55	\N
11021	20	164	SAN JORGE NUCHITA	2022-11-11 12:31:55	\N
11022	20	165	SAN JOSE AYUQUILA	2022-11-11 12:31:55	\N
11023	20	166	SAN JOSE CHILTEPEC	2022-11-11 12:31:55	\N
11024	20	167	SAN JOSE DEL PEÑASCO	2022-11-11 12:31:55	\N
11025	20	168	SAN JOSE ESTANCIA GRANDE	2022-11-11 12:31:55	\N
11026	20	169	SAN JOSE INDEPENDENCIA	2022-11-11 12:31:55	\N
11027	20	170	SAN JOSE LACHIGUIRI	2022-11-11 12:31:55	\N
11028	20	171	SAN JOSE TENANGO	2022-11-11 12:31:55	\N
11029	20	172	SAN JUAN ACHIUTLA	2022-11-11 12:31:55	\N
11030	20	173	SAN JUAN ATEPEC	2022-11-11 12:31:55	\N
11031	20	174	ANIMAS TRUJANO	2022-11-11 12:31:55	\N
11032	20	175	SAN JUAN BAUTISTA ATATLAHUCA	2022-11-11 12:31:55	\N
11033	20	176	SAN JUAN BAUTISTA COIXTLAHUACA	2022-11-11 12:31:55	\N
11034	20	177	SAN JUAN BAUTISTA CUICATLAN	2022-11-11 12:31:55	\N
11035	20	178	SAN JUAN BAUTISTA GUELACHE	2022-11-11 12:31:55	\N
11036	20	179	SAN JUAN BAUTISTA JAYACATLAN	2022-11-11 12:31:55	\N
11037	20	180	SAN JUAN BAUTISTA LO DE SOTO	2022-11-11 12:31:55	\N
11038	20	181	SAN JUAN BAUTISTA SUCHITEPEC	2022-11-11 12:31:55	\N
11039	20	182	SAN JUAN BAUTISTA TLACOATZINTE	2022-11-11 12:31:55	\N
11040	20	183	SAN JUAN BAUTISTA TLACHICHILCO	2022-11-11 12:31:55	\N
11041	20	184	SAN JUAN BAUTISTA TUXTEPEC	2022-11-11 12:31:55	\N
11042	20	185	SAN JUAN CACAHUATEPEC	2022-11-11 12:31:55	\N
11043	20	186	SAN JUAN CIENEGUILLA	2022-11-11 12:31:55	\N
11044	20	187	SAN JUAN COATZOSPAM	2022-11-11 12:31:55	\N
11045	20	188	SAN JUAN COLORADO	2022-11-11 12:31:55	\N
11046	20	189	SAN JUAN COMALTEPEC	2022-11-11 12:31:55	\N
11047	20	190	SAN JUAN COTZOCON	2022-11-11 12:31:55	\N
11048	20	191	SAN JUAN CHICOMEZUCHIL	2022-11-11 12:31:55	\N
11049	20	192	SAN JUAN CHILATECA	2022-11-11 12:31:55	\N
11050	20	193	SAN JUAN DEL ESTADO	2022-11-11 12:31:55	\N
11051	20	194	SAN JUAN DEL RIO	2022-11-11 12:31:55	\N
11052	20	195	SAN JUAN DIUXI	2022-11-11 12:31:55	\N
11053	20	196	SAN JUAN EVANGELISTA ANALCO	2022-11-11 12:31:55	\N
11054	20	197	SAN JUAN GUELAVIA	2022-11-11 12:31:55	\N
11055	20	198	SAN JUAN GUICHICOVI	2022-11-11 12:31:55	\N
11056	20	199	SAN JUAN IHUALTEPEC	2022-11-11 12:31:55	\N
11057	20	200	SAN JUAN JUQUILA MIXES	2022-11-11 12:31:55	\N
11058	20	201	SAN JUAN JUQUILA VIJANOS	2022-11-11 12:31:55	\N
11059	20	202	SAN JUAN LACHAO	2022-11-11 12:31:55	\N
11060	20	203	SAN JUAN LACHIGALLA	2022-11-11 12:31:55	\N
11061	20	204	SAN JUAN LAJARCIA	2022-11-11 12:31:55	\N
11062	20	205	SAN JUAN LALANA	2022-11-11 12:31:55	\N
11063	20	206	SAN JUAN DE LOS CUES	2022-11-11 12:31:55	\N
11064	20	207	SAN JUAN MAZATLAN	2022-11-11 12:31:55	\N
11065	20	208	SAN JUAN MIXTEPEC -DISTR. 08-	2022-11-11 12:31:55	\N
11066	20	209	SAN JUAN MIXTEPEC - DISTR. 26	2022-11-11 12:31:55	\N
11067	20	210	SAN JUAN ÑUMI	2022-11-11 12:31:55	\N
11068	20	211	SAN JUAN OZOLOTEPEC	2022-11-11 12:31:55	\N
11069	20	212	SAN JUAN PETLAPA	2022-11-11 12:31:55	\N
11070	20	213	SAN JUAN QUIAHIJE	2022-11-11 12:31:55	\N
11071	20	214	SAN JUAN QUIOTEPEC	2022-11-11 12:31:55	\N
11072	20	215	SAN JUAN SAYULTEPEC	2022-11-11 12:31:55	\N
11073	20	216	SAN JUAN TABAA	2022-11-11 12:31:55	\N
11074	20	217	SAN JUAN TAMAZOLA	2022-11-11 12:31:55	\N
11075	20	218	SAN JUAN TEITA	2022-11-11 12:31:55	\N
11076	20	219	SAN JUAN TEITIPAC	2022-11-11 12:31:55	\N
11077	20	220	SAN JUAN TEPEUXILA	2022-11-11 12:31:55	\N
11078	20	221	SAN JUAN TEPOSCOLULA	2022-11-11 12:31:55	\N
11079	20	222	SAN JUAN YAE	2022-11-11 12:31:55	\N
11080	20	223	SAN JUAN YATZONA	2022-11-11 12:31:55	\N
11081	20	224	SAN JUAN YUCUITA	2022-11-11 12:31:55	\N
11082	20	225	SAN LORENZO	2022-11-11 12:31:55	\N
11083	20	226	SAN LORENZO ALBARRADAS	2022-11-11 12:31:55	\N
11084	20	227	SAN LORENZO CACAOTEPEC	2022-11-11 12:31:55	\N
11085	20	228	SAN LORENZO CUAUNECUILTITLA	2022-11-11 12:31:55	\N
11086	20	229	SAN LORENZO TEXMELUCAN	2022-11-11 12:31:55	\N
11087	20	230	SAN LORENZO VICTORIA	2022-11-11 12:31:55	\N
11088	20	231	SAN LUCAS CAMOTLAN	2022-11-11 12:31:55	\N
11089	20	232	SAN LUCAS OJITLAN	2022-11-11 12:31:55	\N
11090	20	233	SAN LUCAS QUIAVINI	2022-11-11 12:31:55	\N
11091	20	234	SAN LUCAS ZOQUIAPAM	2022-11-11 12:31:55	\N
11092	20	235	SAN LUIS AMATLAN	2022-11-11 12:31:55	\N
11093	20	236	SAN MARCIAL OZOLOTEPEC	2022-11-11 12:31:55	\N
11094	20	237	SAN MARCOS ARTEAGA	2022-11-11 12:31:55	\N
11095	20	238	SAN MARTIN DE LOS CANSECOS	2022-11-11 12:31:55	\N
11096	20	239	SAN MARTIN HUAMELULPAM	2022-11-11 12:31:55	\N
11097	20	240	SAN MARTIN ITUNYOSO	2022-11-11 12:31:55	\N
11098	20	241	SAN MARTIN LACHILA	2022-11-11 12:31:55	\N
11099	20	242	SAN MARTIN PERAS	2022-11-11 12:31:55	\N
11100	20	243	SAN MARTIN TILCAJETE	2022-11-11 12:31:55	\N
11101	20	244	SAN MARTIN TOXPALAN	2022-11-11 12:31:55	\N
11102	20	245	SAN MARTIN ZACATEPEC	2022-11-11 12:31:55	\N
11103	20	246	SAN MATEO CAJONOS	2022-11-11 12:31:55	\N
11104	20	247	CAPULALPAM DE MENDEZ	2022-11-11 12:31:55	\N
11105	20	248	SAN MATEO DEL MAR	2022-11-11 12:31:55	\N
11106	20	249	SAN MATEO YOLOXOCHITLAN	2022-11-11 12:31:55	\N
11107	20	250	SAN MATEO ETLATONGO	2022-11-11 12:31:55	\N
11108	20	251	SAN MATEO NEJAPAM	2022-11-11 12:31:55	\N
11109	20	252	SAN MATEO PE¥ASCO	2022-11-11 12:31:55	\N
11110	20	253	SAN MATEO PI¥AS	2022-11-11 12:31:55	\N
11111	20	254	SAN MATEO RIO HONDO	2022-11-11 12:31:55	\N
11112	20	255	SAN MATEO SINDIHUI	2022-11-11 12:31:55	\N
11113	20	256	SAN MATEO TLAPILTEPEC	2022-11-11 12:31:55	\N
11114	20	257	SAN MELCHOR BETAZA	2022-11-11 12:31:55	\N
11115	20	258	SAN MIGUEL ACHIUTLA	2022-11-11 12:31:55	\N
11116	20	259	SAN MIGUEL AHUEHUETITLAN	2022-11-11 12:31:55	\N
11117	20	260	SAN MIGUEL ALOAPAM	2022-11-11 12:31:55	\N
11118	20	261	SAN MIGUEL AMATITLAN	2022-11-11 12:31:55	\N
11119	20	262	SAN MIGUEL AMATLAN	2022-11-11 12:31:55	\N
11120	20	263	SAN MIGUEL COATLAN	2022-11-11 12:31:55	\N
11121	20	264	SAN MIGUEL CHICAHUA	2022-11-11 12:31:55	\N
11122	20	265	SAN MIGUEL CHIMALAPA	2022-11-11 12:31:55	\N
11123	20	266	SAN MIGUEL DEL PUERTO	2022-11-11 12:31:55	\N
11124	20	267	SAN MIGUEL DEL RIO	2022-11-11 12:31:55	\N
11125	20	268	SAN MIGUEL EJUTLA	2022-11-11 12:31:55	\N
11126	20	269	SAN MIGUEL EL GRANDE	2022-11-11 12:31:55	\N
11127	20	270	SAN MIGUEL HUAUTLA	2022-11-11 12:31:55	\N
11128	20	271	SAN MIGUEL MIXTEPEC	2022-11-11 12:31:55	\N
11129	20	272	SAN MIGUEL PANIXTLAHUACA	2022-11-11 12:31:55	\N
11130	20	273	SAN MIGUEL PERAS	2022-11-11 12:31:55	\N
11131	20	274	SAN MIGUEL PIEDRAS	2022-11-11 12:31:55	\N
11132	20	275	SAN MIGUEL QUETZALTEPEC	2022-11-11 12:31:55	\N
11133	20	276	SAN MIGUEL SANTA FLOR	2022-11-11 12:31:55	\N
11134	20	277	VILLA SOLA DE VEGA	2022-11-11 12:31:55	\N
11135	20	278	NUEVO SOYALTEPEC	2022-11-11 12:31:55	\N
11136	20	279	SAN MIGUEL SUCHIXTEPEC	2022-11-11 12:31:55	\N
11137	20	280	SAN MIGUEL TALEA DE CASTRO	2022-11-11 12:31:55	\N
11138	20	281	SAN MIGUEL TECOMATLAN	2022-11-11 12:31:55	\N
11139	20	282	SAN MIGUEL TENANGO	2022-11-11 12:31:55	\N
11140	20	283	SAN MIGUEL TEQUIXTEPEC	2022-11-11 12:31:55	\N
11141	20	284	SAN MIGUEL TILQUIAPAM	2022-11-11 12:31:55	\N
11142	20	285	SAN MIGUEL TLACAMAMA	2022-11-11 12:31:55	\N
11143	20	286	SAN MIGUEL TLACOTEPEC	2022-11-11 12:31:55	\N
11144	20	287	SAN MIGUEL TULANCINGO	2022-11-11 12:31:55	\N
11145	20	288	SAN MIGUEL YOTAO	2022-11-11 12:31:55	\N
11146	20	289	SAN NICOLAS	2022-11-11 12:31:55	\N
11147	20	290	SAN NICOLAS HIDALGO	2022-11-11 12:31:55	\N
11148	20	291	SAN PABLO COATLAN	2022-11-11 12:31:55	\N
11149	20	292	SAN PABLO CUATRO VENADOS	2022-11-11 12:31:55	\N
11150	20	293	SAN PABLO ETLA	2022-11-11 12:31:55	\N
11151	20	294	SAN PABLO HUITZO	2022-11-11 12:31:55	\N
11152	20	295	SAN PABLO HUIXTEPEC	2022-11-11 12:31:55	\N
11153	20	296	SAN PABLO MACUILTIANGUIS	2022-11-11 12:31:55	\N
11154	20	297	SAN PABLO TIJALTEPEC	2022-11-11 12:31:55	\N
11155	20	298	SAN PABLO VILLA DE MITLA	2022-11-11 12:31:55	\N
11156	20	299	SAN PABLO YAGANIZA	2022-11-11 12:31:55	\N
11157	20	300	SAN PEDRO AMUZGOS	2022-11-11 12:31:55	\N
11158	20	301	SAN PEDRO APOSTOL	2022-11-11 12:31:55	\N
11159	20	302	SAN PEDRO ATOYAC	2022-11-11 12:31:55	\N
11160	20	303	SAN PEDRO CAJONOS	2022-11-11 12:31:55	\N
11161	20	304	SAN PEDRO CANTAROS COXCALTEPEC	2022-11-11 12:31:55	\N
11162	20	305	SAN PEDRO COMITANCILLO	2022-11-11 12:31:55	\N
11163	20	306	SAN PEDRO EL ALTO	2022-11-11 12:31:55	\N
11164	20	307	SAN PEDRO HUAMELULA	2022-11-11 12:31:55	\N
11165	20	308	SAN PEDRO HUILOTEPEC	2022-11-11 12:31:55	\N
11166	20	309	SAN PEDRO IXCATLAN	2022-11-11 12:31:55	\N
11167	20	310	SAN PEDRO IXTLAHUACA	2022-11-11 12:31:55	\N
11168	20	311	SAN PEDRO JALTEPETONGO	2022-11-11 12:31:55	\N
11169	20	312	SAN PEDRO JICAYAN	2022-11-11 12:31:55	\N
11170	20	313	SAN PEDRO JOCOTIPAC	2022-11-11 12:31:55	\N
11171	20	314	SAN PEDRO JUCHATENGO	2022-11-11 12:31:55	\N
11172	20	315	SAN PEDRO MARTIR	2022-11-11 12:31:55	\N
11173	20	316	SAN PEDRO MARTIR QUIECHAPA	2022-11-11 12:31:55	\N
11174	20	317	SAN PEDRO MARTIR YUCUXACO	2022-11-11 12:31:55	\N
11175	20	318	SAN PEDRO MIXTEPEC - DISTR. 22	2022-11-11 12:31:55	\N
11176	20	319	SAN PEDRO MIXTEPEC - DISTR. 26	2022-11-11 12:31:55	\N
11177	20	320	SAN PEDRO MOLINOS	2022-11-11 12:31:55	\N
11178	20	321	SAN PEDRO NOPALA	2022-11-11 12:31:55	\N
11179	20	322	SAN PEDRO OCOPETATILLO	2022-11-11 12:31:55	\N
11180	20	323	SAN PEDRO OCOTEPEC	2022-11-11 12:31:55	\N
11181	20	324	SAN PEDRO POCHUTLA	2022-11-11 12:31:55	\N
11182	20	325	SAN PEDRO QUIATONI	2022-11-11 12:31:55	\N
11183	20	326	SAN PEDRO SOCHIAPAM	2022-11-11 12:31:55	\N
11184	20	327	SAN PEDRO TAPANATEPEC	2022-11-11 12:31:55	\N
11185	20	328	SAN PEDRO TAVICHE	2022-11-11 12:31:55	\N
11186	20	329	SAN PEDRO TEOZACOALCO	2022-11-11 12:31:55	\N
11187	20	330	SAN PEDRO TEUTILA	2022-11-11 12:31:55	\N
11188	20	331	SAN PEDRO TIDAA	2022-11-11 12:31:55	\N
11189	20	332	SAN PEDRO TOPILTEPEC	2022-11-11 12:31:55	\N
11190	20	333	SAN PEDRO TOTOLAPA	2022-11-11 12:31:55	\N
11191	20	334	SAN PEDRO TUTUTEPEC	2022-11-11 12:31:55	\N
11192	20	335	SAN PEDRO YANERI	2022-11-11 12:31:55	\N
11193	20	336	SAN PEDRO YOLOX	2022-11-11 12:31:55	\N
11194	20	337	SAN PEDRO Y SAN PABLO AYUTLA	2022-11-11 12:31:55	\N
11195	20	338	VILLA DE ETLA	2022-11-11 12:31:55	\N
11196	20	339	SAN PEDRO Y SAN PABLO TEPOSCOL	2022-11-11 12:31:55	\N
11197	20	340	SAN PEDRO Y SAN PABLO TEQUIXTE	2022-11-11 12:31:55	\N
11198	20	341	SAN PEDRO YUCUNAMA	2022-11-11 12:31:55	\N
11199	20	342	SAN RAYMUNDO JALPAN	2022-11-11 12:31:55	\N
11200	20	343	SAN SEBASTIAN ABASOLO	2022-11-11 12:31:55	\N
11201	20	344	SAN SEBASTIAN COATLAN	2022-11-11 12:31:55	\N
11202	20	345	SAN SEBASTIAN IXCAPA	2022-11-11 12:31:55	\N
11203	20	346	SAN SEBASTIAN NICANANDUTA	2022-11-11 12:31:55	\N
11204	20	347	SAN SEBASTIAN RIO HONDO	2022-11-11 12:31:55	\N
11205	20	348	SAN SEBASTIAN TECOMAXTLAHUACA	2022-11-11 12:31:55	\N
11206	20	349	SAN SEBASTIAN TEITIPAC	2022-11-11 12:31:55	\N
11207	20	350	SAN SEBASTIAN TUTLA	2022-11-11 12:31:55	\N
11208	20	351	SAN SIMON ALMOLONGAS	2022-11-11 12:31:55	\N
11209	20	352	SAN SIMON ZAHUATLAN	2022-11-11 12:31:55	\N
11210	20	353	SANTA ANA	2022-11-11 12:31:55	\N
11211	20	354	SANTA ANA ATEIXTLAHUACA	2022-11-11 12:31:55	\N
11212	20	355	SANTA ANA CUAUHTEMOC	2022-11-11 12:31:55	\N
11213	20	356	SANTA ANA DEL VALLE	2022-11-11 12:31:55	\N
11214	20	357	SANTA ANA TAVELA	2022-11-11 12:31:55	\N
11215	20	358	SANTA ANA TLAPACOYAN	2022-11-11 12:31:55	\N
11216	20	359	SANTA ANA YARENI	2022-11-11 12:31:55	\N
11217	20	360	SANTA ANA ZEGACHE	2022-11-11 12:31:55	\N
11218	20	361	SANTA CATALINA QUIERI	2022-11-11 12:31:55	\N
11219	20	362	SANTA CATARINA CUIXTLA	2022-11-11 12:31:55	\N
11220	20	363	SANTA CATARINA IXTEPEJI	2022-11-11 12:31:55	\N
11221	20	364	SANTA CATARINA JUQUILA	2022-11-11 12:31:55	\N
11222	20	365	SANTA CATARINA LACHATAO	2022-11-11 12:31:55	\N
11223	20	366	SANTA CATARINA LOXICHA	2022-11-11 12:31:55	\N
11224	20	367	SANTA CATARINA MECHOACAN	2022-11-11 12:31:55	\N
11225	20	368	SANTA CATARINA MINAS	2022-11-11 12:31:55	\N
11226	20	369	SANTA CATARINA QUIANE	2022-11-11 12:31:55	\N
11227	20	370	SANTA CATARINA TAYATA	2022-11-11 12:31:55	\N
11228	20	371	SANTA CATARINA TICUA	2022-11-11 12:31:55	\N
11229	20	372	SANTA CATARINA YOSONOTU	2022-11-11 12:31:55	\N
11230	20	373	SANTA CATARINA ZAPOQUILA	2022-11-11 12:31:55	\N
11231	20	374	SANTA CRUZ ACATEPEC	2022-11-11 12:31:55	\N
11232	20	375	SANTA CRUZ AMILPAS	2022-11-11 12:31:55	\N
11233	20	376	SANTA CRUZ DE BRAVO	2022-11-11 12:31:55	\N
11234	20	377	SANTA CRUZ ITUNDUJIA	2022-11-11 12:31:55	\N
11235	20	378	SANTA CRUZ MIXTEPEC	2022-11-11 12:31:55	\N
11236	20	379	SANTA CRUZ NUNDACO	2022-11-11 12:31:55	\N
11237	20	380	SANTA CRUZ PAPALUTLA	2022-11-11 12:31:55	\N
11238	20	381	SANTA CRUZ TACACHE DE MINA	2022-11-11 12:31:55	\N
11239	20	382	SANTA CRUZ TACAHUA	2022-11-11 12:31:55	\N
11240	20	383	SANTA CRUZ TAYATA	2022-11-11 12:31:55	\N
11241	20	384	SANTA CRUZ XITLA	2022-11-11 12:31:55	\N
11242	20	385	SANTA CRUZ XOXOCOTLAN	2022-11-11 12:31:55	\N
11243	20	386	SANTA CRUZ ZENZONTEPEC	2022-11-11 12:31:55	\N
11244	20	387	SANTA GERTRUDIS	2022-11-11 12:31:55	\N
11245	20	388	SANTA INES DEL MONTE	2022-11-11 12:31:55	\N
11246	20	389	SANTA INES YATZECHE	2022-11-11 12:31:55	\N
11247	20	390	SANTA LUCIA DEL CAMINO	2022-11-11 12:31:55	\N
11248	20	391	SANTA LUCIA MIAHUATLAN	2022-11-11 12:31:55	\N
11249	20	392	SANTA LUCIA MONTEVERDE	2022-11-11 12:31:55	\N
11250	20	393	SANTA LUCIA OCOTLAN	2022-11-11 12:31:55	\N
11251	20	394	SANTA MARIA ALOTEPEC	2022-11-11 12:31:55	\N
11252	20	395	SANTA MARIA APAZCO	2022-11-11 12:31:55	\N
11253	20	396	SANTA MARIA LA ASUNCION	2022-11-11 12:31:55	\N
11254	20	397	HEROICA CIUDAD DE TLAXIACO	2022-11-11 12:31:55	\N
11255	20	398	AYOQUEZCO DE ALDAMA	2022-11-11 12:31:55	\N
11256	20	399	SANTA MARIA ATZOMPA	2022-11-11 12:31:55	\N
11257	20	400	SANTA MARIA CAMOTLAN	2022-11-11 12:31:55	\N
11258	20	401	SANTA MARIA COLOTEPEC	2022-11-11 12:31:55	\N
11259	20	402	SANTA MARIA CORTIJO	2022-11-11 12:31:55	\N
11260	20	403	SANTA MARIA COYOTEPEC	2022-11-11 12:31:55	\N
11261	20	404	SANTA MARIA CHACHOAPAM	2022-11-11 12:31:55	\N
11262	20	405	SANTA MARIA CHILAPA DE DIAZ	2022-11-11 12:31:55	\N
11263	20	406	SANTA MARIA CHILCHOTLA	2022-11-11 12:31:55	\N
11264	20	407	SANTA MARIA CHIMALAPA	2022-11-11 12:31:55	\N
11265	20	408	SANTA MARIA DEL ROSARIO	2022-11-11 12:31:55	\N
11266	20	409	SANTA MARIA DEL TULE	2022-11-11 12:31:55	\N
11267	20	410	SANTA MARIA ECATEPEC	2022-11-11 12:31:55	\N
11268	20	411	SANTA MARIA GUELACE	2022-11-11 12:31:55	\N
11269	20	412	SANTA MARIA GUIENAGATI	2022-11-11 12:31:55	\N
11270	20	413	SANTA MARIA HUATULCO	2022-11-11 12:31:55	\N
11271	20	414	SANTA MARIA HUAZOLOTITLAN	2022-11-11 12:31:55	\N
11272	20	415	SANTA MARIA IPALAPA	2022-11-11 12:31:55	\N
11273	20	416	SANTA MARIA IXCATLAN	2022-11-11 12:31:55	\N
11274	20	417	SANTA MARIA JACATEPEC	2022-11-11 12:31:55	\N
11275	20	418	SANTA MARIA JALAPA DEL MARQUES	2022-11-11 12:31:55	\N
11276	20	419	SANTA MARIA JALTIANGUIS	2022-11-11 12:31:55	\N
11277	20	420	SANTA MARIA LACHIXIO	2022-11-11 12:31:55	\N
11278	20	421	SANTA MARIA MIXTEQUILLA	2022-11-11 12:31:55	\N
11279	20	422	SANTA MARIA NATIVITAS	2022-11-11 12:31:55	\N
11280	20	423	SANTA MARIA NDUAYACO	2022-11-11 12:31:55	\N
11281	20	424	SANTA MARIA OZOLOTEPEC	2022-11-11 12:31:55	\N
11282	20	425	SANTA MARIA PAPALO	2022-11-11 12:31:55	\N
11283	20	426	SANTA MARIA PE¥OLES	2022-11-11 12:31:55	\N
11284	20	427	SANTA MARIA PETAPA	2022-11-11 12:31:55	\N
11285	20	428	SANTA MARIA QUIEGOLANI	2022-11-11 12:31:55	\N
11286	20	429	SANTA MARIA SOLA	2022-11-11 12:31:55	\N
11287	20	430	SANTA MARIA TATALTEPEC	2022-11-11 12:31:55	\N
11288	20	431	SANTA MARIA TECOMAVACA	2022-11-11 12:31:55	\N
11289	20	432	SANTA MARIA TEMAXCALAPA	2022-11-11 12:31:55	\N
11290	20	433	SANTA MARIA TEMAXCALTEPEC	2022-11-11 12:31:55	\N
11291	20	434	SANTA MARIA TEOPOXCO	2022-11-11 12:31:55	\N
11292	20	435	SANTA MARIA TEPANTLALI	2022-11-11 12:31:55	\N
11293	20	436	SANTA MARIA TEXCATITLAN	2022-11-11 12:31:55	\N
11294	20	437	SANTA MARIA TLAHUITOLTEPEC	2022-11-11 12:31:55	\N
11295	20	438	SANTA MARIA TLALIXTAC	2022-11-11 12:31:55	\N
11296	20	439	SANTA MARIA TONAMECA	2022-11-11 12:31:55	\N
11297	20	440	SANTA MARIA TOTOLAPILLA	2022-11-11 12:31:55	\N
11298	20	441	SANTA MARIA XADANI	2022-11-11 12:31:55	\N
11299	20	442	SANTA MARIA YALINA	2022-11-11 12:31:55	\N
11300	20	443	SANTA MARIA YAVESIA	2022-11-11 12:31:55	\N
11301	20	444	SANTA MARIA YOLOTEPEC	2022-11-11 12:31:55	\N
11302	20	445	SANTA MARIA YOSOYUA	2022-11-11 12:31:55	\N
11303	20	446	SANTA MARIA YUCUHITI	2022-11-11 12:31:55	\N
11304	20	447	SANTA MARIA ZACATEPEC	2022-11-11 12:31:55	\N
11305	20	448	SANTA MARIA ZANIZA	2022-11-11 12:31:55	\N
11306	20	449	SANTA MARIA ZOQUITLAN	2022-11-11 12:31:55	\N
11307	20	450	SANTIAGO AMOLTEPEC	2022-11-11 12:31:55	\N
11308	20	451	SANTIAGO APOALA	2022-11-11 12:31:55	\N
11309	20	452	SANTIAGO APOSTOL	2022-11-11 12:31:55	\N
11310	20	453	SANTIAGO ASTATA	2022-11-11 12:31:55	\N
11311	20	454	SANTIAGO ATITLAN	2022-11-11 12:31:55	\N
11312	20	455	SANTIAGO AYUQUILILLA	2022-11-11 12:31:55	\N
11313	20	456	SANTIAGO CACALOXTEPEC	2022-11-11 12:31:55	\N
11314	20	457	SANTIAGO CAMOTLAN	2022-11-11 12:31:55	\N
11315	20	458	SANTIAGO COMALTEPEC	2022-11-11 12:31:55	\N
11316	20	459	SANTIAGO CHAZUMBA	2022-11-11 12:31:55	\N
11317	20	460	SANTIAGO CHOAPAM	2022-11-11 12:31:55	\N
11318	20	461	SANTIAGO DEL RIO	2022-11-11 12:31:55	\N
11319	20	462	SANTIAGO HUAJOLOTITLAN	2022-11-11 12:31:55	\N
11320	20	463	SANTIAGO HUAUCLILLA	2022-11-11 12:31:55	\N
11321	20	464	SANTIAGO IHUITLAN PLUMAS	2022-11-11 12:31:55	\N
11322	20	465	SANTIAGO IXCUINTEPEC	2022-11-11 12:31:55	\N
11323	20	466	SANTIAGO IXTAYUTLA	2022-11-11 12:31:55	\N
11324	20	467	SANTIAGO JAMILTEPEC	2022-11-11 12:31:55	\N
11325	20	468	SANTIAGO JOCOTEPEC	2022-11-11 12:31:55	\N
11326	20	469	SANTIAGO JUXTLAHUACA	2022-11-11 12:31:55	\N
11327	20	470	SANTIAGO LACHIGUIRI	2022-11-11 12:31:55	\N
11328	20	471	SANTIAGO LALOPA	2022-11-11 12:31:55	\N
11329	20	472	SANTIAGO LAOLLAGA	2022-11-11 12:31:55	\N
11330	20	473	SANTIAGO LAXOPA	2022-11-11 12:31:55	\N
11331	20	474	SANTIAGO LLANO GRANDE	2022-11-11 12:31:55	\N
11332	20	475	SANTIAGO MATATLAN	2022-11-11 12:31:55	\N
11333	20	476	SANTIAGO MILTEPEC	2022-11-11 12:31:55	\N
11334	20	477	SANTIAGO MINAS	2022-11-11 12:31:55	\N
11335	20	478	SANTIAGO NACALTEPEC	2022-11-11 12:31:55	\N
11336	20	479	SANTIAGO NEJAPILLA	2022-11-11 12:31:55	\N
11337	20	480	SANTIAGO NUNDICHE	2022-11-11 12:31:55	\N
11338	20	481	SANTIAGO NUYOO	2022-11-11 12:31:55	\N
11339	20	482	SANTIAGO PINOTEPA NACIONAL	2022-11-11 12:31:55	\N
11340	20	483	SANTIAGO SUCHILQUITONGO	2022-11-11 12:31:55	\N
11341	20	484	SANTIAGO TAMAZOLA	2022-11-11 12:31:55	\N
11342	20	485	SANTIAGO TAPEXTLA	2022-11-11 12:31:55	\N
11343	20	486	VILLA TEJUPAM DE LA UNION	2022-11-11 12:31:55	\N
11344	20	487	SANTIAGO TENANGO	2022-11-11 12:31:55	\N
11345	20	488	SANTIAGO TEPETLAPA	2022-11-11 12:31:55	\N
11346	20	489	SANTIAGO TETEPEC	2022-11-11 12:31:55	\N
11347	20	490	SANTIAGO TEXCALCINGO	2022-11-11 12:31:55	\N
11348	20	491	SANTIAGO TEXTITLAN	2022-11-11 12:31:55	\N
11349	20	492	SANTIAGO TILANTONGO	2022-11-11 12:31:55	\N
11350	20	493	SANTIAGO TILLO	2022-11-11 12:31:55	\N
11351	20	494	SANTIAGO TLAZOYALTEPEC	2022-11-11 12:31:55	\N
11352	20	495	SANTIAGO XANICA	2022-11-11 12:31:55	\N
11353	20	496	SANTIAGO XIACUI	2022-11-11 12:31:55	\N
11354	20	497	SANTIAGO YAITEPEC	2022-11-11 12:31:55	\N
11355	20	498	SANTIAGO YAVEO	2022-11-11 12:31:55	\N
11356	20	499	SANTIAGO YOLOMECATL	2022-11-11 12:31:55	\N
11357	20	500	SANTIAGO YOSONDUA	2022-11-11 12:31:55	\N
11358	20	501	SANTIAGO YUCUYACHI	2022-11-11 12:31:55	\N
11359	20	502	SANTIAGO ZACATEPEC	2022-11-11 12:31:55	\N
11360	20	503	SANTIAGO ZOOCHILA	2022-11-11 12:31:55	\N
11361	20	504	NUEVO ZOQUIAPAM	2022-11-11 12:31:55	\N
11362	20	505	SANTO DOMINGO INGENIO	2022-11-11 12:31:55	\N
11363	20	506	SANTO DOMINGO ALBARRADAS	2022-11-11 12:31:55	\N
11364	20	507	SANTO DOMINGO ARMENTA	2022-11-11 12:31:55	\N
11365	20	508	SANTO DOMINGO CHIHUITAN	2022-11-11 12:31:55	\N
11366	20	509	SANTO DOMINGO DE MORELOS	2022-11-11 12:31:55	\N
11367	20	510	SANTO DOMINGO IXCATLAN	2022-11-11 12:31:55	\N
11368	20	511	SANTO DOMINGO NUXAA	2022-11-11 12:31:55	\N
11369	20	512	SANTO DOMINGO OZOLOTEPEC	2022-11-11 12:31:55	\N
11370	20	513	SANTO DOMINGO PETAPA	2022-11-11 12:31:55	\N
11371	20	514	SANTO DOMINGO ROAYAGA	2022-11-11 12:31:55	\N
11372	20	515	SANTO DOMINGO TEHUANTEPEC	2022-11-11 12:31:55	\N
11373	20	516	SANTO DOMINGO TEOJOMULCO	2022-11-11 12:31:55	\N
11374	20	517	SANTO DOMINGO TEPUXTEPEC	2022-11-11 12:31:55	\N
11375	20	518	SANTO DOMINGO TLATAYAPAM	2022-11-11 12:31:55	\N
11376	20	519	SANTO DOMINGO TOMALTEPEC	2022-11-11 12:31:55	\N
11377	20	520	SANTO DOMINGO TONALA	2022-11-11 12:31:55	\N
11378	20	521	SANTO DOMINGO TONALTEPEC	2022-11-11 12:31:55	\N
11379	20	522	SANTO DOMINGO XAGACIA	2022-11-11 12:31:55	\N
11380	20	523	SANTO DOMINGO YANHUITLAN	2022-11-11 12:31:55	\N
11381	20	524	SANTO DOMINGO YODOHINO	2022-11-11 12:31:55	\N
11382	20	525	SANTO DOMINGO ZANATEPEC	2022-11-11 12:31:55	\N
11383	20	526	SANTOS REYES NOPALA	2022-11-11 12:31:55	\N
11384	20	527	SANTOS REYES PAPALO	2022-11-11 12:31:55	\N
11385	20	528	SANTOS REYES TEPEJILLO	2022-11-11 12:31:55	\N
11386	20	529	SANTOS REYES YUCUNA	2022-11-11 12:31:55	\N
11387	20	530	SANTO TOMAS JALIEZA	2022-11-11 12:31:55	\N
11388	20	531	SANTO TOMAS MAZALTEPEC	2022-11-11 12:31:55	\N
11389	20	532	SANTO TOMAS OCOTEPEC	2022-11-11 12:31:55	\N
11390	20	533	SANTO TOMAS TAMAZULAPAM	2022-11-11 12:31:55	\N
11391	20	534	SAN VICENTE COATLAN	2022-11-11 12:31:55	\N
11392	20	535	SAN VICENTE LACHIXIO	2022-11-11 12:31:55	\N
11393	20	536	SAN VICENTE NU¥U	2022-11-11 12:31:55	\N
11394	20	537	SILACAYOAPAM	2022-11-11 12:31:55	\N
11395	20	538	SITIO DE XITLAPEHUA	2022-11-11 12:31:55	\N
11396	20	539	SOLEDAD ETLA	2022-11-11 12:31:55	\N
11397	20	540	VILLA DE TAMAZULAPAM DEL PROGR	2022-11-11 12:31:55	\N
11398	20	541	TANETZE DE ZARAGOZA	2022-11-11 12:31:55	\N
11399	20	542	TANICHE	2022-11-11 12:31:55	\N
11400	20	543	TATALTEPEC DE VALDES	2022-11-11 12:31:55	\N
11401	20	544	TEOCOCUILCO DE MARCOS PEREZ	2022-11-11 12:31:55	\N
11402	20	545	TEOTITLAN DE FLORES MAGON	2022-11-11 12:31:55	\N
11403	20	546	TEOTITLAN DEL VALLE	2022-11-11 12:31:55	\N
11404	20	547	TEOTONGO	2022-11-11 12:31:55	\N
11405	20	548	TEPELMEME VILLA DE MORELOS	2022-11-11 12:31:55	\N
11406	20	549	TEZOATLAN DE SEGURA Y LUNA	2022-11-11 12:31:55	\N
11407	20	550	SAN JERONIMO TLACOCHAHUAYA	2022-11-11 12:31:55	\N
11408	20	551	TLACOLULA DE MATAMOROS	2022-11-11 12:31:55	\N
11409	20	552	TLACOTEPEC PLUMAS	2022-11-11 12:31:55	\N
11410	20	553	TLALIXTAC DE CABRERA	2022-11-11 12:31:55	\N
11411	20	554	TOTONTEPEC VILLA DE MORELOS	2022-11-11 12:31:55	\N
11412	20	555	TRINIDAD ZAACHILA	2022-11-11 12:31:55	\N
11413	20	556	TRINIDAD VISTA HERMOSA, LA	2022-11-11 12:31:55	\N
11414	20	557	UNION HIDALGO	2022-11-11 12:31:55	\N
11415	20	558	VALERIO TRUJANO	2022-11-11 12:31:55	\N
11416	20	559	SAN JUAN BAUTISTA VALLE NACION	2022-11-11 12:31:55	\N
11417	20	560	VILLA DIAZ ORDAZ	2022-11-11 12:31:55	\N
11418	20	561	YAXE	2022-11-11 12:31:55	\N
11419	20	562	MAGDALENA YODOCONO DE PORFIRIO	2022-11-11 12:31:55	\N
11420	20	563	YOGANA	2022-11-11 12:31:55	\N
11421	20	564	YUTANDUCHI DE GUERRERO	2022-11-11 12:31:55	\N
11422	20	565	VILLA DE ZAACHILA	2022-11-11 12:31:55	\N
11423	20	566	ZAPOTITLAN DEL RIO	2022-11-11 12:31:55	\N
11424	20	567	ZAPOTITLAN LAGUNAS	2022-11-11 12:31:55	\N
11425	20	568	ZAPOTITLAN PALMAS	2022-11-11 12:31:55	\N
11426	20	569	SANTA INES DE ZARAGOZA	2022-11-11 12:31:55	\N
11427	20	570	ZIMATLAN DE ALVAREZ	2022-11-11 12:31:55	\N
11428	20	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11429	21	1	ACAJETE	2022-11-11 12:31:55	\N
11430	21	2	ACATENO	2022-11-11 12:31:55	\N
11431	21	3	ACATLAN	2022-11-11 12:31:55	\N
11432	21	4	ACATZINGO	2022-11-11 12:31:55	\N
11433	21	5	ACTEOPAN	2022-11-11 12:31:55	\N
11434	21	6	AHUACATLAN	2022-11-11 12:31:55	\N
11435	21	7	AHUATLAN	2022-11-11 12:31:55	\N
11436	21	8	AHUAZOTEPEC	2022-11-11 12:31:55	\N
11437	21	9	AHUEHUETITLA	2022-11-11 12:31:55	\N
11438	21	10	AJALPAN	2022-11-11 12:31:55	\N
11439	21	11	ALBINO ZERTUCHE	2022-11-11 12:31:55	\N
11440	21	12	ALJOJUCA	2022-11-11 12:31:55	\N
11441	21	13	ALTEPEXI	2022-11-11 12:31:55	\N
11442	21	14	AMIXTLAN	2022-11-11 12:31:55	\N
11443	21	15	AMOZOC	2022-11-11 12:31:55	\N
11444	21	16	AQUIXTLA	2022-11-11 12:31:55	\N
11445	21	17	ATEMPAN	2022-11-11 12:31:55	\N
11446	21	18	ATEXCAL	2022-11-11 12:31:55	\N
11447	21	19	ATLIXCO	2022-11-11 12:31:55	\N
11448	21	20	ATOYATEMPAN	2022-11-11 12:31:55	\N
11449	21	21	ATZALA	2022-11-11 12:31:55	\N
11450	21	22	ATZITZIHUACAN	2022-11-11 12:31:55	\N
11451	21	23	ATZITZINTLA	2022-11-11 12:31:55	\N
11452	21	24	AXUTLA	2022-11-11 12:31:55	\N
11453	21	25	AYOTOXCO DE GUERRERO	2022-11-11 12:31:55	\N
11454	21	26	CALPAN	2022-11-11 12:31:55	\N
11455	21	27	CALTEPEC	2022-11-11 12:31:55	\N
11456	21	28	CAMOCUAUTLA	2022-11-11 12:31:55	\N
11457	21	29	CAXHUACAN	2022-11-11 12:31:55	\N
11458	21	30	COATEPEC	2022-11-11 12:31:55	\N
11459	21	31	COATZINGO	2022-11-11 12:31:55	\N
11460	21	32	COHETZALA	2022-11-11 12:31:55	\N
11461	21	33	COHUECAN	2022-11-11 12:31:55	\N
11462	21	34	CORONANGO	2022-11-11 12:31:55	\N
11463	21	35	COXCATLAN	2022-11-11 12:31:55	\N
11464	21	36	COYOMEAPAN	2022-11-11 12:31:55	\N
11465	21	37	COYOTEPEC	2022-11-11 12:31:55	\N
11466	21	38	CUAPIAXTLA DE MADERO	2022-11-11 12:31:55	\N
11467	21	39	CUAUTEMPAN	2022-11-11 12:31:55	\N
11468	21	40	CUAUTINCHAN	2022-11-11 12:31:55	\N
11469	21	41	CUAUTLANCINGO	2022-11-11 12:31:55	\N
11470	21	42	CUAYUCA DE ANDRADE	2022-11-11 12:31:55	\N
11471	21	43	CUETZALAN DEL PROGRESO	2022-11-11 12:31:55	\N
11472	21	44	CUYOACO	2022-11-11 12:31:55	\N
11473	21	45	CHALCHICOMULA DE SESMA	2022-11-11 12:31:55	\N
11474	21	46	CHAPULCO	2022-11-11 12:31:55	\N
11475	21	47	CHIAUTLA	2022-11-11 12:31:55	\N
11476	21	48	CHIAUTZINGO	2022-11-11 12:31:55	\N
11477	21	49	CHICONCUAUTLA	2022-11-11 12:31:55	\N
11478	21	50	CHICHIQUILA	2022-11-11 12:31:55	\N
11479	21	51	CHIETLA	2022-11-11 12:31:55	\N
11480	21	52	CHIGMECATITLAN	2022-11-11 12:31:55	\N
11481	21	53	CHIGNAHUAPAN	2022-11-11 12:31:55	\N
11482	21	54	CHIGNAUTLA	2022-11-11 12:31:55	\N
11483	21	55	CHILA	2022-11-11 12:31:55	\N
11484	21	56	CHILA DE LA SAL	2022-11-11 12:31:55	\N
11485	21	57	CHILA  HONEY	2022-11-11 12:31:55	\N
11486	21	58	CHILCHOTLA	2022-11-11 12:31:55	\N
11487	21	59	CHINANTLA	2022-11-11 12:31:55	\N
11488	21	60	DOMINGO ARENAS	2022-11-11 12:31:55	\N
11489	21	61	ELOXOCHITLAN	2022-11-11 12:31:55	\N
11490	21	62	EPATLAN	2022-11-11 12:31:55	\N
11491	21	63	ESPERANZA	2022-11-11 12:31:55	\N
11492	21	64	FRANCISCO Z. MENA	2022-11-11 12:31:55	\N
11493	21	65	GENERAL FELIPE ANGELES	2022-11-11 12:31:55	\N
11494	21	66	GUADALUPE	2022-11-11 12:31:55	\N
11495	21	67	GUADALUPE VICTORIA	2022-11-11 12:31:55	\N
11496	21	68	HERMENEGILDO GALEANA	2022-11-11 12:31:55	\N
11497	21	69	HUAQUECHULA	2022-11-11 12:31:55	\N
11498	21	70	HUATLATLAUCA	2022-11-11 12:31:55	\N
11499	21	71	HUAUCHINANGO	2022-11-11 12:31:55	\N
11500	21	72	HUEHUETLA	2022-11-11 12:31:55	\N
11501	21	73	HUEHUETLAN EL CHICO	2022-11-11 12:31:55	\N
11502	21	74	HUEJOTZINGO	2022-11-11 12:31:55	\N
11503	21	75	HUEYAPAN	2022-11-11 12:31:55	\N
11504	21	76	HUEYTAMALCO	2022-11-11 12:31:55	\N
11505	21	77	HUEYTLALPAN	2022-11-11 12:31:55	\N
11506	21	78	HUITZILAN DE SERDAN	2022-11-11 12:31:55	\N
11507	21	79	HUITZILTEPEC	2022-11-11 12:31:55	\N
11508	21	80	IGNACIO ALLENDE	2022-11-11 12:31:55	\N
11509	21	81	IXCAMILPA DE GUERRERO	2022-11-11 12:31:55	\N
11510	21	82	IXCAQUIXTLA	2022-11-11 12:31:55	\N
11511	21	83	IXTACAMAXTITLAN	2022-11-11 12:31:55	\N
11512	21	84	IXTEPEC	2022-11-11 12:31:55	\N
11513	21	85	IZUCAR DE MATAMOROS	2022-11-11 12:31:55	\N
11514	21	86	JALPAN	2022-11-11 12:31:55	\N
11515	21	87	JOLALPAN	2022-11-11 12:31:55	\N
11516	21	88	JONOTLA	2022-11-11 12:31:55	\N
11517	21	89	JOPALA	2022-11-11 12:31:55	\N
11518	21	90	JUAN C. BONILLA	2022-11-11 12:31:55	\N
11519	21	91	JUAN GALINDO	2022-11-11 12:31:55	\N
11520	21	92	JUAN N. MENDEZ	2022-11-11 12:31:55	\N
11521	21	93	LAFRAGUA	2022-11-11 12:31:55	\N
11522	21	94	LIBRES	2022-11-11 12:31:55	\N
11523	21	95	MAGDALENA TLATLAUQUITEPEC, LA	2022-11-11 12:31:55	\N
11524	21	96	MAZAPILTEPEC DE JUAREZ	2022-11-11 12:31:55	\N
11525	21	97	MIXTLA	2022-11-11 12:31:55	\N
11526	21	98	MOLCAXAC	2022-11-11 12:31:55	\N
11527	21	99	CA¥ADA MORELOS	2022-11-11 12:31:55	\N
11528	21	100	NAUPAN	2022-11-11 12:31:55	\N
11529	21	101	NAUZONTLA	2022-11-11 12:31:55	\N
11530	21	102	NEALTICAN	2022-11-11 12:31:55	\N
11531	21	103	NICOLAS BRAVO	2022-11-11 12:31:55	\N
11532	21	104	NOPALUCAN	2022-11-11 12:31:55	\N
11533	21	105	NOCOTEPEC	2022-11-11 12:31:55	\N
11534	21	106	OCOYUCAN	2022-11-11 12:31:55	\N
11535	21	107	OLINTLA	2022-11-11 12:31:55	\N
11536	21	108	ORIENTAL	2022-11-11 12:31:55	\N
11537	21	109	PAHUATLAN	2022-11-11 12:31:55	\N
11538	21	110	PALMAR DE BRAVO	2022-11-11 12:31:55	\N
11539	21	111	PANTEPEC	2022-11-11 12:31:55	\N
11540	21	112	PETLALCINGO	2022-11-11 12:31:55	\N
11541	21	113	PIAXTLA	2022-11-11 12:31:55	\N
11542	21	114	PUEBLA	2022-11-11 12:31:55	\N
11543	21	115	QUECHOLAC	2022-11-11 12:31:55	\N
11544	21	116	QUIMIXTLAN	2022-11-11 12:31:55	\N
11545	21	117	RAFAEL LARA GRAJALES	2022-11-11 12:31:55	\N
11546	21	118	REYES DE JUAREZ, LOS	2022-11-11 12:31:55	\N
11547	21	119	SAN ANDRES CHOLULA	2022-11-11 12:31:55	\N
11548	21	120	SAN ANTONIO CA¥ADA	2022-11-11 12:31:55	\N
11549	21	121	SAN DIEGO LA MESA TOCHIMILTZIN	2022-11-11 12:31:55	\N
11550	21	122	SAN FELIPE TEOTLALCINGO	2022-11-11 12:31:55	\N
11551	21	123	SAN FELIPE TEPATLAN	2022-11-11 12:31:55	\N
11552	21	124	SAN GABRIEL CHILAC	2022-11-11 12:31:55	\N
11553	21	125	SAN GREGORIO ATZOMPA	2022-11-11 12:31:55	\N
11554	21	126	SAN JERONIMO TECUANIPAN	2022-11-11 12:31:55	\N
11555	21	127	SAN JERONIMO XAYACATLAN	2022-11-11 12:31:55	\N
11556	21	128	SAN JOSE CHIAPA	2022-11-11 12:31:55	\N
11557	21	129	SAN JOSE MIAHUATLAN	2022-11-11 12:31:55	\N
11558	21	130	SAN JUAN ATENCO	2022-11-11 12:31:55	\N
11559	21	131	SAN JUAN ATZOMPA	2022-11-11 12:31:55	\N
11560	21	132	SAN MARTIN TEXMELUCAN	2022-11-11 12:31:55	\N
11561	21	133	SAN MARTIN TOTOLTEPEC	2022-11-11 12:31:55	\N
11562	21	134	SAN MATIAS TLALANCALECA	2022-11-11 12:31:55	\N
11563	21	135	SAN MIGUEL IXITLAN	2022-11-11 12:31:55	\N
11564	21	136	SAN MIGUEL XOXTLA	2022-11-11 12:31:55	\N
11565	21	137	SAN NICOLAS BUENOS AIRES	2022-11-11 12:31:55	\N
11566	21	138	SAN NICOLAS DE LOS RANCHOS	2022-11-11 12:31:55	\N
11567	21	139	SAN PABLO ANICANO	2022-11-11 12:31:55	\N
11568	21	140	SAN PEDRO CHOLULA	2022-11-11 12:31:55	\N
11569	21	141	SAN PEDRO YELOIXTLAHUACA	2022-11-11 12:31:55	\N
11570	21	142	SAN SALVADOR EL SECO	2022-11-11 12:31:55	\N
11571	21	143	SAN SALVADOR EL VERDE	2022-11-11 12:31:55	\N
11572	21	144	SAN SALVADOR HUIXCOLOTLA	2022-11-11 12:31:55	\N
11573	21	145	SAN SEBASTIAN TLACOTEPEC	2022-11-11 12:31:55	\N
11574	21	146	SANTA CATARINA TLALTEMPAN	2022-11-11 12:31:55	\N
11575	21	147	SANTA INES AHUATEMPAN	2022-11-11 12:31:55	\N
11576	21	148	SANTA ISABEL CHOLULA	2022-11-11 12:31:55	\N
11577	21	149	SANTIAGO MIAHUATLAN	2022-11-11 12:31:55	\N
11578	21	150	HUEHUETLAN EL GRANDE	2022-11-11 12:31:55	\N
11579	21	151	SANTO TOMAS HUEYOTLIPAN	2022-11-11 12:31:55	\N
11580	21	152	SOLTEPEC	2022-11-11 12:31:55	\N
11581	21	153	TECALI DE HERRERA	2022-11-11 12:31:55	\N
11582	21	154	TECAMACHALCO	2022-11-11 12:31:55	\N
11583	21	155	TECOMATLAN	2022-11-11 12:31:55	\N
11584	21	156	TEHUACAN	2022-11-11 12:31:55	\N
11585	21	157	TEHUITZINGO	2022-11-11 12:31:55	\N
11586	21	158	TENAMPULCO	2022-11-11 12:31:55	\N
11587	21	159	TEOPANTLAN	2022-11-11 12:31:55	\N
11588	21	160	TEOTLALCO	2022-11-11 12:31:55	\N
11589	21	161	TEPANCO DE LOPEZ	2022-11-11 12:31:55	\N
11590	21	162	TEPANGO DE RODRIGUEZ	2022-11-11 12:31:55	\N
11591	21	163	TEPATLAXCO DE HIDALGO	2022-11-11 12:31:55	\N
11592	21	164	TEPEACA	2022-11-11 12:31:55	\N
11593	21	165	TEPEMAXALCO	2022-11-11 12:31:55	\N
11594	21	166	TEPEOJUMA	2022-11-11 12:31:55	\N
11595	21	167	TEPETZINTLA	2022-11-11 12:31:55	\N
11596	21	168	TEPEXCO	2022-11-11 12:31:55	\N
11597	21	169	TEPEXI DE RODRIGUEZ	2022-11-11 12:31:55	\N
11598	21	170	TEPEYAHUALCO	2022-11-11 12:31:55	\N
11599	21	171	TEPEYAHUALCO DE CUAUHTEMOC	2022-11-11 12:31:55	\N
11600	21	172	TETELA DE OCAMPO	2022-11-11 12:31:55	\N
11601	21	173	TETELES DE AVILA CASTILLO	2022-11-11 12:31:55	\N
11602	21	174	TEZIUTLAN	2022-11-11 12:31:55	\N
11603	21	175	TIANGUISMANALCO	2022-11-11 12:31:55	\N
11604	21	176	TILAPA	2022-11-11 12:31:55	\N
11605	21	177	TLACOTEPEC DE BENITO JUAREZ	2022-11-11 12:31:55	\N
11606	21	178	TLACUILOTEPEC	2022-11-11 12:31:55	\N
11607	21	179	TLACHICHUCA	2022-11-11 12:31:55	\N
11608	21	180	TLAHUAPAN	2022-11-11 12:31:55	\N
11609	21	181	TLALTENANGO	2022-11-11 12:31:55	\N
11610	21	182	TLANEPANTLA	2022-11-11 12:31:55	\N
11611	21	183	TLAOLA	2022-11-11 12:31:55	\N
11612	21	184	TLAPACOYA	2022-11-11 12:31:55	\N
11613	21	185	TLAPANALA	2022-11-11 12:31:55	\N
11614	21	186	TLATLAUQUITEPEC	2022-11-11 12:31:55	\N
11615	21	187	TLAXCO	2022-11-11 12:31:55	\N
11616	21	188	TOCHIMILCO	2022-11-11 12:31:55	\N
11617	21	189	TOCHTEPEC	2022-11-11 12:31:55	\N
11618	21	190	TOTOLTEPEC DE GUERRERO	2022-11-11 12:31:55	\N
11619	21	191	TULCINGO	2022-11-11 12:31:55	\N
11620	21	192	TUZAMAPAN DE GALEANA	2022-11-11 12:31:55	\N
11621	21	193	TZICATLACOYAN	2022-11-11 12:31:55	\N
11622	21	194	VENUSTIANO CARRANZA	2022-11-11 12:31:55	\N
11623	21	195	VICENTE GUERRERO	2022-11-11 12:31:55	\N
11624	21	196	XAYACATLAN DE BRAVO	2022-11-11 12:31:55	\N
11625	21	197	XICOTEPEC	2022-11-11 12:31:55	\N
11626	21	198	XICOTLAN	2022-11-11 12:31:55	\N
11627	21	199	XIUTETELCO	2022-11-11 12:31:55	\N
11628	21	200	XOCHIAPULCO	2022-11-11 12:31:55	\N
11629	21	201	XOCHILTEPEC	2022-11-11 12:31:55	\N
11630	21	202	XOCHITLAN DE VICENTE SUAREZ	2022-11-11 12:31:55	\N
11631	21	203	XOCHITLAN TODOS SANTOS	2022-11-11 12:31:55	\N
11632	21	204	YAONAHUAC	2022-11-11 12:31:55	\N
11633	21	205	YEHUALTEPEC	2022-11-11 12:31:55	\N
11634	21	206	ZACAPALA	2022-11-11 12:31:55	\N
11635	21	207	ZACAPOAXTLA	2022-11-11 12:31:55	\N
11636	21	208	ZACATLAN	2022-11-11 12:31:55	\N
11637	21	209	ZAPOTITLAN	2022-11-11 12:31:55	\N
11638	21	210	ZAPOTITLAN DE MENDEZ	2022-11-11 12:31:55	\N
11639	21	211	ZARAGOZA	2022-11-11 12:31:55	\N
11640	21	212	ZAUTLA	2022-11-11 12:31:55	\N
11641	21	213	ZIHUATEUTLA	2022-11-11 12:31:55	\N
11642	21	214	ZINACATEPEC	2022-11-11 12:31:55	\N
11643	21	215	ZONGOZOTLA	2022-11-11 12:31:55	\N
11644	21	216	ZOQUIAPAN	2022-11-11 12:31:55	\N
11645	21	217	ZOQUITLAN	2022-11-11 12:31:55	\N
11646	21	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11647	22	1	AMEALCO DE BONFIL	2022-11-11 12:31:55	\N
11648	22	2	PINAL DE AMOLES	2022-11-11 12:31:55	\N
11649	22	3	ARROYO SECO	2022-11-11 12:31:55	\N
11650	22	4	CADEREYTA DE MONTES	2022-11-11 12:31:55	\N
11651	22	5	COLON	2022-11-11 12:31:55	\N
11652	22	6	CORREGIDORA	2022-11-11 12:31:55	\N
11653	22	7	EZEQUIEL MONTES	2022-11-11 12:31:55	\N
11654	22	8	HUIMILPAN	2022-11-11 12:31:55	\N
11655	22	9	JALPAN DE SERRA	2022-11-11 12:31:55	\N
11656	22	10	LANDA DE MATAMOROS	2022-11-11 12:31:55	\N
11657	22	11	MARQUES, EL	2022-11-11 12:31:55	\N
11658	22	12	PEDRO ESCOBEDO	2022-11-11 12:31:55	\N
11659	22	13	PEÑAMILLER	2022-11-11 12:31:55	\N
11660	22	14	QUERETARO	2022-11-11 12:31:55	\N
11661	22	15	SAN JOAQUIN	2022-11-11 12:31:55	\N
11662	22	16	SAN JUAN DEL RIO	2022-11-11 12:31:55	\N
11663	22	17	TEQUISQUIAPAN	2022-11-11 12:31:55	\N
11664	22	18	TOLIMAN	2022-11-11 12:31:55	\N
11665	22	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11666	23	1	COZUMEL	2022-11-11 12:31:55	\N
11667	23	2	FELIPE CARRILLO PUERTO	2022-11-11 12:31:55	\N
11668	23	3	ISLA MUJERES	2022-11-11 12:31:55	\N
11669	23	4	OTHON POBLADO BLANCO	2022-11-11 12:31:55	\N
11670	23	5	BENITO JUAREZ	2022-11-11 12:31:55	\N
11671	23	6	JOSE MARIA MORELOS	2022-11-11 12:31:55	\N
11672	23	7	LAZARO CARDENAS	2022-11-11 12:31:55	\N
11673	23	8	SOLIDARIDAD	2022-11-11 12:31:55	\N
11674	23	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11675	24	1	AHUALULCO	2022-11-11 12:31:55	\N
11676	24	2	ALAQUINES	2022-11-11 12:31:55	\N
11677	24	3	AQUISMON	2022-11-11 12:31:55	\N
11678	24	4	ARMADILLO DE LOS INFANTE	2022-11-11 12:31:55	\N
11679	24	5	CARDENAS	2022-11-11 12:31:55	\N
11680	24	6	CATORCE	2022-11-11 12:31:55	\N
11681	24	7	CEDRAL	2022-11-11 12:31:55	\N
11682	24	8	CERRITOS	2022-11-11 12:31:55	\N
11683	24	9	CERRO DE SAN PEDRO	2022-11-11 12:31:55	\N
11684	24	10	CIUDAD DEL MAIZ	2022-11-11 12:31:55	\N
11685	24	11	CIUDAD FERNANDEZ	2022-11-11 12:31:55	\N
11686	24	12	TANCANHUITZ DE SANTOS	2022-11-11 12:31:55	\N
11687	24	13	CIUDAD VALLES	2022-11-11 12:31:55	\N
11688	24	14	COXCATLAN	2022-11-11 12:31:55	\N
11689	24	15	CHARCAS	2022-11-11 12:31:55	\N
11690	24	16	EBANO	2022-11-11 12:31:55	\N
11691	24	17	GUADALCAZAR	2022-11-11 12:31:55	\N
11692	24	18	HUEHUETLAN	2022-11-11 12:31:55	\N
11693	24	19	LAGUNILLAS	2022-11-11 12:31:55	\N
11694	24	20	MATEHUALA	2022-11-11 12:31:55	\N
11695	24	21	MEXQUITIC DE CARMONA	2022-11-11 12:31:55	\N
11696	24	22	MOCTEZUMA	2022-11-11 12:31:55	\N
11697	24	23	RAYON	2022-11-11 12:31:55	\N
11698	24	24	RIOVERDE	2022-11-11 12:31:55	\N
11699	24	25	SALINAS	2022-11-11 12:31:55	\N
11700	24	26	SAN ANTONIO	2022-11-11 12:31:55	\N
11701	24	27	SAN CIRO DE ACOSTA	2022-11-11 12:31:55	\N
11702	24	28	SAN LUIS POTOSI	2022-11-11 12:31:55	\N
11703	24	29	SAN MARTIN CHALCHICUAUTLA	2022-11-11 12:31:55	\N
11704	24	30	SAN NICOLAS TOLENTINO	2022-11-11 12:31:55	\N
11705	24	31	SANTA CATARINA	2022-11-11 12:31:55	\N
11706	24	32	SANTA MARIA DEL RIO	2022-11-11 12:31:55	\N
11707	24	33	SANTO DOMINGO	2022-11-11 12:31:55	\N
11708	24	34	SAN VICENTE TANCUAYALAB	2022-11-11 12:31:55	\N
11709	24	35	SOLEDAD DE GRACIANO SANCHEZ	2022-11-11 12:31:55	\N
11710	24	36	TAMASOPO	2022-11-11 12:31:55	\N
11711	24	37	TAMAZUNCHALE	2022-11-11 12:31:55	\N
11712	24	38	TAMPACAN	2022-11-11 12:31:55	\N
11713	24	39	TAMPAMOLON CORONA	2022-11-11 12:31:55	\N
11714	24	40	TAMUIN	2022-11-11 12:31:55	\N
11715	24	41	TANLAJAS	2022-11-11 12:31:55	\N
11716	24	42	TANQUIAN DE ESCOBEDO	2022-11-11 12:31:55	\N
11717	24	43	TIERRANUEVA	2022-11-11 12:31:55	\N
11718	24	44	VANEGAS	2022-11-11 12:31:55	\N
11719	24	45	VENADO	2022-11-11 12:31:55	\N
11720	24	46	VILLA DE ARRIAGA	2022-11-11 12:31:55	\N
11721	24	47	VILLA DE GUADALUPE	2022-11-11 12:31:55	\N
11722	24	48	VILLA DE LA PAZ	2022-11-11 12:31:55	\N
11723	24	49	VILLA DE RAMOS	2022-11-11 12:31:55	\N
11724	24	50	VILLA DE REYES	2022-11-11 12:31:55	\N
11725	24	51	VILLA HIDALGO	2022-11-11 12:31:55	\N
11726	24	52	VILLA JUAREZ	2022-11-11 12:31:55	\N
11727	24	53	AXTLA DE TERRAZAS	2022-11-11 12:31:55	\N
11728	24	54	XILITLA	2022-11-11 12:31:55	\N
11729	24	55	ZARAGOZA	2022-11-11 12:31:55	\N
11730	24	56	VILLA DE ARISTA	2022-11-11 12:31:55	\N
11731	24	57	MATLAPA	2022-11-11 12:31:55	\N
11732	24	58	NARANJO, EL	2022-11-11 12:31:55	\N
11733	24	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11734	25	1	AHOME	2022-11-11 12:31:55	\N
11735	25	2	ANGOSTURA	2022-11-11 12:31:55	\N
11736	25	3	BADIRAGUATO	2022-11-11 12:31:55	\N
11737	25	4	CONCORDIA	2022-11-11 12:31:55	\N
11738	25	5	COSALA	2022-11-11 12:31:55	\N
11739	25	6	CULIACAN	2022-11-11 12:31:55	\N
11740	25	7	CHOIX	2022-11-11 12:31:55	\N
11741	25	8	ELOTA	2022-11-11 12:31:55	\N
11742	25	9	ESCUINAPA	2022-11-11 12:31:55	\N
11743	25	10	FUERTE, EL	2022-11-11 12:31:55	\N
11744	25	11	GUASAVE	2022-11-11 12:31:55	\N
11745	25	12	MAZATLAN	2022-11-11 12:31:55	\N
11746	25	13	MOCORITO	2022-11-11 12:31:55	\N
11747	25	14	ROSARIO	2022-11-11 12:31:55	\N
11748	25	15	SALVADOR ALVARADO	2022-11-11 12:31:55	\N
11749	25	16	SAN IGNACIO	2022-11-11 12:31:55	\N
11750	25	17	SINALOA	2022-11-11 12:31:55	\N
11751	25	18	NAVOLATO	2022-11-11 12:31:55	\N
11752	25	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11753	26	1	ACONCHI	2022-11-11 12:31:55	\N
11754	26	2	AGUA PRIETA	2022-11-11 12:31:55	\N
11755	26	3	ALAMOS	2022-11-11 12:31:55	\N
11756	26	4	ALTAR	2022-11-11 12:31:55	\N
11757	26	5	ARIVECHI	2022-11-11 12:31:55	\N
11758	26	6	ARIZPE	2022-11-11 12:31:55	\N
11759	26	7	ATIL	2022-11-11 12:31:55	\N
11760	26	8	BACADEHUACHI	2022-11-11 12:31:55	\N
11761	26	9	BACANORA	2022-11-11 12:31:55	\N
11762	26	10	BACERAC	2022-11-11 12:31:55	\N
11763	26	11	BACOACHI	2022-11-11 12:31:55	\N
11764	26	12	BACUM	2022-11-11 12:31:55	\N
11765	26	13	BANAMICHI	2022-11-11 12:31:55	\N
11766	26	14	BAVIACORA	2022-11-11 12:31:55	\N
11767	26	15	BAVISPE	2022-11-11 12:31:55	\N
11768	26	16	BENJAMIN HILL	2022-11-11 12:31:55	\N
11769	26	17	CABORCA	2022-11-11 12:31:55	\N
11770	26	18	CAJEME	2022-11-11 12:31:55	\N
11771	26	19	CANANEA	2022-11-11 12:31:55	\N
11772	26	20	CARBO	2022-11-11 12:31:55	\N
11773	26	21	COLORADA, LA	2022-11-11 12:31:55	\N
11774	26	22	CUCURPE	2022-11-11 12:31:55	\N
11775	26	23	CUMPAS	2022-11-11 12:31:55	\N
11776	26	24	DIVISADEROS	2022-11-11 12:31:55	\N
11777	26	25	EMPALME	2022-11-11 12:31:55	\N
11778	26	26	ETCHOJOA	2022-11-11 12:31:55	\N
11779	26	27	FRONTERAS	2022-11-11 12:31:55	\N
11780	26	28	GRANADOS	2022-11-11 12:31:55	\N
11781	26	29	GUAYMAS	2022-11-11 12:31:55	\N
11782	26	30	HERMOSILLO	2022-11-11 12:31:55	\N
11783	26	31	HUACHINERA	2022-11-11 12:31:55	\N
11784	26	32	HUASABAS	2022-11-11 12:31:55	\N
11785	26	33	HUATABAMPO	2022-11-11 12:31:55	\N
11786	26	34	HUEPAC	2022-11-11 12:31:55	\N
11787	26	35	IMURIS	2022-11-11 12:31:55	\N
11788	26	36	MAGDALENA	2022-11-11 12:31:55	\N
11789	26	37	MAZATAN	2022-11-11 12:31:55	\N
11790	26	38	MOCTEZUMA	2022-11-11 12:31:55	\N
11791	26	39	NACO	2022-11-11 12:31:55	\N
11792	26	40	NACORI CHICO	2022-11-11 12:31:55	\N
11793	26	41	NACOZARI DE GARCIA	2022-11-11 12:31:55	\N
11794	26	42	NAVOJOA	2022-11-11 12:31:55	\N
11795	26	43	NOGALES	2022-11-11 12:31:55	\N
11796	26	44	ONAVAS	2022-11-11 12:31:55	\N
11797	26	45	OPODEPE	2022-11-11 12:31:55	\N
11798	26	46	OQUITOA	2022-11-11 12:31:55	\N
11799	26	47	PITIQUITO	2022-11-11 12:31:55	\N
11800	26	48	PUERTO PEÑASCO	2022-11-11 12:31:55	\N
11801	26	49	QUIRIEGO	2022-11-11 12:31:55	\N
11802	26	50	RAYON	2022-11-11 12:31:55	\N
11803	26	51	ROSARIO	2022-11-11 12:31:55	\N
11804	26	52	SAHUARIPA	2022-11-11 12:31:55	\N
11805	26	53	SAN FELIPE DE JESUS	2022-11-11 12:31:55	\N
11806	26	54	SAN JAVIER	2022-11-11 12:31:55	\N
11807	26	55	SAN LUIS RIO COLORADO	2022-11-11 12:31:55	\N
11808	26	56	SAN MIGUEL DE HORCASITAS	2022-11-11 12:31:55	\N
11809	26	57	SAN PEDRO DE LA CUEVA	2022-11-11 12:31:55	\N
11810	26	58	SANTA ANA	2022-11-11 12:31:55	\N
11811	26	59	SANTA CRUZ	2022-11-11 12:31:55	\N
11812	26	60	SARIC	2022-11-11 12:31:55	\N
11813	26	61	SOYOPA	2022-11-11 12:31:55	\N
11814	26	62	SUAQUI GRANDE	2022-11-11 12:31:55	\N
11815	26	63	TEPACHE	2022-11-11 12:31:55	\N
11816	26	64	TRINCHERAS	2022-11-11 12:31:55	\N
11817	26	65	TUBUTAMA	2022-11-11 12:31:55	\N
11818	26	66	URES	2022-11-11 12:31:55	\N
11819	26	67	VILLA HIDALGO	2022-11-11 12:31:55	\N
11820	26	68	VILLA PESQUEIRA	2022-11-11 12:31:55	\N
11821	26	69	YECORA	2022-11-11 12:31:55	\N
11822	26	70	GENERAL PLUTARCO ELIAS CALLES	2022-11-11 12:31:55	\N
11823	26	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11824	27	1	BALANCAN	2022-11-11 12:31:55	\N
11825	27	2	CARDENAS	2022-11-11 12:31:55	\N
11826	27	3	CENTLA	2022-11-11 12:31:55	\N
11827	27	4	CENTRO	2022-11-11 12:31:55	\N
11828	27	5	COMALCALCO	2022-11-11 12:31:55	\N
11829	27	6	CUNDUACAN	2022-11-11 12:31:55	\N
11830	27	7	EMILIANO ZAPATA	2022-11-11 12:31:55	\N
11831	27	8	HUIMANGUILLO	2022-11-11 12:31:55	\N
11832	27	9	JALAPA	2022-11-11 12:31:55	\N
11833	27	10	JALPA DE MENDEZ	2022-11-11 12:31:55	\N
11834	27	11	JONUTA	2022-11-11 12:31:55	\N
11835	27	12	MACUSPANA	2022-11-11 12:31:55	\N
11836	27	13	NACAJUCA	2022-11-11 12:31:55	\N
11837	27	14	PARAISO	2022-11-11 12:31:55	\N
11838	27	15	TACOTALPA	2022-11-11 12:31:55	\N
11839	27	16	TEAPA	2022-11-11 12:31:55	\N
11840	27	17	TENOSIQUE	2022-11-11 12:31:55	\N
11841	27	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11842	28	1	ABASOLO	2022-11-11 12:31:55	\N
11843	28	2	ALDAMA	2022-11-11 12:31:55	\N
11844	28	3	ALTAMIRA	2022-11-11 12:31:55	\N
11845	28	4	ANTIGUO MORELOS	2022-11-11 12:31:55	\N
11846	28	5	BURGOS	2022-11-11 12:31:55	\N
11847	28	6	BUSTAMANTE	2022-11-11 12:31:55	\N
11848	28	7	CAMARGO	2022-11-11 12:31:55	\N
11849	28	8	CASAS	2022-11-11 12:31:55	\N
11850	28	9	CIUDAD MADERO	2022-11-11 12:31:55	\N
11851	28	10	CRUILLAS	2022-11-11 12:31:55	\N
11852	28	11	GOMEZ FARIAS	2022-11-11 12:31:55	\N
11853	28	12	GONZALEZ	2022-11-11 12:31:55	\N
11854	28	13	GSEMEZ	2022-11-11 12:31:55	\N
11855	28	14	GUERRERO	2022-11-11 12:31:55	\N
11856	28	15	GUSTAVO DIAZ ORDAZ	2022-11-11 12:31:55	\N
11857	28	16	HIDALGO	2022-11-11 12:31:55	\N
11858	28	17	JAUMAVE	2022-11-11 12:31:55	\N
11859	28	18	JIMENEZ	2022-11-11 12:31:55	\N
11860	28	19	LLERA	2022-11-11 12:31:55	\N
11861	28	20	MAINERO	2022-11-11 12:31:55	\N
11862	28	21	MANTE,EL	2022-11-11 12:31:55	\N
11863	28	22	MATAMOROS	2022-11-11 12:31:55	\N
11864	28	23	MENDEZ	2022-11-11 12:31:55	\N
11865	28	24	MIER	2022-11-11 12:31:55	\N
11866	28	25	MIGUEL ALEMAN	2022-11-11 12:31:55	\N
11867	28	26	MIQUIHUANA	2022-11-11 12:31:55	\N
11868	28	27	NUEVO LAREDO	2022-11-11 12:31:55	\N
11869	28	28	NUEVO MORELOS	2022-11-11 12:31:55	\N
11870	28	29	OCAMPO	2022-11-11 12:31:55	\N
11871	28	30	PADILLA	2022-11-11 12:31:55	\N
11872	28	31	PALMILLAS	2022-11-11 12:31:55	\N
11873	28	32	REYNOSA	2022-11-11 12:31:55	\N
11874	28	33	RIO BRAVO	2022-11-11 12:31:55	\N
11875	28	34	SAN CARLOS	2022-11-11 12:31:55	\N
11876	28	35	SAN FERNANDO	2022-11-11 12:31:55	\N
11877	28	36	SAN NICOLAS	2022-11-11 12:31:55	\N
11878	28	37	SOTO LA MARINA	2022-11-11 12:31:55	\N
11879	28	38	TAMPICO	2022-11-11 12:31:55	\N
11880	28	39	TULA	2022-11-11 12:31:55	\N
11881	28	40	VALLE HERMOSO	2022-11-11 12:31:55	\N
11882	28	41	VICTORIA	2022-11-11 12:31:55	\N
11883	28	42	VILLAGRAN	2022-11-11 12:31:55	\N
11884	28	43	XICOTENCATL	2022-11-11 12:31:55	\N
11885	28	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11886	29	1	AMAXAC DE GUERRERO	2022-11-11 12:31:55	\N
11887	29	2	APETATITLAN DE ANTONIO CARVAJA	2022-11-11 12:31:55	\N
11888	29	3	ATLANGATEPEC	2022-11-11 12:31:55	\N
11889	29	4	ALTZAYANCA	2022-11-11 12:31:55	\N
11890	29	5	APIZACO	2022-11-11 12:31:55	\N
11891	29	6	CALPULALPAN	2022-11-11 12:31:55	\N
11892	29	7	CARMEN TEQUEXQUITLA, EL	2022-11-11 12:31:55	\N
11893	29	8	CUAPIAXTLA	2022-11-11 12:31:55	\N
11894	29	9	CUAXOMULCO	2022-11-11 12:31:55	\N
11895	29	10	CHIAUTEMPAN	2022-11-11 12:31:55	\N
11896	29	11	MUÑOZ DE DOMINGO ARENAS	2022-11-11 12:31:55	\N
11897	29	12	ESPAÑITA	2022-11-11 12:31:55	\N
11898	29	13	HUAMANTLA	2022-11-11 12:31:55	\N
11899	29	14	HUEYOTLIPAN	2022-11-11 12:31:55	\N
11900	29	15	IXTACUIXTLA DE MARIANO MATAMOR	2022-11-11 12:31:55	\N
11901	29	16	IXTENCO	2022-11-11 12:31:55	\N
11902	29	17	MAZATECOCHCO DE JOSE MARIA MOR	2022-11-11 12:31:55	\N
11903	29	18	CONTLA DE JUAN CUAMATZI	2022-11-11 12:31:55	\N
11904	29	19	TEPETITLA DE LARDIZABAL	2022-11-11 12:31:55	\N
11905	29	20	SANCTORUM DE LAZARO CARDENAS	2022-11-11 12:31:55	\N
11906	29	21	NANACAMILPA DE MARIANO ARISTA	2022-11-11 12:31:55	\N
11907	29	22	ACUAMANALA DE MIGUEL HIDALGO	2022-11-11 12:31:55	\N
11908	29	23	NATIVITAS	2022-11-11 12:31:55	\N
11909	29	24	PANOTLA	2022-11-11 12:31:55	\N
11910	29	25	SAN PABLO DEL MONTE	2022-11-11 12:31:55	\N
11911	29	26	SANTA CRUZ TLAXCALA	2022-11-11 12:31:55	\N
11912	29	27	TENANCINGO	2022-11-11 12:31:55	\N
11913	29	28	TEOLOCHOLCO	2022-11-11 12:31:55	\N
11914	29	29	TEPEYANCO	2022-11-11 12:31:55	\N
11915	29	30	TERRENATE	2022-11-11 12:31:55	\N
11916	29	31	TETLA	2022-11-11 12:31:55	\N
11917	29	32	TETLATLAHUCA	2022-11-11 12:31:55	\N
11918	29	33	TLAXCALA	2022-11-11 12:31:55	\N
11919	29	34	TLAXCO	2022-11-11 12:31:55	\N
11920	29	35	TOCATLAN	2022-11-11 12:31:55	\N
11921	29	36	TOTOLAC	2022-11-11 12:31:55	\N
11922	29	37	ZITLALTEPEC DE TRINIDAD SANCHE	2022-11-11 12:31:55	\N
11923	29	38	TZOMPANTEPEC	2022-11-11 12:31:55	\N
11924	29	39	XALOZTOC	2022-11-11 12:31:55	\N
11925	29	40	XALTOCAN	2022-11-11 12:31:55	\N
11926	29	41	PAPALOTLA DE XICOHTENCATL	2022-11-11 12:31:55	\N
11927	29	42	XICOTZINGO	2022-11-11 12:31:55	\N
11928	29	43	YAUHQUEMEHCAN	2022-11-11 12:31:55	\N
11929	29	44	ZACATELCO	2022-11-11 12:31:55	\N
11930	29	45	BENITO JUAREZ	2022-11-11 12:31:55	\N
11931	29	46	EMILIANO ZAPATA	2022-11-11 12:31:55	\N
11932	29	47	LAZARO CARDENAS	2022-11-11 12:31:55	\N
11933	29	48	MAGDALENA TLALTELULCO, LA	2022-11-11 12:31:55	\N
11934	29	49	SAN DAMIAN TEXOLOC	2022-11-11 12:31:55	\N
11935	29	50	SAN FRANCISCO TETLANOHCAN	2022-11-11 12:31:55	\N
11936	29	51	SAN JERONIMO ZACUALPAN	2022-11-11 12:31:55	\N
11937	29	52	SAN JOSE TEACALCO	2022-11-11 12:31:55	\N
11938	29	53	SAN JUAN HUACTZINGO	2022-11-11 12:31:55	\N
11939	29	54	SAN LORENZO AXOCOMANITLA	2022-11-11 12:31:55	\N
11940	29	55	SAN LUCAS TECOPILCO	2022-11-11 12:31:55	\N
11941	29	56	SANTA ANA NOPALUCAN	2022-11-11 12:31:55	\N
11942	29	57	SANTA APOLONIA TEACALCO	2022-11-11 12:31:55	\N
11943	29	58	SANTA CATARINA AYOMETLA	2022-11-11 12:31:55	\N
11944	29	59	SANTA CRUZ QUILEHTLA	2022-11-11 12:31:55	\N
11945	29	60	SANTA ISABEL XILOXOXTLA	2022-11-11 12:31:55	\N
11946	29	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
11947	30	1	ACAJETE	2022-11-11 12:31:55	\N
11948	30	2	ACATLAN	2022-11-11 12:31:55	\N
11949	30	3	ACAYUCAN	2022-11-11 12:31:55	\N
11950	30	4	ACTOPAN	2022-11-11 12:31:55	\N
11951	30	5	ACULA	2022-11-11 12:31:55	\N
11952	30	6	ACULTZINGO	2022-11-11 12:31:55	\N
11953	30	7	CAMARON DE TEJEDA	2022-11-11 12:31:55	\N
11954	30	8	ALPATLAHUAC	2022-11-11 12:31:55	\N
11955	30	9	ALTO LUCERO	2022-11-11 12:31:55	\N
11956	30	10	ALTOTONGA	2022-11-11 12:31:55	\N
11957	30	11	ALVARADO	2022-11-11 12:31:55	\N
11958	30	12	AMATITLAN	2022-11-11 12:31:55	\N
11959	30	13	AMATLAN TUXPAN	2022-11-11 12:31:55	\N
11960	30	14	AMATLAN DE LOS REYES	2022-11-11 12:31:55	\N
11961	30	15	ANGEL R. CABADA	2022-11-11 12:31:55	\N
11962	30	16	ANTIGUA, LA	2022-11-11 12:31:55	\N
11963	30	17	APAZAPAN	2022-11-11 12:31:55	\N
11964	30	18	AQUILA	2022-11-11 12:31:55	\N
11965	30	19	ASTACINGA	2022-11-11 12:31:55	\N
11966	30	20	ATLAHUILCO	2022-11-11 12:31:55	\N
11967	30	21	ATOYAC	2022-11-11 12:31:55	\N
11968	30	22	ATZACAN	2022-11-11 12:31:55	\N
11969	30	23	ATZALAN	2022-11-11 12:31:55	\N
11970	30	24	TLALTETELA	2022-11-11 12:31:55	\N
11971	30	25	AYAHUALULCO	2022-11-11 12:31:55	\N
11972	30	26	BANDERILLA	2022-11-11 12:31:55	\N
11973	30	27	BENITO JUAREZ	2022-11-11 12:31:55	\N
11974	30	28	BOCA DEL RIO	2022-11-11 12:31:55	\N
11975	30	29	CALCAHUALCO	2022-11-11 12:31:55	\N
11976	30	30	CAMERINO Z. MENDOZA	2022-11-11 12:31:55	\N
11977	30	31	CARRILLO PUERTO	2022-11-11 12:31:55	\N
11978	30	32	CATEMACO	2022-11-11 12:31:55	\N
11979	30	33	CAZONES DE HERRERA	2022-11-11 12:31:55	\N
11980	30	34	CERRO AZUL	2022-11-11 12:31:55	\N
11981	30	35	CITLALTEPETL	2022-11-11 12:31:55	\N
11982	30	36	COACOATZINTLA	2022-11-11 12:31:55	\N
11983	30	37	COAHUITLAN	2022-11-11 12:31:55	\N
11984	30	38	COATEPEC	2022-11-11 12:31:55	\N
11985	30	39	COATZACOALCOS	2022-11-11 12:31:55	\N
11986	30	40	COATZINTLA	2022-11-11 12:31:55	\N
11987	30	41	COETZALA	2022-11-11 12:31:55	\N
11988	30	42	COLIPA	2022-11-11 12:31:55	\N
11989	30	43	COMAPA	2022-11-11 12:31:55	\N
11990	30	44	CORDOBA	2022-11-11 12:31:55	\N
11991	30	45	COSAMALOAPAN	2022-11-11 12:31:55	\N
11992	30	46	COSAUTLAN DE CARVAJAL	2022-11-11 12:31:55	\N
11993	30	47	COSCOMATEPEC	2022-11-11 12:31:55	\N
11994	30	48	COSOLEACAQUE	2022-11-11 12:31:55	\N
11995	30	49	COTAXTLA	2022-11-11 12:31:55	\N
11996	30	50	COXQUIHUI	2022-11-11 12:31:55	\N
11997	30	51	COYUTLA	2022-11-11 12:31:55	\N
11998	30	52	CUICHAPA	2022-11-11 12:31:55	\N
11999	30	53	CUITLAHUAC	2022-11-11 12:31:55	\N
12000	30	54	CHACALTIANGUIS	2022-11-11 12:31:55	\N
12001	30	55	CHALMA	2022-11-11 12:31:55	\N
12002	30	56	CHICONAMEL	2022-11-11 12:31:55	\N
12003	30	57	CHICONQUIACO	2022-11-11 12:31:55	\N
12004	30	58	CHICONTEPEC	2022-11-11 12:31:55	\N
12005	30	59	CHINAMECA	2022-11-11 12:31:55	\N
12006	30	60	CHINAMPA DE GOROSTIZA	2022-11-11 12:31:55	\N
12007	30	61	LAS CHOAPAS	2022-11-11 12:31:55	\N
12008	30	62	CHOCAMAN	2022-11-11 12:31:55	\N
12009	30	63	CHONTLA	2022-11-11 12:31:55	\N
12010	30	64	CHUMATLAN	2022-11-11 12:31:55	\N
12011	30	65	EMILIANO ZAPATA	2022-11-11 12:31:55	\N
12012	30	66	ESPINAL	2022-11-11 12:31:55	\N
12013	30	67	FILOMENO MATA	2022-11-11 12:31:55	\N
12014	30	68	FORTIN	2022-11-11 12:31:55	\N
12015	30	69	GUTIERREZ ZAMORA	2022-11-11 12:31:55	\N
12016	30	70	HIDALGOTITLAN	2022-11-11 12:31:55	\N
12017	30	71	HUATUSCO	2022-11-11 12:31:55	\N
12018	30	72	HUAYACOCOTLA	2022-11-11 12:31:55	\N
12019	30	73	HUEYAPAN DE OCAMPO	2022-11-11 12:31:55	\N
12020	30	74	HUILOAPAN DE CUAUHTEMOC	2022-11-11 12:31:55	\N
12021	30	75	IGNACIO DE LA LLAVE	2022-11-11 12:31:55	\N
12022	30	76	ILAMATLAN	2022-11-11 12:31:55	\N
12023	30	77	ISLA	2022-11-11 12:31:55	\N
12024	30	78	IXCATEPEC	2022-11-11 12:31:55	\N
12025	30	79	IXHUACAN DE LOS REYES	2022-11-11 12:31:55	\N
12026	30	80	IXHUATLAN DEL CAFE	2022-11-11 12:31:55	\N
12027	30	81	IXHUATLANCILLO	2022-11-11 12:31:55	\N
12028	30	82	IXHUATLAN DEL SURESTE	2022-11-11 12:31:55	\N
12029	30	83	IXHUATLAN DE MADERO	2022-11-11 12:31:55	\N
12030	30	84	IXMATLAHUACAN	2022-11-11 12:31:55	\N
12031	30	85	IXTACZOQUITLAN	2022-11-11 12:31:55	\N
12032	30	86	JALACINGO	2022-11-11 12:31:55	\N
12033	30	87	XALAPA	2022-11-11 12:31:55	\N
12034	30	88	JALCOMULCO	2022-11-11 12:31:55	\N
12035	30	89	JALTIPAN	2022-11-11 12:31:55	\N
12036	30	90	JAMAPA	2022-11-11 12:31:55	\N
12037	30	91	JESUS CARRANZA	2022-11-11 12:31:55	\N
12038	30	92	XICO	2022-11-11 12:31:55	\N
12039	30	93	JILOTEPEC	2022-11-11 12:31:55	\N
12040	30	94	JUAN RODRIGUEZ CLARA	2022-11-11 12:31:55	\N
12041	30	95	JUCHIQUE DE FERRER	2022-11-11 12:31:55	\N
12042	30	96	LANDERO Y COSS	2022-11-11 12:31:55	\N
12043	30	97	LERDO DE TEJADA	2022-11-11 12:31:55	\N
12044	30	98	MAGDALENA	2022-11-11 12:31:55	\N
12045	30	99	MALTRATA	2022-11-11 12:31:55	\N
12046	30	100	MANLIO FABIO ALTAMIRANO	2022-11-11 12:31:55	\N
12047	30	101	MARIANO ESCOBEDO	2022-11-11 12:31:55	\N
12048	30	102	MARTINEZ DE LA TORRE	2022-11-11 12:31:55	\N
12049	30	103	MECATLAN	2022-11-11 12:31:55	\N
12050	30	104	MECAYAPAN	2022-11-11 12:31:55	\N
12051	30	105	MEDELLIN	2022-11-11 12:31:55	\N
12052	30	106	MIAHUATLAN	2022-11-11 12:31:55	\N
12053	30	107	MINAS, LAS	2022-11-11 12:31:55	\N
12054	30	108	MINATITLAN	2022-11-11 12:31:55	\N
12055	30	109	MISANTLA	2022-11-11 12:31:55	\N
12056	30	110	MIXTLA DE ALTAMIRANO	2022-11-11 12:31:55	\N
12057	30	111	MOLOACAN	2022-11-11 12:31:55	\N
12058	30	112	NAOLINCO	2022-11-11 12:31:55	\N
12059	30	113	NARANJAL	2022-11-11 12:31:55	\N
12060	30	114	NAUTLA	2022-11-11 12:31:55	\N
12061	30	115	NOGALES	2022-11-11 12:31:55	\N
12062	30	116	OLUTA	2022-11-11 12:31:55	\N
12063	30	117	OMEALCA	2022-11-11 12:31:55	\N
12064	30	118	ORIZABA	2022-11-11 12:31:55	\N
12065	30	119	OTATITLAN	2022-11-11 12:31:55	\N
12066	30	120	OTEAPAN	2022-11-11 12:31:55	\N
12067	30	121	OZULUAMA	2022-11-11 12:31:55	\N
12068	30	122	PAJAPAN	2022-11-11 12:31:55	\N
12069	30	123	PANUCO	2022-11-11 12:31:55	\N
12070	30	124	PAPANTLA	2022-11-11 12:31:55	\N
12071	30	125	PASO DEL MACHO	2022-11-11 12:31:55	\N
12072	30	126	PASO DE OVEJAS	2022-11-11 12:31:55	\N
12073	30	127	PERLA, LA	2022-11-11 12:31:55	\N
12074	30	128	PEROTE	2022-11-11 12:31:55	\N
12075	30	129	PLATON SANCHEZ	2022-11-11 12:31:55	\N
12076	30	130	PLAYA VICENTE	2022-11-11 12:31:55	\N
12077	30	131	POZA RICA DE HIDALGO	2022-11-11 12:31:55	\N
12078	30	132	VIGAS DE RAMIREZ, LAS	2022-11-11 12:31:55	\N
12079	30	133	PUEBLO VIEJO	2022-11-11 12:31:55	\N
12080	30	134	PUENTE NACIONAL	2022-11-11 12:31:55	\N
12081	30	135	RAFAEL DELGADO	2022-11-11 12:31:55	\N
12082	30	136	RAFAEL LUCIO	2022-11-11 12:31:55	\N
12083	30	137	REYES, LOS	2022-11-11 12:31:55	\N
12084	30	138	RIO BLANCO	2022-11-11 12:31:55	\N
12085	30	139	SALTABARRANCA	2022-11-11 12:31:55	\N
12086	30	140	SAN ANDRES TENEJAPAN	2022-11-11 12:31:55	\N
12087	30	141	SAN ANDRES TUXTLA	2022-11-11 12:31:55	\N
12088	30	142	SAN JUAN EVANGELISTA	2022-11-11 12:31:55	\N
12089	30	143	SANTIAGO TUXTLA	2022-11-11 12:31:55	\N
12090	30	144	SAYULA DE ALEMÁN	2022-11-11 12:31:55	\N
12091	30	145	SOCONUSCO	2022-11-11 12:31:55	\N
12092	30	146	SOCHIAPA	2022-11-11 12:31:55	\N
12093	30	147	SOLEDAD ATZOMPA	2022-11-11 12:31:55	\N
12094	30	148	SOLEDAD DE DOBLADO	2022-11-11 12:31:55	\N
12095	30	149	SOTEAPAN	2022-11-11 12:31:55	\N
12096	30	150	TAMALIN	2022-11-11 12:31:55	\N
12097	30	151	TAMIAHUA	2022-11-11 12:31:55	\N
12098	30	152	TAMPICO ALTO	2022-11-11 12:31:55	\N
12099	30	153	TANCOCO	2022-11-11 12:31:55	\N
12100	30	154	TANTIMA	2022-11-11 12:31:55	\N
12101	30	155	TANTOYUCA	2022-11-11 12:31:55	\N
12102	30	156	TATATILA	2022-11-11 12:31:55	\N
12103	30	157	CASTILLO DE TEAYO	2022-11-11 12:31:55	\N
12104	30	158	TECOLUTLA	2022-11-11 12:31:55	\N
12105	30	159	TEHUIPANGO	2022-11-11 12:31:55	\N
12106	30	160	TEMAPACHE	2022-11-11 12:31:55	\N
12107	30	161	TEMPOAL	2022-11-11 12:31:55	\N
12108	30	162	TENAMPA	2022-11-11 12:31:55	\N
12109	30	163	TENOCHTITLAN	2022-11-11 12:31:55	\N
12110	30	164	TEOCELO	2022-11-11 12:31:55	\N
12111	30	165	TEPATLAXCO	2022-11-11 12:31:55	\N
12112	30	166	TEPETLAN	2022-11-11 12:31:55	\N
12113	30	167	TEPETZINTLA	2022-11-11 12:31:55	\N
12114	30	168	TEQUILA	2022-11-11 12:31:55	\N
12115	30	169	JOSE AZUETA	2022-11-11 12:31:55	\N
12116	30	170	TEXCATEPEC	2022-11-11 12:31:55	\N
12117	30	171	TEXHUACAN	2022-11-11 12:31:55	\N
12118	30	172	TEXISTEPEC	2022-11-11 12:31:55	\N
12119	30	173	TEZONAPA	2022-11-11 12:31:55	\N
12120	30	174	TIERRA BLANCA	2022-11-11 12:31:55	\N
12121	30	175	TIHUATLAN	2022-11-11 12:31:55	\N
12122	30	176	TLACOJALPAN	2022-11-11 12:31:55	\N
12123	30	177	TLACOLULAN	2022-11-11 12:31:55	\N
12124	30	178	TLACOTALPAN	2022-11-11 12:31:55	\N
12125	30	179	TLACOTEPEC DE MEJIA	2022-11-11 12:31:55	\N
12126	30	180	TLACHICHILCO	2022-11-11 12:31:55	\N
12127	30	181	TLALIXCOYAN	2022-11-11 12:31:55	\N
12128	30	182	TLALNELHUAYOCAN	2022-11-11 12:31:55	\N
12129	30	183	TLAPACOYAN	2022-11-11 12:31:55	\N
12130	30	184	TLAQUILPAN	2022-11-11 12:31:55	\N
12131	30	185	TLILAPAN	2022-11-11 12:31:55	\N
12132	30	186	TOMATLAN	2022-11-11 12:31:55	\N
12133	30	187	TONAYAN	2022-11-11 12:31:55	\N
12134	30	188	TOTUTLA	2022-11-11 12:31:55	\N
12135	30	189	TUXPAM	2022-11-11 12:31:55	\N
12136	30	190	TUXTILLA	2022-11-11 12:31:55	\N
12137	30	191	URSULO GALVAN	2022-11-11 12:31:55	\N
12138	30	192	VEGA DE ALATORRE	2022-11-11 12:31:55	\N
12139	30	193	VERACRUZ	2022-11-11 12:31:55	\N
12140	30	194	VILLA ALDAMA	2022-11-11 12:31:55	\N
12141	30	195	XOXOCOTLA	2022-11-11 12:31:55	\N
12142	30	196	YANGA	2022-11-11 12:31:55	\N
12143	30	197	YECUATLAN	2022-11-11 12:31:55	\N
12144	30	198	ZACUALPAN	2022-11-11 12:31:55	\N
12145	30	199	ZARAGOZA	2022-11-11 12:31:55	\N
12146	30	200	ZENTLA	2022-11-11 12:31:55	\N
12147	30	201	ZONGOLICA	2022-11-11 12:31:55	\N
12148	30	202	ZONTECOMATLAN	2022-11-11 12:31:55	\N
12149	30	203	ZOZOCOLCO DE HIDALGO	2022-11-11 12:31:55	\N
12150	30	204	AGUA DULCE	2022-11-11 12:31:55	\N
12151	30	205	HIGO, EL	2022-11-11 12:31:55	\N
12152	30	206	NANCHITAL DE LAZARO CARDENAS D	2022-11-11 12:31:55	\N
12153	30	207	TRES VALLES	2022-11-11 12:31:55	\N
12154	30	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
12155	31	1	ABALA	2022-11-11 12:31:55	\N
12156	31	2	ACANCEH	2022-11-11 12:31:55	\N
12157	31	3	AKIL	2022-11-11 12:31:55	\N
12158	31	4	BACA	2022-11-11 12:31:55	\N
12159	31	5	BOKOBA	2022-11-11 12:31:55	\N
12160	31	6	BUCTZOTZ	2022-11-11 12:31:55	\N
12161	31	7	CACALCHEN	2022-11-11 12:31:55	\N
12162	31	8	CALOTMUL	2022-11-11 12:31:55	\N
12163	31	9	CANSAHCAB	2022-11-11 12:31:55	\N
12164	31	10	CANTAMAYEC	2022-11-11 12:31:55	\N
12165	31	11	CELESTUN	2022-11-11 12:31:55	\N
12166	31	12	CENOTILLO	2022-11-11 12:31:55	\N
12167	31	13	CONKAL	2022-11-11 12:31:55	\N
12168	31	14	CUNCUNUL	2022-11-11 12:31:55	\N
12169	31	15	CUZAMA	2022-11-11 12:31:55	\N
12170	31	16	CHACSINKIN	2022-11-11 12:31:55	\N
12171	31	17	CHANKOM	2022-11-11 12:31:55	\N
12172	31	18	CHAPAB	2022-11-11 12:31:55	\N
12173	31	19	CHEMAX	2022-11-11 12:31:55	\N
12174	31	20	CHICXULUB PUEBLO	2022-11-11 12:31:55	\N
12175	31	21	CHICHIMILA	2022-11-11 12:31:55	\N
12176	31	22	CHIKINDZONOT	2022-11-11 12:31:55	\N
12177	31	23	CHOCHOLA	2022-11-11 12:31:55	\N
12178	31	24	CHUMAYEL	2022-11-11 12:31:55	\N
12179	31	25	DZAN	2022-11-11 12:31:55	\N
12180	31	26	DZEMUL	2022-11-11 12:31:55	\N
12181	31	27	DZIDZANTUN	2022-11-11 12:31:55	\N
12182	31	28	DZILAM DE BRAVO	2022-11-11 12:31:55	\N
12183	31	29	DZILAM GONZALEZ	2022-11-11 12:31:55	\N
12184	31	30	DZITAS	2022-11-11 12:31:55	\N
12185	31	31	DZONCAUICH	2022-11-11 12:31:55	\N
12186	31	32	ESPITA	2022-11-11 12:31:55	\N
12187	31	33	HALACHO	2022-11-11 12:31:55	\N
12188	31	34	HOCABA	2022-11-11 12:31:55	\N
12189	31	35	HOCTUN	2022-11-11 12:31:55	\N
12190	31	36	HOMUN	2022-11-11 12:31:55	\N
12191	31	37	HUHI	2022-11-11 12:31:55	\N
12192	31	38	HUNUCMA	2022-11-11 12:31:55	\N
12193	31	39	IXIL	2022-11-11 12:31:55	\N
12194	31	40	IZAMAL	2022-11-11 12:31:55	\N
12195	31	41	KANASIN	2022-11-11 12:31:55	\N
12196	31	42	KANTUNIL	2022-11-11 12:31:55	\N
12197	31	43	KAUA	2022-11-11 12:31:55	\N
12198	31	44	KINCHIL	2022-11-11 12:31:55	\N
12199	31	45	KOPOMA	2022-11-11 12:31:55	\N
12200	31	46	MAMA	2022-11-11 12:31:55	\N
12201	31	47	MANI	2022-11-11 12:31:55	\N
12202	31	48	MAXCANU	2022-11-11 12:31:55	\N
12203	31	49	MAYAPAN	2022-11-11 12:31:55	\N
12204	31	50	MERIDA	2022-11-11 12:31:55	\N
12205	31	51	MOCOCHA	2022-11-11 12:31:55	\N
12206	31	52	MOTUL	2022-11-11 12:31:55	\N
12207	31	53	MUNA	2022-11-11 12:31:55	\N
12208	31	54	MUXUPIP	2022-11-11 12:31:55	\N
12209	31	55	OPICHEN	2022-11-11 12:31:55	\N
12210	31	56	OXKUTZCAB	2022-11-11 12:31:55	\N
12211	31	57	PANABA	2022-11-11 12:31:55	\N
12212	31	58	PETO	2022-11-11 12:31:55	\N
12213	31	59	PROGRESO	2022-11-11 12:31:55	\N
12214	31	60	QUINTANA ROO	2022-11-11 12:31:55	\N
12215	31	61	RIO LAGARTOS	2022-11-11 12:31:55	\N
12216	31	62	SACALUM	2022-11-11 12:31:55	\N
12217	31	63	SAMAHIL	2022-11-11 12:31:55	\N
12218	31	64	SANAHCAT	2022-11-11 12:31:55	\N
12219	31	65	SAN FELIPE	2022-11-11 12:31:55	\N
12220	31	66	SANTA ELENA	2022-11-11 12:31:55	\N
12221	31	67	SEYE	2022-11-11 12:31:55	\N
12222	31	68	SINANCHE	2022-11-11 12:31:55	\N
12223	31	69	SOTUTA	2022-11-11 12:31:55	\N
12224	31	70	SUCILA	2022-11-11 12:31:55	\N
12225	31	71	SUDZAL	2022-11-11 12:31:55	\N
12226	31	72	SUMA	2022-11-11 12:31:55	\N
12227	31	73	TAHDZIU	2022-11-11 12:31:55	\N
12228	31	74	TAHMEK	2022-11-11 12:31:55	\N
12229	31	75	TEABO	2022-11-11 12:31:55	\N
12230	31	76	TECOH	2022-11-11 12:31:55	\N
12231	31	77	TEKAL DE VENEGAS	2022-11-11 12:31:55	\N
12232	31	78	TEKANTO	2022-11-11 12:31:55	\N
12233	31	79	TEKAX	2022-11-11 12:31:55	\N
12234	31	80	TEKIT	2022-11-11 12:31:55	\N
12235	31	81	TEKOM	2022-11-11 12:31:55	\N
12236	31	82	TELCHAC PUEBLO	2022-11-11 12:31:55	\N
12237	31	83	TELCHAC PUERTO	2022-11-11 12:31:55	\N
12238	31	84	TEMAX	2022-11-11 12:31:55	\N
12239	31	85	TEMOZON	2022-11-11 12:31:55	\N
12240	31	86	TEPAKAN	2022-11-11 12:31:55	\N
12241	31	87	TETIZ	2022-11-11 12:31:55	\N
12242	31	88	TEYA	2022-11-11 12:31:55	\N
12243	31	89	TICUL	2022-11-11 12:31:55	\N
12244	31	90	TIMUCUY	2022-11-11 12:31:55	\N
12245	31	91	TINUM	2022-11-11 12:31:55	\N
12246	31	92	TIXCACALCUPUL	2022-11-11 12:31:55	\N
12247	31	93	TIXKOKOB	2022-11-11 12:31:55	\N
12248	31	94	TIXMEHUAC	2022-11-11 12:31:55	\N
12249	31	95	TIXPEHUAL	2022-11-11 12:31:55	\N
12250	31	96	TIZIMIN	2022-11-11 12:31:55	\N
12251	31	97	TUNKAS	2022-11-11 12:31:55	\N
12252	31	98	TZUCACAB	2022-11-11 12:31:55	\N
12253	31	99	UAYMA	2022-11-11 12:31:55	\N
12254	31	100	UCU	2022-11-11 12:31:55	\N
12255	31	101	UMAN	2022-11-11 12:31:55	\N
12256	31	102	VALLADOLID	2022-11-11 12:31:55	\N
12257	31	103	XOCCHEL	2022-11-11 12:31:55	\N
12258	31	104	YAXCABA	2022-11-11 12:31:55	\N
12259	31	105	YAXKUKUL	2022-11-11 12:31:55	\N
12260	31	106	YOBAIN	2022-11-11 12:31:55	\N
12261	31	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
12262	32	1	APOZOL	2022-11-11 12:31:55	\N
12263	32	2	APULCO	2022-11-11 12:31:55	\N
12264	32	3	ATOLINGA	2022-11-11 12:31:55	\N
12265	32	4	BENITO JUAREZ	2022-11-11 12:31:55	\N
12266	32	5	CALERA	2022-11-11 12:31:55	\N
12267	32	6	CAÑITAS DE FELIPE PESCADOR	2022-11-11 12:31:55	\N
12268	32	7	CONCEPCION DEL ORO	2022-11-11 12:31:55	\N
12269	32	8	CUAUHTEMOC	2022-11-11 12:31:55	\N
12270	32	9	CHALCHIHUITES	2022-11-11 12:31:55	\N
12271	32	10	FRESNILLO	2022-11-11 12:31:55	\N
12272	32	11	TRINIDAD GARCIA DE LA CADENA	2022-11-11 12:31:55	\N
12273	32	12	GENARO CODINA	2022-11-11 12:31:55	\N
12274	32	13	GENERAL ENRIQUE ESTRADA	2022-11-11 12:31:55	\N
12275	32	14	FRANCISCO R. MURGUIA	2022-11-11 12:31:55	\N
12276	32	15	GENERAL JOAQUIN AMARO	2022-11-11 12:31:55	\N
12277	32	16	GENERAL PANFILO NATERA	2022-11-11 12:31:55	\N
12278	32	17	GUADALUPE	2022-11-11 12:31:55	\N
12279	32	18	HUANUSCO	2022-11-11 12:31:55	\N
12280	32	19	JALPA	2022-11-11 12:31:55	\N
12281	32	20	JEREZ	2022-11-11 12:31:55	\N
12282	32	21	JIMENEZ DEL TEUL	2022-11-11 12:31:55	\N
12283	32	22	JUAN ALDAMA	2022-11-11 12:31:55	\N
12284	32	23	JUCHIPILA	2022-11-11 12:31:55	\N
12285	32	24	LORETO	2022-11-11 12:31:55	\N
12286	32	25	LUIS MOYA	2022-11-11 12:31:55	\N
12287	32	26	MAZAPIL	2022-11-11 12:31:55	\N
12288	32	27	MELCHOR OCAMPO	2022-11-11 12:31:55	\N
12289	32	28	MEZQUITAL DEL ORO	2022-11-11 12:31:55	\N
12290	32	29	MIGUEL AUZA	2022-11-11 12:31:55	\N
12291	32	30	MOMAX	2022-11-11 12:31:55	\N
12292	32	31	MONTE ESCOBEDO	2022-11-11 12:31:55	\N
12293	32	32	MORELOS	2022-11-11 12:31:55	\N
12294	32	33	MOYAHUA DE ESTRADA	2022-11-11 12:31:55	\N
12295	32	34	NOCHISTLAN DE MEJIA	2022-11-11 12:31:55	\N
12296	32	35	NORIA DE ANGELES	2022-11-11 12:31:55	\N
12297	32	36	OJOCALIENTE	2022-11-11 12:31:55	\N
12298	32	37	PANUCO	2022-11-11 12:31:55	\N
12299	32	38	PINOS	2022-11-11 12:31:55	\N
12300	32	39	RIO GRANDE	2022-11-11 12:31:55	\N
12301	32	40	SAIN ALTO	2022-11-11 12:31:55	\N
12302	32	41	EL SALVADOR	2022-11-11 12:31:55	\N
12303	32	42	SOMBRERETE	2022-11-11 12:31:55	\N
12304	32	43	SUSTICACAN	2022-11-11 12:31:55	\N
12305	32	44	TABASCO	2022-11-11 12:31:55	\N
12306	32	45	TEPECHITLAN	2022-11-11 12:31:55	\N
12307	32	46	TEPETONGO	2022-11-11 12:31:55	\N
12308	32	47	TEUL DE GONZALEZ ORTEGA	2022-11-11 12:31:55	\N
12309	32	48	TLALTENANGO DE SANCHEZ ROMAN	2022-11-11 12:31:55	\N
12310	32	49	VALPARAISO	2022-11-11 12:31:55	\N
12311	32	50	VETAGRANDE	2022-11-11 12:31:55	\N
12312	32	51	VILLA DE COS	2022-11-11 12:31:55	\N
12313	32	52	VILLA GARCIA	2022-11-11 12:31:55	\N
12314	32	53	VILLA GONZALEZ ORTEGA	2022-11-11 12:31:55	\N
12315	32	54	VILLA HIDALGO	2022-11-11 12:31:55	\N
12316	32	55	VILLANUEVA	2022-11-11 12:31:55	\N
12317	32	56	ZACATECAS	2022-11-11 12:31:55	\N
12318	32	57	CONGREGACION IGNACIO ALLENDE	2022-11-11 12:31:55	\N
12319	32	999	MUNICIPIO NO ESPECIFICADO	2022-11-11 12:31:55	\N
\.


--
-- Data for Name: nivel_escolar; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".nivel_escolar (nivel_escolar, descripcion_nivel) FROM stdin;
B	BACHILLERATO                                      
L	LICENCIATURA                                      
P	POSTGRADO                                         
\.


--
-- Data for Name: organigrama; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".organigrama (clave_area, descripcion_area, area_depende, siglas) FROM stdin;
100000	DIRECCION	100000	\N
110000	SUBDIRECCION ACADEMICA	100000	\N
110100	DEPARTAMENTO DE CIENCIAS BASICAS	110000	DCB  
110101	COORDINACION DE CIENCIAS BASICAS	110100	\N
110102	LABORATORIO DE QUIMICA	110100	\N
110200	DEPARTAMENTO DE ING. QUIMICA	110000	\N
110201	COORDINACION DE INGENIERIA MECANICA	110200	\N
110202	TALLER DE MAQUINAS Y HERRAMIENTAS	110200	\N
110203	LABORATORIO DE INGENIERIA MECANICA	110200	\N
110204	LABORATORIO DE VIBRACIONES MECANICAS	110200	\N
110205	LABORATORIO DE ANALISIS DE ESFUERZOS	110200	\N
110300	DEPTO. DE INGENIERIA INDUSTRIAL	110000	DII  
110301	COORDINACION DE INGENIERIA INDUSTRIAL	110300	\N
110302	LABORATORIO DE PRODUCCION	110300	\N
110400	DEPARTAMENTO DE METAL MECANICA	110000	\N
110401	COORDINACION DE ARQUITECTURA	110400	\N
110402	LABORATORIO DE CONSTRUCCION	110400	\N
110403	LABORATORIO DE ARQUITECTURA	110400	\N
110500	DPTO ING ELECTROMEC Y MECATRONICA	110000	DIEE 
110501	COORDINACION INGENIERIA ELECTRICA	110500	\N
110502	COORDINACION INGENIERIA ELECTRONICA	110500	\N
110503	LABORATORIO DE INGENIERIA ELECTRICA	110500	\N
110504	LABORATORIO DE ELECTRONICA	110500	\N
110600	DEPARTAMENTO DE SISTEMAS Y COMPUTACIÓN	110000	DSIS 
110601	COORDINACION DE ING. EN SISTEMAS COMPUTACIONALES	110600	\N
110700	DEPTO C. ECONO ADMVAS	110000	CEA  
110701	COORDINACION DE ADMINISTRACION	110700	\N
110801	OFICINA DE DESARROLLO CURRICULAR	110800	\N
110802	OFICINA DE MEDIOS AUDIOVISUALES	110800	\N
110803	OFICINA DE ORIENTACION EDUCATIVA	110800	\N
110804	OFICINA DE DESARROLLO PROFESIONAL	110800	\N
110805	OFICINA DE ADMISION DE ALUMNOS	110800	\N
111000	DIVISION DE ESTUDIOS PROFESIONALES	110000	\N
111100	DEPARTAMENTO DE ING. AMBIENTAL	110000	\N
111200	DIVISION DE ESTUDIOS A DISTANCIA	110000	\N
111201	COORDINACION DE CARRERA MECATRONICA	111200	\N
111300	CIENCIAS DE LA TIERRA	110000	\N
111400	DEPARTAMENTO DE QUÖMICA Y BIOQUÖMICA	110000	\N
111500	DEPARTAMENTO DE CIENCIAS DE LA AGRONOMÖA	110000	\N
111600	DEPARTAMENTO DE INGENIERÖA AMBIENTAL	110000	\N
111700	DEPARTAMENTO DE CIENCIAS DEL MAR	110000	\N
111800	DEPARTAMENTO DE CIENCIAS AGROPECUARIAS	110000	\N
111900	DEPARTAMENTO DE INGENIERIAS	110000	\N
112000	DEPTO DE CALIDAD EN LOS SERV EDUCATIV	110000	\N
112100	COORDINACION DE IDIOMAS	112000	\N
112200	COORD DE ACREDIT Y REACREDIT	112000	\N
112300	COORD DE SGC	112000	\N
112400	COORD DE SGA	112000	\N
112500	COORD DE SSHT	112000	\N
120000	SUBDIRECCION DE PLANEACION	100000	\N
120100	DPTO PLAN PROGR Y PRESUP	120000	\N
120101	OFICINA DESARROLLO INSTITUCIONAL	120100	\N
120102	OFICINA PROGRAMACION Y EVALUACION PRESUPUESTAL	120100	\N
120103	OFICINA CONSTRUCCION Y EQUIPAMIENTO	120100	\N
120200	DEPARTAMENTO DE GESTION TECNOLOGICA Y VINCULACION	120000	\N
120201	OFICINA DE GESTION	120200	\N
120202	OFICINA DE VINCULACION CON EL SECTOR PRODUCTIVO	120200	\N
120203	OFICINA DE SERVICIO SOCIAL	120200	\N
120204	OFICINA DE SERVICIOS EXTERNOS	120200	\N
120205	LABORATORIO DE IDIOMAS	120200	\N
120300	DEPARTAMENTO DE COMUNICACION Y DIFUSION	120000	\N
120301	OFICINA EDITORIAL	120300	\N
120302	OFICINA DIFUSION ESCRITA Y AUDIOVISUAL	120300	\N
120303	OFICINA DE RELACIONES PUBLICAS	120300	\N
120400	DEPARTAMENTO DE ACTIVIDADES EXTRAESCOLARES	120000	\N
120401	OFICINA ACTIVIDADES CULTURALES	120400	\N
120402	OFICINA DE ACTIVIDADES DEPORTIVAS	120400	\N
120500	DEPARTAMENTO DE CENTRO DE INFORMACION	120000	\N
120501	OFICINA DE ADQUISICIONES	120500	\N
120502	OFICINA DE PROCESOS TECNICOS	120500	\N
120503	OFICINA DE SERVICIOS AL PUBLICO	120500	\N
120600	DEPARTAMENTO DE SERVICIOS ESCOLARES	120000	\N
120601	OFICINA DE CONTROL ESCOLAR	120600	\N
120602	OFICINA DE TITULACION	120600	\N
120603	OFICINA DE SERVICIOS MEDICOS	120600	\N
120604	OFICINA DE SERVICIOS ESTUDIANTILES	120600	\N
130000	SUBDIRECCION ADMINISTRATIVA	100000	\N
130100	DEPARTAMENTO DE CENTRO DE COMPUTO	130000	\N
130101	OFICINA DISE¥O Y DESARROLLO DE SISTEMAS	130100	\N
130102	OFICINA INTERNET E INTRANET	130100	\N
130103	OFICINA CONECTIVIDAD Y REDES	130100	\N
130104	OFICINA DE MANTENIMIENTO DE EQUIPO DE COMPUTO	130100	\N
130105	OFICINA DE SOPORTE TECNICO	130100	\N
130106	LABORATORIO DE COMPUTO	130100	\N
130200	DEPARTAMENTO DE RECURSOS HUMANOS	130000	\N
130201	OFICINA DE CONSERVACION	130200	\N
130300	DEPARTAMENTO DE RECURSOS MATERIALES	130000	\N
130301	OFICINA DE CONTABILIDAD Y PRESUPUESTO	130300	\N
130302	OFICINA DE ADQUISICIONES	130300	\N
130303	OFICINA DE ALMACEN E INVENTARIO	130300	\N
130400	DEPARTAMENTO DE RECURSOS FINANCIEROS	130000	\N
130401	OFICINA DE ADMINISTRACION DE PERSONAL	130400	\N
130500	DEPARTAMENTO DE MANTENIMIENTO Y EQUIPO	130000	\N
130600	DEPARTAMENTO DE MANTENIMIENTO	130000	\N
140000	COMITE DE GESTION TECNOLOGICA Y VINCULACION	100000	\N
150000	COMITE DE PLANEACION	100000	\N
160000	CONSEJO EDITORIAL	100000	\N
170000	COMITE ACADEMICO	100000	\N
200000	SINDICATO	100000	\N
999999	SIN AREA DE ADSCRIPCION	100000	\N
110800	DEPARTAMENTO DE DESARROLLO ACADÉMICO	110000	\N
110900	DIVISION DE POSTGRADO E INVESTIGACION	110000	DEPI 
\.


--
-- Data for Name: parametros; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".parametros (id, ciudad, tec) FROM stdin;
\.


--
-- Data for Name: parametros_fichas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".parametros_fichas (id, fichas, activo, inicio_prope, fin_prope, entrega, termina, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".password_resets (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: periodos_escolares; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".periodos_escolares (periodo, identificacion_larga, identificacion_corta, fecha_inicio, fecha_termino, inicio_vacacional_ss, fin_vacacional_ss, inicio_especial, fin_especial, cierre_horarios, cierre_seleccion, inicio_sele_alumnos, fin_sele_alumnos, inicio_vacacional, termino_vacacional, inicio_cal_docentes, fin_cal_docentes, created_at, updated_at, ccarrera) FROM stdin;
\.


--
-- Data for Name: permisos_carreras; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".permisos_carreras (carrera, reticula, nombre_carrera, nombre_reducido, email) FROM stdin;
\.


--
-- Data for Name: personal; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal (id, rfc, clave_area, curp_empleado, no_tarjeta, apellidos_empleado, nombre_empleado, nombramiento, ingreso_rama, inicio_gobierno, inicio_sep, inicio_plantel, domicilio_empleado, colonia_empleado, codigo_postal_empleado, telefono_empleado, sexo_empleado, estado_civil, status_empleado, correo_electronico, correo_institucion, apellido_paterno, apellido_materno, siglas, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_carreras; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_carreras (id, carrera, nombre_corto, siglas, nivel, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_datos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_datos (id, campo, lectura, tabla, created_at, updated_at) FROM stdin;
19	apellido_paterno	Apellido Paterno	personal	2022-12-24 15:00:00	\N
20	apellido_materno	Apellido Materno	personal	2022-12-24 15:00:01	\N
21	nombre_empleado	Nombre	personal	2022-12-24 15:00:02	\N
22	siglas	Siglas	personal	2022-12-24 15:00:03	\N
23	rfc	RFC	personal	2022-12-24 15:00:04	\N
24	curp_empleado	CURP	personal	2022-12-24 15:00:05	\N
25	clave_area	Área de adscripción	organigrama	2022-12-24 15:00:06	\N
26	no_tarjeta	No. de empleado	personal	2022-12-24 15:00:07	\N
27	nombramiento	Tipo de contratación	nombramientos	2022-12-24 15:00:08	\N
28	inicio_gobierno	Gob. Federal	personal	2022-12-24 15:00:09	\N
29	inicio_sep	S.E.P	personal	2022-12-24 15:00:10	\N
30	ingreso_rama	Rama	personal	2022-12-24 15:00:11	\N
31	domicilio_empleado	Calle y número	personal	2022-12-24 15:00:12	\N
32	colonia_empleado	Colonia	personal	2022-12-24 15:00:13	\N
33	codigo_postal_empleado	Código Postal	personal	2022-12-24 15:00:14	\N
34	telefono_empleado	Teléfono	personal	2022-12-24 15:00:15	\N
35	correo_electronico	Correo electrónico personal	personal	2022-12-24 15:00:16	\N
36	correo_institucion	Correo electrónico institucional	personal	2022-12-24 15:00:17	\N
\.


--
-- Data for Name: personal_estudios; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_estudios (id, id_docente, fecha_inicio, fecha_final, id_carrera, id_escuela, cedula, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_instit_estudios; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_instit_estudios (id, id_escuela, id_estado, id_municipio, nombre, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_nivel_estudios; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_nivel_estudios (id, caracter, descripcion, created_at, updated_at) FROM stdin;
15	0	Sin estudios	2023-01-10 11:00:00	\N
16	A	Primaria	2023-01-10 11:00:01	\N
17	B	Carrera comercial	2023-01-10 11:00:02	\N
18	C	Estudios técnicos	2023-01-10 11:00:03	\N
19	D	Secundaria	2023-01-10 11:00:04	\N
20	E	Bachillerato	2023-01-10 11:00:05	\N
21	M	Técnico Superior	2023-01-10 11:00:06	\N
22	H	Pasante de licenciatura	2023-01-10 11:00:07	\N
23	F	Normal	2023-01-10 11:00:08	\N
24	G	Normal Superior	2023-01-10 11:00:09	\N
25	I	Licenciatura	2023-01-10 11:00:10	\N
26	L	Especialidad	2023-01-10 11:00:11	\N
27	J	Maestría	2023-01-10 11:00:12	\N
28	K	Doctorado	2023-01-10 11:00:13	\N
\.


--
-- Data for Name: personal_nombramientos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_nombramientos (id, letra, descripcion, created_at, updated_at) FROM stdin;
5	D	Docente	2022-12-26 12:25:00	\N
6	A	Administrativo	2022-12-26 12:25:01	\N
7	Z	Personal de apoyo y de servicios	2022-12-26 12:25:02	\N
8	X	Personal administrativo/docente	2022-12-26 12:25:03	\N
\.


--
-- Data for Name: personal_plazas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".personal_plazas (id, id_personal, unidad, subunidad, id_categoria, horas, diagonal, estatus_plaza, id_motivo, efectos_iniciales, efectos_finales, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: planes_de_estudio; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".planes_de_estudio (plan_de_estudio, descripcion) FROM stdin;
\.


--
-- Data for Name: preficha; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".preficha (no_recibo, fecha_registro, instituto, apellido_paterno, apellido_materno, nombre_aspirante, nip, fecha_nacimiento, sexo, nacionalidad, especifique_extranjero, curp, carrera_opcion_1, entidad_federativa_prepa, clave_preparatoria, agnio_egreso, promedio_general, calle_no, entidad_federativa, municipio, codigo_postal, colonia_aspirante, correo_electronico, telefono, estado_civil, capacidad_diferente, tienes_beca, quien_otorgo, zona_procedencia, especifique_zona_procedencia, programa_oportunidades, apellido_paterno_padre, apellido_materno_padre, nombre_padre_aspirante, vive_padre, apellido_paterno_madre, apellido_materno_madre, nombre_madre_aspirante, vive_madre, fecha_atencion, hora_atencion, no_solicitud, periodo, itmin, folio_ceneval, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: preguntas; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".preguntas (encuesta, aspecto, no_pregunta, pregunta, respuestas, resp_val, consecutivo) FROM stdin;
A	A	1	¿El profesor te entregó al inicio del curso el programa de la materia?	A) Si  B) No	2	1
A	A	1	Explica de manera clara los contenidos de la asignatura.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	A	2	¿El profesor explicó los objetivos del curso?	A) Si  B) No	2	1
A	A	2	Relaciona los contenidos de la asignatura con los contenidos de otras.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	A	3	¿El profesor explica la forma en que se trabajará durante el curso?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	A	3	Resuelve las dudas relacionadas con los contenidos de la asignatura.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	A	4	¿El profesor dio a conocer al inicio del curso la forma en que evaluará tu aprendizaje?	A) Si  B) No	2	1
A	A	4	Propone ejemplos o ejercicios que vinculan la asignatura con la práctica profesional.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	A	5	Explica la utilidad de los contenidos teóricos y prácticos para la actividad profesional.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	B	5	¿El profesor te pregunta lo que sabes acerca de los temas a tratar?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	6	¿El profesor te ayuda a que relaciones lo que ya sabes del tema con lo visto en clase?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	6	Cumple con los acuerdos establecidos al inicio de la asignatura.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	B	7	¿El profesor te motiva a que busques información adicional sobre los temas de la materia?	A) Si  B) No	2	1
A	B	7	Durante el curso establece las estrategias adecuadas necesarias para lograr el aprendizaje deseado.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	B	8	¿El profesor propone actividades que te permiten desarrollar algunas de estas habilidades: analizar, sintetizar, comparar, clasificar, pensar de manera crítica o ser creativo?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	8	El programa presentado al principio de la asignatura se cubre totalmente.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	B	9	¿El profesor promueve en ti la reflexión sobre la manera en que aprendes?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	10	¿El profesor utiliza diferentes formas de trabajo en clase que favorecen tu aprendizaje?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	11	¿El profesor propicia un ambiente de confianza?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
A	B	12	¿El profesor estimula el intercambio de experiencias que enriquecen el aprendizaje del grupo sobre la materia?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	B	13	¿El profesor propicia que te intereses por la materia?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	C	9	Incluye experiencias de aprendizaje en lugares diferentes al aula (talleres, laboratorios, empresa, comunidad, etc.).	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	C	10	Utiliza para el aprendizaje las herramientas de interacción de las tecnologías actuales de la información (correo electrónico, chats, plataformas, etc.a.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	C	11	Organiza actividades que me permiten ejercitar mi expresión oral y escrita.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	C	12	Relaciona los contenidos de la asignatura con la industria y la sociedad a nivel local, regional, nacional e internacional.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	C	13	Usa ejemplos y casos relacionados con la vida real	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	C	14	¿El profesor define de manera clara los conceptos propios de la materia?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	C	15	¿El profesor relaciona los temas de la materia con otras materias?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
A	C	16	¿El profesor relaciona los temas de la materia con el perfil de egreso de la carrera?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	C	17	¿El profesor presenta los temas en forma organizada?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	C	18	¿El profesor usa ejemplos reales para que comprendas los temas vistos en clase?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	C	19	¿El profesor resuelve las dudas que se le plantean en clase?	A)Generalmente  B)Ocasionalmente  C)Casi nunca	3	1
A	D	14	Adapta las actividades para atender los diferentes estilos de aprendizaje de los estudiantes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	15	Promueve el autodidactismo y la investigación.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	16	Promueve actividades participativas que me permiten colaborar con mis compañeros con una actitud positiva.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	17	Estimula la reflexión sobre la manera en que aprendes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	18	Se involucra en las actividades propuestas al grupo.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	19	Presenta y expone las clases de manera organizada y estructurada.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	D	20	¿El profesor promueve los valores de los Institutos Tecnológicos (honestidad, respeto, responsabilidad y colaboración, identidad nacional, entre otros)?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	D	20	Utiliza diversas estrategias, métodos, medios y materiales.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
D	A	2	Cuenta con el título y la cédula de licenciatura y posgrado.	\N	5	2
A	D	21	¿El profesor promueve el respeto hacia el medio ambiente?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	D	22	¿El profesor promueve el uso racional de los recursos naturales?	A)Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	E	21	Muestra compromiso y entusiasmo en sus actividades docentes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	22	Toma en cuenta las necesidades, intereses y expectativas del grupo.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	23	¿El profesor utiliza diferentes formas de evaluación (reportes, ensayos, participación en clase, trabajo en equipo, proyectos, exámenes, entre otros)?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	E	23	Propicia el desarrollo de un ambiente de respeto y confianza.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	24	¿El profesor analiza con el grupo los resultados de las evaluaciones?	A)Generalmente  B)Ocasionalmente  C)Casi nunca	3	1
A	E	24	Propicia la curiosidad y el deseo de aprender.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	25	¿El profesor propone acciones para mejorar tu aprendizaje considerando los resultados de la evaluación (asesorías, trabajos complementarios, búsqueda de información)?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	E	25	Reconoce los Éxitos y logros en las actividades de aprendizaje.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	26	¿El profesor evalúa los temas tratados durante el curso?	A) Generalmente  B) Ocasionalmente  C) Casi Nunca	3	1
A	E	26	Existe la impresión de que se toman represalias con algunos estudiantes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	E	27	Hace interesante la asignatura.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	27	¿En una escala del 0 al 100 cómo calificarías el desempeño del profesor?	A) 80 - 100  B) 50 - 79  C) Menos De 50	3	1
A	F	28	Identifica los conocimientos y habilidades de los estudiantes al inicio de la asignatura o de cada unidad.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	29	Proporciona información para realizar adecuadamente las actividades de evaluación.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	30	Toma en cuenta las actividades realizadas y los productos como evidencias para la calificación y acreditación de la asignatura.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	31	Considera los resultados de la evaluación (asesorías, trabajos complementarios, búsqueda de información, etc.) para realizar mejoras en el aprendizaje.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	32	Da a conocer las calificaciones en el plazo establecido.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	33	Da oportunidad de mejorar los resultados de la evaluación del aprendizaje.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	34	Muestra apertura para la corrección de errores de apreciación y evaluación.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	F	35	Otorga calificaciones imparciales.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	G	36	Desarrolla la clase en un clima de apertura y entendimiento.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	G	37	Escucha y toma en cuenta las opiniones de los estudiantes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	G	38	Muestra congruencia entre lo que dice y lo que hace.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	H	39	Asiste a clases regular y puntualmente.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	H	40	Fomenta la importancia de contribuir a la conservación del medio ambiente.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	H	41	Promueve mantener limpias y ordenadas las instalaciones.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	H	42	Es accesible y esta dispuesto a brindarte ayuda académica.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	I	43	Emplea las tecnologías de la información y de la comunicación como un medio que facilite el aprendizaje de los estudiantes.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	I	44	Promueve el uso de diversas herramientas, particularmente las digitales, para gestionar (recabar, procesar, evaluar y usar) información.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	I	45	Promueve el uso seguro, legal y Ético de la información digital.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	J	46	En general, pienso que es un buen docente	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	J	47	Estoy satisfecha o satisfecho por mi nivel de desempeño y aprendizaje logrado gracias a la labor del docente.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
A	J	48	Yo recomendaría a este docente a otros compañeros.	5) Totalmente de acuerdo 4) De acuerdo 3) Indiferente 2) En desacuerdo 1) Altamente en desacuerdo	5	2
D	A	1	¿El profesor elabora material didáctico (antologías, software, presentaciones electrónicas, apuntes, guías de prácticas, libros, guías de estudio, entre otros?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	A	1	Acredita un diplomado en formación docente  o profesional , o realiza una estadía técnica en su área de formación, y asiste a un evento (congreso, simposio, convención, entre otros),  y acredita cursos de formación docente y/o profesional y muestra evidencia	\N	5	2
D	A	3	Diseña un curso de actualización docente o profesional que considere: la guía de sesión, cronograma y los  materiales didácticos, y participa en la impartición de cursos  entregando el reporte final.	\N	5	2
D	B	2	¿El profesor realiza proyectos de investigación o desarrollo (disciplinar o educativa)?	A) Si  B) No	2	1
D	B	3	¿El profesor involucra a los estudiantes en sus proyectos de investigación o desarrollo?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	B	4	¿El profesor participa en redes de investigación?	A) Generalmente B) Ocasionalmente C) Casi nunca	3	1
D	B	4	Participa en la academia  y grupos de trabajo o comités de evaluación y pláticas de inducción o en exámenes de nuevo ingreso o promoción de las carreras del instituto y pertenece a asociaciones académicas o profesionales nacionales y/o internacionales.	\N	5	2
D	B	5	¿El profesor da a conocer los resultados de sus proyectos de investigación y desarrollo (escribe artículos, presenta ponencias, da conferencias, entre otros)?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	B	5	Realiza el avance programático de curso y/o  diseña la instrumentación didáctica en el seno de las academias por áreas del conocimiento (con docentes que dan la misma asignatura),  y los presenta en tiempo y forma, y da seguimiento a lo programado	\N	5	2
D	B	6	Entrega al Departamento Académico una relación de bibliografía básica y de consulta sugerida para mantener actualizado el acervo bibliográfico de su asignatura, y prepara presentaciones  electrónicas o antologías para sus clases, y propone el uso de tecnología	\N	5	2
D	B	7	Asiste a / Participa en: -Eventos institucionales (honores a la bandera, ceremonia de inicio de cursos, graduaciones). -Pláticas o reuniones informativas convocadas por grupos de trabajo con el fin de mejorar la vida institucional. - Con su grupo a pláticas	\N	5	2
D	C	6	¿El profesor forma parte de algún cuerpo colegiado o asociación profesional?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	C	7	¿El profesor contribuye con aportaciones al logro de los objetivos de su academia?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	C	8	¿El profesor entrega la documentación requerida para la gestión del curso, listas de calificaciones, reportes parciales, entre otros?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	C	8	Planea  y ejecuta actividades para el fortalecimiento del aprendizaje como reforzamiento al total de sus asignaturas con representantes de los sectores empresarial, gubernamental y social (conferencias, visitas industriales, talleres, foros, seminarios	\N	5	2
D	C	9	¿El profesor proporciona información para actualizar el acervo bibliográfico?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	C	9	Desarrolla, administra, Concerta y asesora proyecto de  residencia profesional, de servicio social, de investigación, innovación o incubación de empresas que den respuesta a las necesidades planteadas por los diferentes sectores de la sociedad.	\N	5	2
D	C	10	¿El profesor utiliza de manera pertinente las tecnologías de la información y la comunicación?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	C	10	Desarrolla y  realiza un curso de capacitación,  participa en el diseño de un diplomado,  realiza un proyecto, da  asesoría técnica, o realiza  actividades,   para los sectores empresarial, gubernamental y social.	\N	5	2
D	C	11	¿El profesor participa en los comités, consejos, grupos de trabajo y demás comisiones cuyo fin es el mejoramiento de la vida institucional?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	D	11	Presenta informe final de proyecto de investigación disciplinar o educativa, o tiene un proyecto terminado en el periodo anterior y presenta un nuevo protocolo de proyecto de investigación disciplinar o educativa.	\N	5	2
D	D	12	¿El profesor realiza trabajo de tutoría o asesoría (concursos, residencias, titulación, plan de vida, tutoría académica, entre otros)?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	D	12	Participa en grupos o redes de investigación (área de conocimiento de su competencia o educativos).	\N	5	2
D	D	13	Difunde y divulga los resultados de sus proyectos de investigación disciplinar o educativa.	\N	5	2
D	D	14	Involucra y asesora al o los estudiante (s)  en el proyecto de investigación, avala bitácora de actividades realizadas y el estudiante genera producto(s) como resultado de las actividades realizadas en la investigación.	\N	5	2
D	E	13	¿El profesor en conjunto con los sectores productivos de bienes y servicios, realiza actividades (actualización, asesoría, capacitación) o proyectos de investigación y desarrollo?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	E	15	Cuenta con un diplomado referente a la tutoría y cursos que apoyan la actividad tutorial.	\N	5	2
D	E	16	Elabora el Programa de Acción Tutorial considerando: el diagnóstico, la competencia general y específica,  los contenidos, el cronograma de actividades,  los recursos necesarios,las estrategias, y la  evaluación,  y  lo presenta en tiempo y forma.	\N	5	2
D	E	17	Realiza sesiones planeadas,  realiza diagnóstico y canaliza estudiantes en riesgo, y promueve programas de apoyo para la formación integral del tutorado  y aplica estrategias.	\N	5	2
D	E	18	Entrega un reporte con las actividades desarrolladas en el Programa de Acción Tutorial, presenta evidencias del seguimiento, hace contrastación entre lo planeado y lo realizado, identifica sus áreas de oportunidad  y elabora una propuesta de realimentación	\N	5	2
D	F	14	¿El profesor participa en actividades (cursos, congresos, seminarios, foros, conferencias, entre otros) de formación y actualización docente y de su disciplina?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	G	15	¿El profesor es reconocido favorablemente por la comunidad escolar (estudiantes, directivos, profesores, administrativos)?	A) Generalmente  B) Ocasionalmente  C) Casi nunca	3	1
D	H	16	¿En una escala del 0 a 100? ¿cómo calificaría el desempeño del profesor?	A) 80 -100  B) 50 - 79  C) Menos de 50	3	1
I	A	1	¿El instructor dio a conocer al inicio del curso el temario de la asignatura?	A) Si B) No	2	1
I	A	2	¿El instructor explica la forma de trabajar durante el curso?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	A	3	¿El instructor da a conocer la información personal necesaria para mantener una comunicación constante durante el curso? (e-mail,horario oficial,etc.)	A) Si B) No	2	1
I	A	12	¿El instructor dio a conocer al inicio del curso la forma en como evaluara el aprendizaje?	A) Si B) No	2	1
I	B	4	¿El instructor realiza un sondeo general acerca de los conocimientos relacionados con los temas que se abordaran en el curso?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	B	5	En las actividades que el instructor asigna para la evaluación, ¿Enfatiza en la relación que debe existir entre tu experiencia personal y laboral y la teoría que te proporciona?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	B	6	¿El instructor le motiva a que busque información adicional sobre los temas de la asignatura?	A) Si B) No	2	1
I	B	7	¿El instructor propone actividades que le permita desarrollar alguna de estas habilidades: Analizar, Sintetizar, Comparar, Clasificar, Ser crítico?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	B	8	¿El instructor promueve el trabajo colaborativo a través de los recursos de la plataforma educativa?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	C	9	¿El instructor motiva el interés hacia su materia?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	C	10	¿El instructor utiliza distintas formas de trabajo para favoreces tu aprendizaje?	A) Si B) No	2	1
I	C	11	¿El instructor usa ejemplos reales para la comprensión de los temas?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	D	16	¿El instructor propone acciones para mejorar su aprendizaje considerando los resultados de las evaluaciones por medio de: Asesorías, Trabajos complementarios, Búsqueda de información?	A) Si B) No	2	1
I	D	17	¿El instructor muestra interés por resolver tus dudas?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	D	18	¿El instructor propicia un ambiente de cordialidad para contestar cuando surgen dudas al realizar sus actividades?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	E	13	¿El instructor ejecuta las actividades obligatorias en los tiempos marcados en su plan de actividades (Exámenes, Chats, Foros, etc)?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	E	14	¿El instructor utiliza distintas formas de evaluación (Uso de foros, Reportes, Ensayos, Mapas mentales, Trabajos de investigación, Proyectos, Trabajo en equipo, etc)?	A) Si B) No	2	1
I	E	15	¿El instructor analiza los resultados de las evaluaciones después de su aplicación y obtener resultados?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	F	19	¿El material del instructor es claro en su explicación y procedimientos para su aplicación?	A) Excelente B) Bueno C) Regular D) Deficiente	4	1
I	F	20	¿El instructor presenta los temas en forma organizada?	A) Generalmente B) Ocasionalmente C) Casi Nunca	3	1
I	F	21	¿Existe la retro alimentación entre usted y el instructor?	A) Si B) No	2	1
I	F	22	En escala de 0 a 100, ¿Como calificarías el desempeño del instructor?	A) 80-100 B) 50-79 C) Menos de 50	3	1
\.


--
-- Data for Name: preparatorias; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".preparatorias (clave_preparatoria, nombre_preparatoria, entidad_federativa, municipio) FROM stdin;
\.


--
-- Data for Name: puestos; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".puestos (clave_puesto, descripcion_puesto) FROM stdin;
1	ALBANIL
2	ALMACENISTA
3	ANALISTA DE SISTEMAS
4	ASESOR CENTRO DE MATEMATICAS
5	ASESOR CENTRO REGIONAL MICROSEP
6	ASESOR EDUCATIVO
7	ASESOR JURIDICO
8	ASESOR LEGAL
9	ASESOR Y JURADO DE TESIS
10	ASISTENTE DE INFORMACION
11	AUXILIAR ADMINISTRATIVO
12	AUXILIAR CENTRO DE COMPUTO
13	AUXILIAR DE BIBLIOTECA
14	AUXILIAR DE CIRCULACION
15	AUXILIAR DE CONSULTA
16	AUXILIAR DE COORDINACION
17	AUXILIAR DE INTENDENCIA
18	AUXILIAR DE LABORATORIO DE ANALISIS INDUSTRIALES
19	AUXILIAR DE LABORATORIO DE ELECTRICIDAD
20	AUXILIAR DE LABORATORIO DE ELECTRONICA
21	AUXILIAR DE LABORATORIO DE FISICA
22	AUXILIAR DE LABORATORIO DE INGENIERIA INDUSTRIAL
23	AUXILIAR DE LABORATORIO DE INGENIERIA QUIMICA
24	AUXILIAR DE LABORATORIO DE INSTRUMENTCION
25	AUXILIAR DE LABORATORIO DE PROPULSION
26	AUXILIAR DE LABORATORIO DE QUIMICA ANALITICA
27	AUXILIAR DE LABORATORIO DE QUIMICA GENERAL
28	AUXILIAR DE MANTENIMIENTO
29	AUXILIAR DE MEDIOS EDUCATIVOS
30	AUXILIAR DE METODOS EDUCATIVOS
31	AUXILIAR DE OFICINA
32	AUXILIAR DE SERVICIO AL PUBLICO
33	AUXILIAR DE SERVICIO SOCIAL
34	AUXILIAR DE TALLER
35	AUXILIAR DEL CENTRO DE INFORMACION
36	AUXILIAR DEL COMITE PROMOTOR DE DESARROLLO
37	AUXILIAR DEPORTIVO
38	AUXILIAR DOCENTE
39	AUXILIAR DOCENTE MECANICA AUTOMOTIZ
40	AUXILIAR DOCENTE TALLER SOLDADURA
41	AUXILIAR LABORATORIO ANALISIS CUAL-CUANT
42	AUXILIAR LABORATORIO ANALISIS CUALITATIVO
43	AUXILIAR LABORATORIO ANALISIS CUANTI.
44	AUXILIAR LABORATORIO DE PRODUCCION
45	AUXILIAR LABORATORIO ING. SIS. COMPUTACION
46	AUXILIAR OFICINA CONTROL ESCOLAR
47	AUXILIAR SALA ADJUNTA MICROSEP
48	AUXILIAR TALLER MECANICO
49	CAJERO
50	CASETERA LAB. INGENIERIA ELECTRONICA
51	CASETERO HERRAMENTISTA
52	CASETERO LABORATORIO DE INGENIERIA ELECT
53	CASETERO LABORATORIO INGENIERIA CIVIL
54	CASETERO LABORATORIO INGENIERIA ELECTROMECANICA
55	CASETERO LABORATORIO INGENIERIA QUIMICA
56	CASETERO TALLER DE MECANICA
57	CASETERO TALLER MECANICO AUTOMOTRIZ
58	CASETERO TALLER SOLDADURA
59	CATEDRATICO
60	CHOFER
61	COORD. DE SERVS. DE COMPUTO
62	COORDINACION DE TITULACION
63	COORDINADOR
64	COORDINADOR AREA INGENIERO INDUSTRIAL
65	COORDINADOR CARRERA INGENIERIA ELECTRICA
66	COORDINADOR CARRERA INGENIERIA ELECTRONI
67	COORDINADOR CULTURAL
68	COORDINADOR CULTURAL Y DEPORTIVO
69	COORDINADOR DE ASESORIA ACADEMICA
70	COORDINADOR DE CAPACITACION
71	COORDINADOR DE CAPACITACION Y DESARROLLO
72	COORDINADOR DE CARRERA
73	COORDINADOR DE DIFUSION
74	COORDINADOR DE INFORMATICA
75	COORDINADOR DE INGENIERIA ELECTROMECANICA
76	COORDINADOR DE INGENIERIA INDUSTRIAL
77	COORDINADOR DE INVESTIGACION
78	COORDINADOR DE MATERIAS BASICAS
79	COORDINADOR DE TITULACION
80	COORDINADOR DEPORTIVO
81	COORDINADOR INGENIERIA ELECTRONICA
82	COORDINADOR INTENDENCIA
83	COORDINADOR LICENCIADO EN INFORMATICA
84	COORDINADOR VINCULACION CON EL SECTOR PR
85	COORDINADORA CARRERA ING. INDUSTRIAL EN
86	COORDINADORA DEL SEMESTRE CERO
87	COORDINADORA TRONCO COMUN
88	DEPARTAMENTO ADMINISTRACION DE RECURSOS
89	DEPARTAMENTO ADMINISTRACION DEL PRESUPUE
90	DEPARTAMENTO DE PLANEACION
91	DEPARTAMENTO DE SERVICIOS EXTERNO
92	DEPARTAMENTO DE SERVICIOS GENERALES
93	DEPARTAMENTO TECNOLOGIA EDUCATIVA
94	DIBUJANTE
95	DIRECTOR DEL PLANTEL
96	DOCENTE
97	Director de Incubadora
98	ELECTRICISTA
99	ENCARGADA DE OFICINA
100	ENCARGADA DEL CONMUTADOR
101	ENCARGADA SECCION CONTABILIDAD
102	ENCARGADO DE ACTIVO FIJO
103	ENCARGADO DE CIRCULACION
104	ENCARGADO DE COMPRAS
105	ENCARGADO DE DEPARTAMENTO
106	ENCARGADO DE LA COORDINACION
107	ENCARGADO DE MANTENIMIENTO
108	ENCARGADO DE PRACTICAS PROFESIONALES
109	ENCARGADO DE SEGUIMIENTO
110	ENCARGADO DE SERVICIO SOCIAL
111	ENCARGADO DE VINCULACION
112	ENCARGADO DEL CENTRO REGIONAL MICROSEP
113	ENFERMERA
114	ENTRENADOR DEPORTIVO
115	FONTANERO
116	INSTRUCTOR DE PRACTICAS DE LABORATORIO
117	INVESTIGADOR DE OPERACION
118	JARDINERO
119	JEFA DE LABORATORIO DE PRODUCCION
120	JEFA DE LABORATORIO INGENIEROS DE SISTEM
121	JEFA DEL LABORATORIO FISICO-QUIMICA
122	JEFA SALA ADJUNTA MICROSEP
123	JEFA UNIDAD SERVICIOS MEDICOS
124	JEFE DE CENTRO DE COMPUTO
125	JEFE DE DEPARTAMENTO
126	JEFE DE LA COORDINACION DE INVESTIGACION
127	JEFE DE LA DIVISION
128	JEFE DE LA OFICINA DE CONTROL ESCOLAR
129	JEFE DE LAB DE ELECTRONICA ANALOGICA
130	JEFE DE LAB DE ELECTRONICA ANALOGICA AB Y SP
131	JEFE DE LAB DE ELECTRONICA ANALOGICA AO
132	JEFE DE LABORATORIO
133	JEFE DE LABORATORIO DE CD
134	JEFE DE LABORATORIO DE INSTRUMENTOS II
135	JEFE DE LABORATORIO DE POSTGRADO
136	JEFE DE LABORATORIO INGENIERIA ELECTRON
137	JEFE DE MANTENIMIENTO
138	JEFE DE OFICINA
139	JEFE DE OFICINA CONSTRUCION Y EQUIPAMIENTO
140	JEFE DE OFICINA DE EDITORIAL
141	JEFE DE OFICINA DE INFORMATICA
142	JEFE DE OFICINA DE PATENTES Y MARCAS
143	JEFE DE OFICINA DE PERSONAL DE RECURSOS
144	JEFE DE OFICINA DESARROLLO
145	JEFE DE OFICINA DESARROLLO PLANEACION
146	JEFE DE OFICINA TITULACION
147	JEFE DE PROYECTO DE DOCENCIA
148	JEFE DE PROYECTO DE INVESTIGACION
149	JEFE DE PROYECTO DE VINCULACION
150	JEFE DE TALLER
151	JEFE DE TALLER MECANICO AUTOMOTRIZ
152	JEFE DEL CENTRO DE COMPUTO
153	JEFE DEL CENTRO DE GRADUADOS
154	JEFE DEL CENTRO DE INFORMACION
155	JEFE DEL DEPARTAMENTO ADMINISTRACION DEL
156	JEFE DEL DEPARTAMENTO DE COMUNICACION Y
157	JEFE DEL DPTO PLAN PROGR Y PRESUP
158	JEFE DEL DEPARTAMENTO DE RECURSOS HUMANOS
159	JEFE DEL DEPARTAMENTO DE SERVICIOS ESCOLARES
160	JEFE DEL DEPARTAMENTO DE SERVICIOS GENER
161	JEFE DEL LABORATORIO DE QUIMICA GENERAL
162	JEFE DEL LABORATORIO INGENIERIA ELECTRON
163	JEFE DEPARTAMENTO COMUNICACION Y DIFUSION
164	JEFE DEPARTAMENTO TECNOLOGIA EDUCATIVA
165	JEFE DIVISION DE EXTENCION
166	JEFE DIVISION ESTUDIOS PROFESIONALES
167	JEFE LABORATORIO ALTA TENSION
168	JEFE LABORATORIO FISICOQUIMICA
169	JEFE LABORATORIO INGENIERIA QUIMICA
170	JEFE LABORATORIO QUIMICA CUAL Y CUANT.
171	JEFE LABORATORIO SISTEMAS DE COMPUTO
172	JEFE MANTENIMIENTO ELECTRICO
173	JEFE OFICINA CONTROL DE PERSONAL
174	JEFE OFICINA CONTROL ESCOLAR
175	JEFE OFICINA INFORMATICA
176	JEFE OFICINA INFORMES Y SERVICIOS
177	JEFE OFICINA MEDIOS EDUCATIVOS
178	JEFE OFICINA METODOS EDUCATIVOS
179	JEFE OFICINA PROGRAMACION
180	JEFE SECCION PREFECTURA
181	JEFE SERVICIOS GENERALES
182	JEFE TALLER ELECTRICIDAD
183	JEFE TALLER ELECTRICIDAD Y MAGNETISMO
184	JEFE TALLER INGENIERIA MECANICA
185	JEFE TALLER MECANICO Y MANTENIMIENTO
186	KARDISTA
187	MAESTRO DE DANZA
188	MAESTRO DE MUSICA
189	MAESTRO DE TEATRO
190	MEDICINA DEPORTIVA
191	MEDICO
192	OPERADOR
193	OPERADOR DE CONMUTADOR
194	OPERADOR DE FOTOCOPIADOR
195	OPERADOR DE LITOGRAFIA
196	OPERADOR DEL CENTRO DE COMPUTO
197	ORIENTACION VOCACIONAL
198	PENDIENTE
199	PINTOR
200	PREFECTO
201	PRENSISTA
202	PROFESOR ARTES Y CIENCIAS
203	PROFESOR INVESTIGADOR
204	PROMOTOR CULTURAL
205	PROMOTOR CULTURAL MUSICA
206	PROMOTOR CULTURAL TEATRO
207	PROMOTOR DE AJEDREZ
208	PROMOTOR DE ATLETISMO
209	PROMOTOR DE DANZA
210	PROMOTOR DE ORATORIA Y DECLAMACION
211	PROMOTOR DEPORTIVO ATLETISMO
212	PROMOTOR DEPORTIVO BASE-BALL
213	PROMOTOR DEPORTIVO DE BASQUET-BALL
214	PROMOTOR DEPORTIVO DE NATACION
215	PROMOTOR DEPORTIVO VOLEI-BALL
216	PROMOTOR FUT-BALL AMERICANO
217	PROMOTOR FUT-BALL SOCCER
218	RESPONSABLE DE LABORATORIO IDIOMAS
219	SECRETARIA
220	SECRETARIA ADMINISTRACION DEL PRESUPUESTO
221	SECRETARIA BILINGUE
222	SECRETARIA CONTADOR PRIVADO
223	SECRETARIA DE JEFE DE CENTRO DE COMPUTO
224	SECRETARIA DE JEFE DE DEPARTAMENTO
225	SECRETARIA DE JEFE DE DIVISION
226	SECRETARIA DE LA COORDINACION DE INV. Y
227	SECRETARIA DE LA DIRECCION
228	SECRETARIA DE SERVICIOS GENERALES
229	SECRETARIA DE SUBDIRECTOR
230	SECRETARIA DE TECNOLOGIA EDUCATIVA
231	SECRETARIA DEL CENTRO DE INFORMACION
232	SECRETARIA DEL COMITE PROMOTOR DE DESARROLLO
233	SECRETARIA DEL JEFE DIVISION DE EXTENCIO
234	SECRETARIA PLANEACION
235	SECRETARIA SECCION INFORMACION Y SERVICI
236	SECRETARIA SERVICIO SOCIAL
237	SECRETARIA SERVICIOS ESCOLARES
238	SECRETARIO SINDICAL DELEGACION DV4
239	SUBDIRECTOR
240	SUBDIRECTOR ACADEMICO
241	SUBDIRECTOR ADMINISTRATIVO
242	SUBDIRECTOR DE PLANEACION Y VINCULACION
243	SUBDIRECTOR DE SERVICIOS ADMINISTRATIVOS
244	SUPERVISOR DE INTENDENCIA
245	SUPERVISOR DE SERVICIOS
246	SUPERVISOR DE TIEMPO
247	TECNICO EN ELECTRICIDAD
248	TECNICO EN MAQUINAS DE COMB. INTERNA
249	TECNICO EN MAQUINAS Y HERRAMIENTAS
250	TECNICO EN MECANICA AUT.
251	TRABAJADORA SOCIAL
252	VELADOR
253	VIGILANTE
254	VINCULACION CON EL SECTOR PRODUCTIVO
255	AUXILIAR DE LABORATORIO DE ELECTROMECANICA
256	JEFE DE OFICINA DE PROGRAMACION Y EVALUACION PRESUPUESTARIA
257	JEFE DE OFICINA DE DESARROLLO INSTITUCIONAL
258	JEFE DE OFICINA DE PRACTICAS Y PROMOCION PROFESIONAL
259	JEFE DE OFICINA DE SERV. SOCIAL Y DES. COMUNITARIO
260	JEFE DE OFICINA DE SERVICIOS EXTERNOS
261	COORDINADOR DE SERVICIOS DE COMPUTO
262	JEFE DEL DEPARTAMENTO DE GESTION TECNOLOGICA Y VINCULACION
263	JEFE DE LA OFICINA DE DIFUSION ESCRITA
264	JEFE DE LA OFICINA DE DIFUSION AUDIOVISUAL
265	JEFE DEL DEPARTAMENTO DE ACTIVIDADES EXTRAESCOLARES
266	JEFE DE LA OFICINA DE PROMOCION CULTURAL
267	JEFE DE LA OFICINA DE PROMOCION DEPORTIVA
268	JEFE DE LA OFICINA DE SERVICIOS ESTUDIANTILES
269	JEFE DE LA OFICINA DE ORGANIZACION BIBLIOGRAFICA
270	JEFE DE LA OFICINA DE SERVICIOS A USUARIOS
271	JEFE DE LA OFICINA DE SERVICIOS ESPECIALIZADOS
272	JEFE DEL DEPARTAMENTO DE CIENCIAS BASICAS
273	JEFE DEL DEPARTAMENTO DE SISTEMAS Y COMPUTACION
274	JEFE DEL DEPARTAMENTO DE METAL-MECANICA
275	JEFE DEL DEPARTAMENTO DE CIENCAS DE LA TIERRA
276	JEFE DEL DEPARTAMENTO DE INGENIERIA QUIMICA Y BIOQUIMICA
277	JEFE DEL DEPARTAMENTO  DE INGENIERIA INDUSTRIAL
278	JEFE DEL DPTO ING ELECTROMEC Y MECATRONICA
279	JEFE DEL DEPARTAMENTO DE CIENCIAS ECONOMICAS
280	JEFE DEL DEPARTAMENTO DE DESARROLLO ACADEMICO
281	COORDINADOR DE ACTUALIZACION DOCENTE
282	JEFE DE LA DIVISION DE ESTUDIOS PROFESIONALES
283	COORDINADOR DE PROYECTOS DE INVESTIGACION INTERDEPARTAMENTALES DE CARRERA
284	COORDINADOR DE PROYECTOS DE DIVULGACION CIENTIFICAS DE CARRERAS
285	COORDINADOR DE ORIENTACION EDUCATIVA
286	JEFE DE LA DIVISION DE ESTUDIOS DE POSGRADO E INVESTIGACION
287	COORDINADOR DE POSGRADO
288	COORDINADOR DE PROYECTOS DE INVESTIGACION DE POSGRADO
289	COORDINADOR DE PROYECTOS DE DIVULGACION CIENTIFICA DE POSGRADO
290	JEFE DE LA OFICINA DE REGISTRO Y CONTROLES
291	JEFE DE OFICINA DE SERVICIOS AL PERSONAL
292	JEFE DEL DEPARTAMENTO DE RECURSOS FINANCIEROS
293	JEFE DE LA OFICINA DE TESORERIA
294	JEFE DE LA OFICINA DE CONTABILIDAD Y PRESUPUESTO
295	JEFE DE LA OFICINA DE CONTROL DE INGRESOS PROPIOS
296	JEFE DEL DEPARTAMENTO DE RECURSOS MATERIALES Y SERVICIOS
297	JEFE DE LA OFICINA DE ADQUISIONES
298	JEFE DE LA OFICINA DE ALMACEN E INVENTARIOS
299	JEFE DE LA OFICINA DE SERVICIOS GENERALES
300	COORDINADOR DE DESARROLLO DE SISTEMAS
301	JEFE DEL DEPARTAMENTO DE MANTENIMIENTO DE EQUIPO
302	JEFE DE LA OFICINA DE MANTENIMIENTO PREVENTIVO
303	JEFE DE LA OFICINA DE MANTENIMIENTO CORRECTIVO
304	FOTOGRAFO
305	AUXILIAR CONTABLE
306	PROGRAMADOR
307	CAPTURISTA
308	TECNICO EN MANTENIMIENTO
309	COORDINADOR DE MEDIOS EDUCATIVOS
310	JEFE DE OFICINA DE METODOS EDUCATIVOS
311	RD SISTEMAS DE GESTION
312	MANUAL DE CAMPO
313	COORDINADOR DE TUTORIAS
314	JEFE DE LABORATORIO DE ANALISIS INDUSTRIAL
315	JEFE DE LABORATORIO DE QUIMICA ANALITICA
316	COORDINADORA DEL MODELO DE EQUIDAD DE GENERO
317	COORDINADORA DEL SISTEMA DE GESTION AMBIENTAL
318	JEFE DE LABORATORIO DE FISICA
319	JEFA DE OFICINA DE SERVICIO SOCIAL
320	COORDINADOR DE INGENIERIA EN GESTION EMPRESARIAL
321	COORDINADOR DE INGENIERIA EN SISTEMAS COMPUTACIONALES
322	COORDINADOR DE EDUCACION A DISTANCIA
323	COORDINADOR DE LA CARRERA DE ADMINISTRACION
324	COORDINADOR DE ELETRONICA Y MECATRONICA
325	JEFE DE PROYECTOS DEL DPTO IEE
326	COORDINADORA DE INGENIERIA SISTEMAS Y COMPUTACION
327	AUXILIAR DE POSGRADO
328	COORDINACION DE IDIOMAS
329	COORDINACION DE ACREDITACION Y REACREDIT
330	COORDINACION DE SGC
331	COORDINACION DE SGA
332	COORDINACION DE SSHT
\.


--
-- Data for Name: requisitos_materia; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".requisitos_materia (carrera, reticula, materia, materia_relacion, tipo_requisito) FROM stdin;
\.


--
-- Data for Name: role_user; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".role_user (id, role_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".roles (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seleccion_materias; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".seleccion_materias (periodo, no_de_control, materia, grupo, calificacion, tipo_evaluacion, repeticion, nopresento, status_seleccion, fecha_hora_seleccion, global, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seleccion_materias_log; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".seleccion_materias_log (periodo, no_de_control, materia, grupo, movimiento, cuando, responsable) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: socioecono; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".socioecono (nivel_estudios_padre, nivel_estudios_madre, con_quien_vives, ingresos_padre, ingresos_madre, ingresos_hermanos, ingresos_propios, total_ingresos, ocupacion_padre, ocupacion_madre, de_quien_dependes, casa_vives, cuartos_casa, personas_casa, personas_dependen, tipo_sangre, comunicar_con, calle_no, colonia, codigo_postal, municipio, entidad_federativa, telefono, lugar_trabajo, telefono_trabajo, no_solicitud, periodo, created_at, updated_at, tipo_alergia, enfermedad) FROM stdin;
\.


--
-- Data for Name: sol_ds_de_quien_dependes; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".sol_ds_de_quien_dependes (de_quien, descripcion) FROM stdin;
\.


--
-- Data for Name: sol_ds_estudios_padres; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".sol_ds_estudios_padres (nivel_estudios, descripcion) FROM stdin;
\.


--
-- Data for Name: tipo_materia; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".tipo_materia (tipo_materia, nombre_tipo) FROM stdin;
\.


--
-- Data for Name: tipos_evaluacion; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".tipos_evaluacion (plan_de_estudios, tipo_evaluacion, descripcion_evaluacion, descripcion_corta_evaluacion, calif_minima_aprobatoria, usocurso, nosegundas, prioridad) FROM stdin;
\.


--
-- Data for Name: tipos_ingreso; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".tipos_ingreso (id, descripcion) FROM stdin;
1	EXAMEN SELECCIÓN    
2	EQUIVALENCIA        
3	TRASLADO            
4	CONVALIDACIÓN       
5	MOVILIDAD           
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: ITE; Owner: amaterasu
--

COPY "ITE".users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, two_factor_secret) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2024_06_11_181833_add_two_factor_columns_to_users_table	1
5	2024_06_11_181849_create_personal_access_tokens_table	1
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
0p0nBXfE6wB99FhOpe8hqJuDlJ8PLHNZuGp5I5Ww	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEJ2bXB6cXFrVTljT3MydmhKVFBYZEtIekJGVmhWOUJieTV0bENXeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9uc2lpLnRlc3QvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1718156252
sxu6tTqksATQb3RqlhcqGd1mEUdsN8Ih58Gp3dvO	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjF6TWdMcHF5YnBJeHVqN0g3WERpY1BQSGYySHhTVzZ6cmZqNkM1TSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9uc2lpLnRlc3QvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1718156967
VjVvU8xhpY1DB4a2Gy4OrF5GhBLvYcoeMnNTfzLj	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3BOSVhtTlhGa0NYM0M0SDZuZnZKNUJMUUtPODV6VHBDMmdhVHpMVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9uc2lpLnRlc3QvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1718211759
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: amaterasu
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, current_team_id, profile_photo_path, created_at, updated_at, two_factor_secret, two_factor_recovery_codes, two_factor_confirmed_at) FROM stdin;
\.


--
-- Name: aulas_aspirantes_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".aulas_aspirantes_id_seq', 6, true);


--
-- Name: aulas_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".aulas_id_seq', 186, true);


--
-- Name: baja_cespeciales_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".baja_cespeciales_id_seq', 54, true);


--
-- Name: categorías_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE"."categorías_id_seq"', 688, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".failed_jobs_id_seq', 1, false);


--
-- Name: fecha_evaluacion_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".fecha_evaluacion_id_seq', 1, true);


--
-- Name: folios_constancias_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".folios_constancias_id_seq', 416, true);


--
-- Name: idiomas_docentes_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".idiomas_docentes_id_seq', 1, false);


--
-- Name: idiomas_grupos_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".idiomas_grupos_id_seq', 1, false);


--
-- Name: idiomas_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".idiomas_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".migrations_id_seq', 17, true);


--
-- Name: motivos_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".motivos_id_seq', 96, true);


--
-- Name: municipios_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".municipios_id_seq', 12319, true);


--
-- Name: parametros_fichas_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".parametros_fichas_id_seq', 6, true);


--
-- Name: parametros_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".parametros_id_seq', 1, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_access_tokens_id_seq', 1, false);


--
-- Name: personal_carreras_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_carreras_id_seq', 210, true);


--
-- Name: personal_datos_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_datos_id_seq', 36, true);


--
-- Name: personal_estudios_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_estudios_id_seq', 1142, true);


--
-- Name: personal_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_id_seq', 507, true);


--
-- Name: personal_instit_estudio_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_instit_estudio_id_seq', 67, true);


--
-- Name: personal_nivel_estudios_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_nivel_estudios_id_seq', 28, true);


--
-- Name: personal_nombramientos_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_nombramientos_id_seq', 8, true);


--
-- Name: personal_plazas_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".personal_plazas_id_seq', 5038, true);


--
-- Name: role_user_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".role_user_id_seq', 6987, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".roles_id_seq', 29, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: ITE; Owner: amaterasu
--

SELECT pg_catalog.setval('"ITE".users_id_seq', 7064, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amaterasu
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amaterasu
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amaterasu
--

SELECT pg_catalog.setval('public.migrations_id_seq', 5, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amaterasu
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amaterasu
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: baja_cespeciales baja_cespeciales_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".baja_cespeciales
    ADD CONSTRAINT baja_cespeciales_pkey PRIMARY KEY (id);


--
-- Name: categorias categorías_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".categorias
    ADD CONSTRAINT "categorías_pkey" PRIMARY KEY (id);


--
-- Name: estatus_alumno estatus_alumno_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".estatus_alumno
    ADD CONSTRAINT estatus_alumno_pkey PRIMARY KEY (estatus);


--
-- Name: evaluacion_alumnos evaluacion_alumnos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".evaluacion_alumnos
    ADD CONSTRAINT evaluacion_alumnos_pkey PRIMARY KEY (periodo, no_de_control, materia);


--
-- Name: evaluacion_aspectos evaluacion_aspectos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".evaluacion_aspectos
    ADD CONSTRAINT evaluacion_aspectos_pkey PRIMARY KEY (aspecto, encuesta, consecutivo);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: fecha_evaluacion fecha_evaluacion_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".fecha_evaluacion
    ADD CONSTRAINT fecha_evaluacion_pkey PRIMARY KEY (periodo);


--
-- Name: idiomas_docentes idiomas_docentes_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_docentes
    ADD CONSTRAINT idiomas_docentes_pkey PRIMARY KEY (id);


--
-- Name: idiomas_grupos idiomas_grupos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_grupos
    ADD CONSTRAINT idiomas_grupos_pkey PRIMARY KEY (id);


--
-- Name: idiomas_liberacion idiomas_liberacion_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_liberacion
    ADD CONSTRAINT idiomas_liberacion_pkey PRIMARY KEY (control);


--
-- Name: idiomas idiomas_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas
    ADD CONSTRAINT idiomas_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: motivos motivos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".motivos
    ADD CONSTRAINT motivos_pkey PRIMARY KEY (id);


--
-- Name: municipios municipios_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".municipios
    ADD CONSTRAINT municipios_pkey PRIMARY KEY (id);


--
-- Name: parametros parametros_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".parametros
    ADD CONSTRAINT parametros_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: personal_carreras personal_carreras_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_carreras
    ADD CONSTRAINT personal_carreras_pkey PRIMARY KEY (id);


--
-- Name: personal_datos personal_datos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_datos
    ADD CONSTRAINT personal_datos_pkey PRIMARY KEY (id);


--
-- Name: personal_estudios personal_estudios_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_estudios
    ADD CONSTRAINT personal_estudios_pkey PRIMARY KEY (id);


--
-- Name: personal_nivel_estudios personal_nivel_estudios_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_nivel_estudios
    ADD CONSTRAINT personal_nivel_estudios_pkey PRIMARY KEY (id, caracter);


--
-- Name: personal_nombramientos personal_nombramientos_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_nombramientos
    ADD CONSTRAINT personal_nombramientos_pkey PRIMARY KEY (id);


--
-- Name: personal personal_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal
    ADD CONSTRAINT personal_pkey PRIMARY KEY (id);


--
-- Name: preguntas preguntas_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".preguntas
    ADD CONSTRAINT preguntas_pkey PRIMARY KEY (encuesta, no_pregunta, consecutivo);


--
-- Name: role_user role_user_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".role_user
    ADD CONSTRAINT role_user_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tipos_ingreso tipos_ingreso_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".tipos_ingreso
    ADD CONSTRAINT tipos_ingreso_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: amaterasu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: KEY_idioma; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "KEY_idioma" ON "ITE".idiomas_liberacion USING btree (idioma);


--
-- Name: PK.eval_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK.eval_alumnos" ON "ITE".evaluacion_alumnos USING btree (periodo) INCLUDE (no_de_control, materia) WITH (deduplicate_items='true');


--
-- Name: PK.motivos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK.motivos" ON "ITE".motivos USING btree (motivo) WITH (deduplicate_items='true');


--
-- Name: PK_apoyo_docencia; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_apoyo_docencia" ON "ITE".apoyo_docencia USING btree (periodo, rfc, actividad, consecutivo);


--
-- Name: PK_aulas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_aulas" ON "ITE".aulas USING btree (id) WITH (deduplicate_items='true');


--
-- Name: PK_aulas_aspirantes; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_aulas_aspirantes" ON "ITE".aulas_aspirantes USING btree (id) WITH (deduplicate_items='true');


--
-- Name: PK_horario_admin; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_horario_admin" ON "ITE".horario_administrativo USING btree (periodo, rfc, consecutivo_admvo, fcaptura);


--
-- Name: PK_idiomas_grupos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_idiomas_grupos" ON "ITE".idiomas_grupos USING btree (periodo, clave);


--
-- Name: PK_idiomas_horario; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_idiomas_horario" ON "ITE".idiomas_horario USING btree (periodo, idioma, clave);


--
-- Name: PK_idiomas_inscripcion; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_idiomas_inscripcion" ON "ITE".idiomas_inscripcion USING btree (periodo, control, idioma, clave);


--
-- Name: PK_idiomas_liberacion; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "PK_idiomas_liberacion" ON "ITE".idiomas_liberacion USING btree (control, idioma);


--
-- Name: PK_periodo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "PK_periodo" ON "ITE".fecha_evaluacion USING btree (periodo) WITH (deduplicate_items='true');


--
-- Name: fki_AD_periodos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_AD_periodos" ON "ITE".apoyo_docencia USING btree (periodo);


--
-- Name: fki_AP_activ_apoyo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_AP_activ_apoyo" ON "ITE".apoyo_docencia USING btree (actividad);


--
-- Name: fki_AV_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_AV_alumnos" ON "ITE".avisos_reinscripcion USING btree (no_de_control);


--
-- Name: fki_A_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_A_carreras" ON "ITE".alumnos USING btree (carrera, reticula);


--
-- Name: fki_A_estatus; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_A_estatus" ON "ITE".alumnos USING btree (estatus_alumno);


--
-- Name: fki_A_plan_estudio; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_A_plan_estudio" ON "ITE".alumnos USING btree (plan_de_estudios);


--
-- Name: fki_ESP_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_ESP_carreras" ON "ITE".especialidades USING btree (carrera, reticula);


--
-- Name: fki_F; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_F" ON "ITE".personal_instit_estudios USING btree (id_estado);


--
-- Name: fki_FC_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FC_alumnos" ON "ITE".folio_constancias USING btree (control);


--
-- Name: fki_FC_periodo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FC_periodo" ON "ITE".folio_constancias USING btree (periodo);


--
-- Name: fki_FK.categorias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK.categorias" ON "ITE".personal_plazas USING btree (id_categoria);


--
-- Name: fki_FK.motivos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK.motivos" ON "ITE".personal_plazas USING btree (id_motivo);


--
-- Name: fki_FK.personal; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK.personal" ON "ITE".personal_plazas USING btree (id_personal);


--
-- Name: fki_FK_PE.periodo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK_PE.periodo" ON "ITE".fecha_evaluacion USING btree (periodo);


--
-- Name: fki_FK_aulas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK_aulas" ON "ITE".aulas_aspirantes USING btree (aula);


--
-- Name: fki_FK_idiomas_grupos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK_idiomas_grupos" ON "ITE".idiomas_horario USING btree (clave);


--
-- Name: fki_FK_periodos_escolares; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_FK_periodos_escolares" ON "ITE".parametros_fichas USING btree (fichas);


--
-- Name: fki_G_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_G_carreras" ON "ITE".grupos USING btree (exclusivo_carrera, exclusivo_reticula);


--
-- Name: fki_G_materias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_G_materias" ON "ITE".grupos USING btree (materia);


--
-- Name: fki_G_periodos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_G_periodos" ON "ITE".grupos USING btree (periodo);


--
-- Name: fki_HA_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_HA_alumnos" ON "ITE".historia_alumno USING btree (no_de_control);


--
-- Name: fki_HA_periodos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_HA_periodos" ON "ITE".horario_administrativo USING btree (periodo);


--
-- Name: fki_HA_tipos_ev; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_HA_tipos_ev" ON "ITE".historia_alumno USING btree (tipo_evaluacion, plan_de_estudios);


--
-- Name: fki_HO_periodos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_HO_periodos" ON "ITE".horario_observaciones USING btree (periodo);


--
-- Name: fki_MC_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_MC_carreras" ON "ITE".materias_carreras USING btree (carrera, reticula);


--
-- Name: fki_MC_materias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_MC_materias" ON "ITE".materias_carreras USING btree (materia);


--
-- Name: fki_M_nivel_es; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_M_nivel_es" ON "ITE".materias USING btree (nivel_escolar);


--
-- Name: fki_M_organigrama; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_M_organigrama" ON "ITE".materias USING btree (clave_area);


--
-- Name: fki_M_tipo_materia; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_M_tipo_materia" ON "ITE".materias USING btree (tipo_materia);


--
-- Name: fki_PC_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_PC_carreras" ON "ITE".permisos_carreras USING btree (carrera, reticula);


--
-- Name: fki_PF_periodo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_PF_periodo" ON "ITE".preficha USING btree (periodo);


--
-- Name: fki_P_entidad; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_P_entidad" ON "ITE".preparatorias USING btree (entidad_federativa);


--
-- Name: fki_REQ_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_REQ_carreras" ON "ITE".requisitos_materia USING btree (carrera, reticula);


--
-- Name: fki_REQ_materias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_REQ_materias" ON "ITE".requisitos_materia USING btree (materia);


--
-- Name: fki_SM_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_SM_alumnos" ON "ITE".seleccion_materias USING btree (no_de_control);


--
-- Name: fki_SM_periodos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_SM_periodos" ON "ITE".seleccion_materias USING btree (periodo);


--
-- Name: fki_TE_planes_estudio; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_TE_planes_estudio" ON "ITE".tipos_evaluacion USING btree (plan_de_estudios);


--
-- Name: fki_fk_P_personal_estudios; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX "fki_fk_P_personal_estudios" ON "ITE".personal_estudios USING btree (id_docente);


--
-- Name: fki_fk_municipios; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX fki_fk_municipios ON "ITE".municipios USING btree (id_estado);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX password_resets_email_index ON "ITE".password_resets USING btree (email);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON "ITE".personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: pk_PN_letra; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "pk_PN_letra" ON "ITE".personal_nombramientos USING btree (letra);


--
-- Name: pk_P_estudios; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX "pk_P_estudios" ON "ITE".personal_estudios USING btree (id_docente, id_carrera, id_escuela);


--
-- Name: pk_actividades_apoyo; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_actividades_apoyo ON "ITE".actividades_apoyo USING btree (actividad);


--
-- Name: pk_alumnos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_alumnos ON "ITE".alumnos USING btree (no_de_control);


--
-- Name: pk_alumnos_generales; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_alumnos_generales ON "ITE".alumnos_generales USING btree (no_de_control);


--
-- Name: pk_avisos_reinscripcion; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_avisos_reinscripcion ON "ITE".avisos_reinscripcion USING btree (periodo, no_de_control);


--
-- Name: pk_bespeciales; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_bespeciales ON "ITE".baja_cespeciales USING btree (periodo, no_de_control, materia);


--
-- Name: pk_caracter; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_caracter ON "ITE".personal_nivel_estudios USING btree (caracter);


--
-- Name: pk_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_carreras ON "ITE".carreras USING btree (carrera, reticula);


--
-- Name: pk_edo_mun; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_edo_mun ON "ITE".municipios USING btree (id_estado, id_municipio);


--
-- Name: pk_entidades_federativas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_entidades_federativas ON "ITE".entidades_federativas USING btree (entidad_federativa);


--
-- Name: pk_especialidades; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_especialidades ON "ITE".especialidades USING btree (especialidad, carrera, reticula);


--
-- Name: pk_estatus; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_estatus ON "ITE".estatus_alumno USING btree (estatus);


--
-- Name: pk_evaluacion_aspectos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_evaluacion_aspectos ON "ITE".evaluacion_aspectos USING btree (aspecto, encuesta, consecutivo);


--
-- Name: pk_folios_const; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_folios_const ON "ITE".folio_constancias USING btree (folio, periodo, control);


--
-- Name: pk_grupos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_grupos ON "ITE".grupos USING btree (periodo, materia, grupo);


--
-- Name: pk_historia_alumno; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_historia_alumno ON "ITE".historia_alumno USING btree (periodo, no_de_control, materia, fecha_calificacion);


--
-- Name: pk_horario_obs; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_horario_obs ON "ITE".horario_observaciones USING btree (periodo, rfc, observaciones);


--
-- Name: pk_idiomas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_idiomas ON "ITE".idiomas USING btree (id);


--
-- Name: pk_idiomas2; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_idiomas2 ON "ITE".idiomas USING btree (id, idiomas, abrev);


--
-- Name: pk_jefes; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_jefes ON "ITE".jefes USING btree (clave_area);


--
-- Name: pk_materias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_materias ON "ITE".materias USING btree (materia);


--
-- Name: pk_materias_carreras; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_materias_carreras ON "ITE".materias_carreras USING btree (carrera, reticula, materia, especialidad);


--
-- Name: pk_nivel_escolar; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_nivel_escolar ON "ITE".nivel_escolar USING btree (nivel_escolar);


--
-- Name: pk_organigrama; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_organigrama ON "ITE".organigrama USING btree (clave_area);


--
-- Name: pk_periodos_escolares; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_periodos_escolares ON "ITE".periodos_escolares USING btree (periodo);


--
-- Name: pk_plan_estudios; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_plan_estudios ON "ITE".planes_de_estudio USING btree (plan_de_estudio);


--
-- Name: pk_preficha; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_preficha ON "ITE".preficha USING btree (no_solicitud, periodo);


--
-- Name: pk_preguntas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_preguntas ON "ITE".preguntas USING btree (encuesta, aspecto, no_pregunta, consecutivo);


--
-- Name: pk_prepas; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_prepas ON "ITE".preparatorias USING btree (clave_preparatoria);


--
-- Name: pk_puestos; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_puestos ON "ITE".puestos USING btree (clave_puesto);


--
-- Name: pk_requisitos_materia; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_requisitos_materia ON "ITE".requisitos_materia USING btree (carrera, reticula, materia, materia_relacion);


--
-- Name: pk_seleccion_materias; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_seleccion_materias ON "ITE".seleccion_materias USING btree (periodo, no_de_control, materia);


--
-- Name: pk_socioecono; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_socioecono ON "ITE".socioecono USING btree (no_solicitud, periodo);


--
-- Name: pk_tipo_materia; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_tipo_materia ON "ITE".tipo_materia USING btree (tipo_materia);


--
-- Name: pk_tipos_evaluacion; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE UNIQUE INDEX pk_tipos_evaluacion ON "ITE".tipos_evaluacion USING btree (plan_de_estudios, tipo_evaluacion);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX sessions_last_activity_index ON "ITE".sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: ITE; Owner: amaterasu
--

CREATE INDEX sessions_user_id_index ON "ITE".sessions USING btree (user_id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: amaterasu
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: amaterasu
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: amaterasu
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: amaterasu
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: seleccion_materias alta_materia; Type: TRIGGER; Schema: ITE; Owner: amaterasu
--

CREATE CONSTRAINT TRIGGER alta_materia AFTER INSERT ON "ITE".seleccion_materias NOT DEFERRABLE INITIALLY IMMEDIATE FOR EACH ROW EXECUTE FUNCTION "ITE".alta_materia();


--
-- Name: horarios trig_horario; Type: TRIGGER; Schema: ITE; Owner: amaterasu
--

CREATE TRIGGER trig_horario BEFORE INSERT ON "ITE".horarios FOR EACH ROW EXECUTE FUNCTION "ITE".alta_horario();


--
-- Name: apoyo_docencia AD_periodos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".apoyo_docencia
    ADD CONSTRAINT "AD_periodos" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: alumnos_generales AG_alumnos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".alumnos_generales
    ADD CONSTRAINT "AG_alumnos" FOREIGN KEY (no_de_control) REFERENCES "ITE".alumnos(no_de_control) NOT VALID;


--
-- Name: apoyo_docencia AP_activ_apoyo; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".apoyo_docencia
    ADD CONSTRAINT "AP_activ_apoyo" FOREIGN KEY (actividad) REFERENCES "ITE".actividades_apoyo(actividad) NOT VALID;


--
-- Name: avisos_reinscripcion AV_alumnos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".avisos_reinscripcion
    ADD CONSTRAINT "AV_alumnos" FOREIGN KEY (no_de_control) REFERENCES "ITE".alumnos(no_de_control) NOT VALID;


--
-- Name: alumnos A_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".alumnos
    ADD CONSTRAINT "A_carreras" FOREIGN KEY (carrera, reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: alumnos A_estatus; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".alumnos
    ADD CONSTRAINT "A_estatus" FOREIGN KEY (estatus_alumno) REFERENCES "ITE".estatus_alumno(estatus) NOT VALID;


--
-- Name: alumnos A_plan_estudio; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".alumnos
    ADD CONSTRAINT "A_plan_estudio" FOREIGN KEY (plan_de_estudios) REFERENCES "ITE".planes_de_estudio(plan_de_estudio) NOT VALID;


--
-- Name: personal_instit_estudios EF_estados; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_instit_estudios
    ADD CONSTRAINT "EF_estados" FOREIGN KEY (id_estado) REFERENCES "ITE".entidades_federativas(entidad_federativa) NOT VALID;


--
-- Name: especialidades ESP_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".especialidades
    ADD CONSTRAINT "ESP_carreras" FOREIGN KEY (carrera, reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: folio_constancias FC_alumnos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".folio_constancias
    ADD CONSTRAINT "FC_alumnos" FOREIGN KEY (control) REFERENCES "ITE".alumnos(no_de_control) NOT VALID;


--
-- Name: folio_constancias FC_periodo; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".folio_constancias
    ADD CONSTRAINT "FC_periodo" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: personal_plazas FK.categorias; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_plazas
    ADD CONSTRAINT "FK.categorias" FOREIGN KEY (id_categoria) REFERENCES "ITE".categorias(id) NOT VALID;


--
-- Name: personal_plazas FK.motivos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_plazas
    ADD CONSTRAINT "FK.motivos" FOREIGN KEY (id_motivo) REFERENCES "ITE".motivos(id) NOT VALID;


--
-- Name: personal_plazas FK.personal; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_plazas
    ADD CONSTRAINT "FK.personal" FOREIGN KEY (id_personal) REFERENCES "ITE".personal(id) NOT VALID;


--
-- Name: fecha_evaluacion FK_PE.periodo; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".fecha_evaluacion
    ADD CONSTRAINT "FK_PE.periodo" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: aulas_aspirantes FK_aulas; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".aulas_aspirantes
    ADD CONSTRAINT "FK_aulas" FOREIGN KEY (aula) REFERENCES "ITE".aulas(id) NOT VALID;


--
-- Name: idiomas_horario FK_idiomas_grupos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_horario
    ADD CONSTRAINT "FK_idiomas_grupos" FOREIGN KEY (clave) REFERENCES "ITE".idiomas_grupos(id) NOT VALID;


--
-- Name: idiomas_inscripcion FK_idiomas_grupos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_inscripcion
    ADD CONSTRAINT "FK_idiomas_grupos" FOREIGN KEY (clave) REFERENCES "ITE".idiomas_grupos(id) NOT VALID;


--
-- Name: parametros_fichas FK_periodos_escolares; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".parametros_fichas
    ADD CONSTRAINT "FK_periodos_escolares" FOREIGN KEY (fichas) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: grupos G_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".grupos
    ADD CONSTRAINT "G_carreras" FOREIGN KEY (exclusivo_carrera, exclusivo_reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: grupos G_materias; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".grupos
    ADD CONSTRAINT "G_materias" FOREIGN KEY (materia) REFERENCES "ITE".materias(materia) ON UPDATE CASCADE NOT VALID;


--
-- Name: grupos G_periodos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".grupos
    ADD CONSTRAINT "G_periodos" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: historia_alumno HA_alumnos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".historia_alumno
    ADD CONSTRAINT "HA_alumnos" FOREIGN KEY (no_de_control) REFERENCES "ITE".alumnos(no_de_control) NOT VALID;


--
-- Name: horario_administrativo HA_periodos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".horario_administrativo
    ADD CONSTRAINT "HA_periodos" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: historia_alumno HA_tipos_ev; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".historia_alumno
    ADD CONSTRAINT "HA_tipos_ev" FOREIGN KEY (tipo_evaluacion, plan_de_estudios) REFERENCES "ITE".tipos_evaluacion(tipo_evaluacion, plan_de_estudios) NOT VALID;


--
-- Name: horario_observaciones HO_periodos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".horario_observaciones
    ADD CONSTRAINT "HO_periodos" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: idiomas_liberacion IL_idiomas; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".idiomas_liberacion
    ADD CONSTRAINT "IL_idiomas" FOREIGN KEY (idioma) REFERENCES "ITE".idiomas(id) NOT VALID;


--
-- Name: jefes JEF_org; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".jefes
    ADD CONSTRAINT "JEF_org" FOREIGN KEY (clave_area) REFERENCES "ITE".organigrama(clave_area) NOT VALID;


--
-- Name: materias_carreras MC_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".materias_carreras
    ADD CONSTRAINT "MC_carreras" FOREIGN KEY (carrera, reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: materias_carreras MC_materias; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".materias_carreras
    ADD CONSTRAINT "MC_materias" FOREIGN KEY (materia) REFERENCES "ITE".materias(materia) ON UPDATE CASCADE NOT VALID;


--
-- Name: materias M_nivel_es; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".materias
    ADD CONSTRAINT "M_nivel_es" FOREIGN KEY (nivel_escolar) REFERENCES "ITE".nivel_escolar(nivel_escolar) NOT VALID;


--
-- Name: materias M_organigrama; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".materias
    ADD CONSTRAINT "M_organigrama" FOREIGN KEY (clave_area) REFERENCES "ITE".organigrama(clave_area) NOT VALID;


--
-- Name: materias M_tipo_materia; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".materias
    ADD CONSTRAINT "M_tipo_materia" FOREIGN KEY (tipo_materia) REFERENCES "ITE".tipo_materia(tipo_materia) NOT VALID;


--
-- Name: permisos_carreras PC_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".permisos_carreras
    ADD CONSTRAINT "PC_carreras" FOREIGN KEY (carrera, reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: preficha PF_periodo; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".preficha
    ADD CONSTRAINT "PF_periodo" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: preparatorias P_entidad; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".preparatorias
    ADD CONSTRAINT "P_entidad" FOREIGN KEY (entidad_federativa) REFERENCES "ITE".entidades_federativas(entidad_federativa) NOT VALID;


--
-- Name: requisitos_materia REQ_carreras; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".requisitos_materia
    ADD CONSTRAINT "REQ_carreras" FOREIGN KEY (carrera, reticula) REFERENCES "ITE".carreras(carrera, reticula) NOT VALID;


--
-- Name: requisitos_materia REQ_materias; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".requisitos_materia
    ADD CONSTRAINT "REQ_materias" FOREIGN KEY (materia) REFERENCES "ITE".materias(materia) NOT VALID;


--
-- Name: seleccion_materias SM_alumnos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".seleccion_materias
    ADD CONSTRAINT "SM_alumnos" FOREIGN KEY (no_de_control) REFERENCES "ITE".alumnos(no_de_control) NOT VALID;


--
-- Name: seleccion_materias SM_periodos; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".seleccion_materias
    ADD CONSTRAINT "SM_periodos" FOREIGN KEY (periodo) REFERENCES "ITE".periodos_escolares(periodo) NOT VALID;


--
-- Name: tipos_evaluacion TE_planes_estudio; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".tipos_evaluacion
    ADD CONSTRAINT "TE_planes_estudio" FOREIGN KEY (plan_de_estudios) REFERENCES "ITE".planes_de_estudio(plan_de_estudio) NOT VALID;


--
-- Name: personal_estudios fk_P_personal_estudios; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".personal_estudios
    ADD CONSTRAINT "fk_P_personal_estudios" FOREIGN KEY (id_docente) REFERENCES "ITE".personal(id) NOT VALID;


--
-- Name: municipios fk_municipios; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".municipios
    ADD CONSTRAINT fk_municipios FOREIGN KEY (id_estado) REFERENCES "ITE".entidades_federativas(entidad_federativa) NOT VALID;


--
-- Name: role_user role_user_role_id_foreign; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".role_user
    ADD CONSTRAINT role_user_role_id_foreign FOREIGN KEY (role_id) REFERENCES "ITE".roles(id) ON DELETE CASCADE;


--
-- Name: role_user role_user_user_id_foreign; Type: FK CONSTRAINT; Schema: ITE; Owner: amaterasu
--

ALTER TABLE ONLY "ITE".role_user
    ADD CONSTRAINT role_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES "ITE".users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

